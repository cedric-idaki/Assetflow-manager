import{r as l,h as t}from"./htmlEscape-CwTrPYmb.js";import{aV as h}from"./index-CuypY5S5.js";const i=a=>`KES ${parseFloat(a||0).toLocaleString("en-KE",{minimumFractionDigits:0,maximumFractionDigits:0})}`,g=a=>a?new Date(a).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}):"—",f=a=>a?new Date(a+"-01").toLocaleDateString("en-GB",{month:"long",year:"numeric"}):"—",v=`
  /* A payslip is a document, not a themed page. It declares its own light
     ground: the text colours below are near-black, and a viewer in dark mode
     otherwise paints them onto a dark background — the pop-up sitting behind
     the print dialog comes out unreadable even though the printed sheet is
     fine. color-scheme keeps the browser from inverting scrollbars with it. */
  :root { color-scheme: light; }
  html, body { background: #fff; }
  body { font-family: Arial, sans-serif; max-width: 640px; margin: 32px auto; color: #111; }
  .head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1A56DB; padding-bottom: 16px; margin-bottom: 20px; }
  .co { font-size: 18px; font-weight: 700; }
  .muted { color: #666; font-size: 12px; margin-top: 2px; }
  .title { font-size: 22px; font-weight: 800; color: #1A56DB; text-align: right; }
  .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; font-size: 13px; }
  .lbl { font-size: 11px; text-transform: uppercase; color: #888; letter-spacing: .05em; margin-bottom: 4px; }
  .sec { font-weight: 700; border-bottom: 1px solid #ddd; padding-bottom: 6px; margin: 16px 0 4px; }
  .row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #f0f0f0; font-size: 13px; }
  .row span:last-child { font-family: monospace; font-weight: 600; }
  .neg { color: #DC2626; }
  .gross { font-weight: 700; border-top: 2px solid #111; }
  .net { display: flex; justify-content: space-between; padding: 14px 0; border-top: 2px solid #111; margin-top: 8px; font-size: 18px; font-weight: 800; }
  .net span:last-child { color: #059669; font-family: monospace; }
  .foot { margin-top: 28px; font-size: 11px; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 12px; }
  /* Each payslip is its own sheet. Without this a batch runs slips together
     across page boundaries and nobody can hand one to one employee. */
  .payslip { page-break-after: always; }
  .payslip:last-child { page-break-after: auto; }
  @media print { body { margin: 0 auto; } }
`,b=({company:a,employee:n={},month:p,data:e={}})=>{const s=(a==null?void 0:a.company_name)||"Ararat Company",m=(r,c)=>l(t`<div class="row"><span>${r}</span><span>${i(c)}</span></div>`),d=(r,c)=>l(t`<div class="row"><span>${r}</span><span class="neg">(${i(c)})</span></div>`),u=(r,c)=>parseFloat(c)>0?m(r,c):"",y=(r,c)=>parseFloat(c)>0?d(r,c):"";return t`
    <div class="payslip">
      <div class="head">
        <div>
          <div class="co">${s}</div>
          ${a!=null&&a.kra_pin?l(t`<div class="muted">KRA PIN: ${a.kra_pin}</div>`):""}
          ${a!=null&&a.physical_address?l(t`<div class="muted">${a.physical_address}</div>`):""}
        </div>
        <div>
          <div class="title">PAYSLIP</div>
          <div class="muted" style="text-align:right;">${f(p)}</div>
        </div>
      </div>
      <div class="meta">
        <div>
          <div class="lbl">Employee</div>
          <div style="font-weight:600;">${n.full_name||"—"}</div>
          ${n.department?l(t`<div class="muted">${n.department}</div>`):""}
          ${n.email?l(t`<div class="muted">${n.email}</div>`):""}
          ${n.kra_pin?l(t`<div class="muted">KRA PIN: ${n.kra_pin}</div>`):""}
        </div>
        <div>
          <div class="lbl">Employee ID</div>
          <div style="font-family:monospace;font-size:12px;word-break:break-all;">${n.id||"—"}</div>
          <div class="lbl" style="margin-top:8px;">Pay Period</div>
          <div>${f(p)}</div>
        </div>
      </div>
      <div class="sec">Earnings</div>
      ${m("Basic Salary",e.basic)}
      ${u("Housing Allowance",e.housingAllowance)}
      ${u("Transport Allowance",e.transportAllowance)}
      ${u("Meal Allowance",e.mealAllowance)}
      ${u("Bonus",e.bonus)}
      ${u("Gift",e.gift)}
      <div class="row gross"><span>Gross Pay</span><span>${i(e.grossCash)}</span></div>
      ${e.taxableNonCash>0?l(t`<div class="row"><span>Taxable non-cash benefits</span><span>${i(e.taxableNonCash)}</span></div>`):""}

      <div class="sec">Statutory Deductions</div>
      ${d("NSSF (Tier I & II)",e.nssf)}
      ${d("SHIF (2.75%)",e.shif)}
      ${d("Affordable Housing Levy (1.5%)",e.housingLevy)}
      ${d("PAYE (Income Tax)",e.paye)}

      ${e.voluntaryDeductions>0?l(t`<div class="sec">Other Deductions</div>`):""}
      ${y("Pension Contribution",e.pension)}
      ${y("Post-Retirement Medical",e.postRetirementMedical)}
      ${y("Loan Repayment",e.loanDeduction)}
      ${y("Salary Advance",e.advanceDeduction)}
      ${y("Other",e.otherDeductions)}

      ${d("Total Deductions",e.totalDeductions)}
      <div class="net"><span>NET PAY</span><span>${i(e.netPay)}</span></div>

      <!-- How the tax was arrived at. A payslip that shows only the tax gives
           an employee no way to check it, and gives the employer nothing to
           show a KRA query. -->
      <div class="sec">How PAYE Was Calculated</div>
      <div class="row"><span>Gross pay</span><span>${i(e.grossPay)}</span></div>
      <div class="row"><span>Less allowable deductions (NSSF, SHIF, AHL${e.mortgageDeduction>0?", mortgage interest":""}${e.medicalFundDeduction>0?", medical fund":""})</span><span class="neg">(${i(e.allowableDeductions)})</span></div>
      ${e.disabilityRelief>0?l(t`<div class="row"><span>Less disability exemption</span><span class="neg">(${i(e.disabilityRelief)})</span></div>`):""}
      <div class="row gross"><span>Taxable pay</span><span>${i(e.taxablePay)}</span></div>
      ${l((e.payeBands||[]).map(r=>t`
        <div class="row"><span style="padding-left:12px;">${(r.rate*100).toFixed(r.rate===.325?1:0)}% on ${i(r.amount)}</span><span>${i(r.tax)}</span></div>
      `).join(""))}
      <div class="row"><span>Tax on taxable pay</span><span>${i(e.grossTax)}</span></div>
      <div class="row"><span>Less personal relief</span><span class="neg">(${i(e.personalRelief)})</span></div>
      ${e.insuranceRelief>0?l(t`<div class="row"><span>Less insurance relief</span><span class="neg">(${i(e.insuranceRelief)})</span></div>`):""}
      <div class="row gross"><span>PAYE payable</span><span>${i(e.paye)}</span></div>

      <div class="foot">
        Generated by ${s} on ${g(new Date)} · Computer-generated payslip, no signature required.<br/>
        ${e.rateLabel?`Statutory rates: ${e.rateLabel}`:"Statutory basis not recorded for this period"}
      </div>
    </div>
  `},$=(a=[])=>{var e,s,m,d;const n=Array.isArray(a)?a:[a],p=n.length===1?`Payslip — ${((s=(e=n[0])==null?void 0:e.employee)==null?void 0:s.full_name)||"Employee"} — ${f((m=n[0])==null?void 0:m.month)}`:`Payslips — ${f((d=n[0])==null?void 0:d.month)} — ${n.length} employees`;return t`
    <html><head><title>${p}</title>
    <style>${l(v)}</style></head><body>
    ${l(n.map(u=>b(u)).join(""))}
    </body></html>
  `},w=["PIN of Employee","Name of Employee","Residential Status","Type of Employee","Basic Salary","Housing Allowance","Transport Allowance","Leave Pay","Overtime Allowance","Directors Fee","Lump Sum Payment","Other Allowances","Total Cash Pay","Value of Car Benefit","Other Non-Cash Benefits","Total Non-Cash Pay","Total Gross Pay","Pension: Actual Contribution","Pension: 30% of Cash Pay","Pension: Permissible Limit","Pension: Amount Deductible","Owner Occupier Interest Deductible","Post Retirement Medical Fund","Affordable Housing Levy","Social Health Insurance Fund","Taxable Pay","Tax Payable on Taxable Pay","Monthly Personal Relief","Amount of Insurance Relief","PAYE Tax","Basis"],o=a=>Math.round(((parseFloat(a)||0)+Number.EPSILON)*100)/100,A=({records:a=[],employeesById:n={}})=>a.map(p=>{const e=n[p.employee_id]||{},s=h(p);return{"PIN of Employee":e.kra_pin||"","Name of Employee":e.full_name||"","Residential Status":"Resident","Type of Employee":"Primary Employee","Basic Salary":o(s.basic),"Housing Allowance":o(s.housingAllowance),"Transport Allowance":o(s.transportAllowance),"Leave Pay":0,"Overtime Allowance":0,"Directors Fee":0,"Lump Sum Payment":0,"Other Allowances":o(s.mealAllowance+s.bonus+s.gift+s.otherAllowances),"Total Cash Pay":o(s.grossCash),"Value of Car Benefit":0,"Other Non-Cash Benefits":o(s.nonCashBenefits),"Total Non-Cash Pay":o(s.taxableNonCash),"Total Gross Pay":o(s.grossPay),"Pension: Actual Contribution":o(s.pensionActual),"Pension: 30% of Cash Pay":o(s.pensionRateLimit),"Pension: Permissible Limit":o(s.pensionCap),"Pension: Amount Deductible":o(s.pensionDeduction),"Owner Occupier Interest Deductible":o(s.mortgageDeduction),"Post Retirement Medical Fund":o(s.medicalFundDeduction),"Affordable Housing Levy":o(s.housingLevy),"Social Health Insurance Fund":o(s.shif),"Taxable Pay":o(s.taxablePay),"Tax Payable on Taxable Pay":o(s.grossTax),"Monthly Personal Relief":o(s.personalRelief),"Amount of Insurance Relief":o(s.insuranceRelief),"PAYE Tax":o(s.paye),Basis:s.rebuilt?`${s.rateVersion||"unknown"} (reconstructed)`:s.rateVersion||""}}),D=(a=[])=>{const n=p=>o(a.reduce((e,s)=>e+(parseFloat(s[p])||0),0));return{employees:a.length,grossPay:n("Total Gross Pay"),taxablePay:n("Taxable Pay"),paye:n("PAYE Tax"),shif:n("Social Health Insurance Fund"),housingLevy:n("Affordable Housing Levy"),personalRelief:n("Monthly Personal Relief")}},T=(a=[])=>{const n=a.filter(e=>!e["PIN of Employee"]).map(e=>e["Name of Employee"]||"Unnamed employee"),p=a.filter(e=>String(e.Basis).includes("reconstructed")).length;return{missingPin:n,reconstructed:p}};export{w as P,D as a,A as b,$ as c,T as p};
