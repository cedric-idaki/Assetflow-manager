import React, { useState } from 'react';
import MainLayout from '../../layouts/MainLayout';
import { useAuth } from '../../contexts/AuthContext';
import { useFinanceHub, calcKenyaTax } from '../../hooks/useFinanceHub';
import Icon from '../../components/AppIcon';

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) => `KES ${parseFloat(n || 0).toLocaleString('en-KE', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const fmtMonth = (m) => m ? new Date(m + '-01').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }) : '—';

// ── Skeleton ──────────────────────────────────────────────────────────────────
const Sk = ({ className = '' }) => <div className={`animate-pulse bg-muted rounded-lg ${className}`} />;

// ── Tab button ────────────────────────────────────────────────────────────────
const Tab = ({ active, label, icon, badge, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ${
      active
        ? 'border-primary/40 text-primary'
        : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted'
    }`}
    style={active ? { background: 'rgba(26,86,219,0.08)' } : {}}
  >
    <Icon name={icon} size={15} color="currentColor" />
    {label}
    {badge > 0 && (
      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold">
        {badge}
      </span>
    )}
  </button>
);

// ── KPI Card ──────────────────────────────────────────────────────────────────
const KPICard = ({ title, value, icon, iconBg, iconColor, sub, trend, loading }) => (
  <div className="bg-card border border-border rounded-xl p-5">
    {loading ? (
      <div className="space-y-2 animate-pulse">
        <Sk className="h-4 w-28" /><Sk className="h-8 w-36" /><Sk className="h-3 w-20" />
      </div>
    ) : (
      <>
        <div className="flex items-start justify-between mb-3">
          <p className="text-xs font-medium text-muted-foreground">{title}</p>
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${iconBg}`}>
            <Icon name={icon} size={17} color={iconColor} />
          </div>
        </div>
        <p className="text-2xl font-bold text-foreground leading-none mb-1">{value}</p>
        {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
      </>
    )}
  </div>
);

// ── Status badge ──────────────────────────────────────────────────────────────
const Badge = ({ status }) => {
  const map = {
    paid:     'bg-emerald-100 text-emerald-700',
    pending:  'bg-amber-100 text-amber-700',
    overdue:  'bg-red-100 text-red-700',
    posted:   'bg-blue-100 text-blue-700',
    approved: 'bg-emerald-100 text-emerald-700',
    draft:    'bg-gray-100 text-gray-600',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${map[status] || 'bg-gray-100 text-gray-600'}`}>
      {status}
    </span>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// TAB 1 — INVOICES
// ══════════════════════════════════════════════════════════════════════════════
const InvoicesTab = ({ invoices, loading, companyProfile }) => {
  const [search, setSearch]       = useState('');
  const [statusFilter, setStatus] = useState('all');
  const [selected, setSelected]   = useState(null);

  const filtered = invoices.filter(inv => {
    const matchSearch = !search ||
      inv.client_name.toLowerCase().includes(search.toLowerCase()) ||
      inv.invoice_no.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter === 'all' || inv.status === statusFilter);
  });

  if (selected) {
    return (
      <div className="space-y-4">
        <button onClick={() => setSelected(null)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <Icon name="ArrowLeft" size={15} color="currentColor" /> Back to Invoices
        </button>

        {/* Invoice preview */}
        <div className="bg-card border border-border rounded-xl p-8 max-w-2xl">
          <div className="flex justify-between items-start mb-8">
            <div>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
                <span className="text-white font-bold text-lg">
                  {(companyProfile?.company_name || 'A')[0]}
                </span>
              </div>
              <h2 className="text-xl font-bold text-foreground">{companyProfile?.company_name || 'Your Company'}</h2>
              <p className="text-sm text-muted-foreground">{companyProfile?.email || ''}</p>
              <p className="text-sm text-muted-foreground">{companyProfile?.address || ''}</p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-foreground">{selected.invoice_no}</p>
              <Badge status={selected.status} />
              <p className="text-sm text-muted-foreground mt-2">Date: {fmtDate(selected.date)}</p>
            </div>
          </div>

          <div className="mb-6">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Bill To</p>
            <p className="font-semibold text-foreground">{selected.client_name}</p>
            <p className="text-sm text-muted-foreground">{selected.client_email}</p>
            <p className="text-sm text-muted-foreground">Account: {selected.account_no}</p>
          </div>

          <table className="w-full text-sm mb-6">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 text-xs font-semibold text-muted-foreground uppercase">Description</th>
                <th className="text-right py-2 text-xs font-semibold text-muted-foreground uppercase">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border">
                <td className="py-3">
                  <p className="font-medium text-foreground">{selected.asset || 'Payment'}</p>
                  {selected.asset_code && <p className="text-xs text-muted-foreground">{selected.asset_code}</p>}
                  <p className="text-xs text-muted-foreground">Method: {selected.method} · Ref: {selected.reference}</p>
                </td>
                <td className="py-3 text-right font-semibold text-foreground">{fmt(selected.amount)}</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td className="py-3 font-bold text-foreground">Total</td>
                <td className="py-3 text-right font-bold text-xl text-foreground">{fmt(selected.amount)}</td>
              </tr>
            </tfoot>
          </table>

          {selected.notes && (
            <div className="bg-muted/30 rounded-lg p-3 text-sm text-muted-foreground">
              <span className="font-medium">Notes: </span>{selected.notes}
            </div>
          )}

          <div className="flex gap-3 mt-6 pt-6 border-t border-border">
            <button onClick={() => window.print()}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium border border-border rounded-lg hover:bg-muted transition-colors text-foreground">
              <Icon name="Printer" size={14} color="currentColor" /> Print
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none">
            <Icon name="Search" size={14} color="var(--color-muted-foreground)" />
          </div>
          <input type="text" placeholder="Search client or invoice number..."
            value={search} onChange={e => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground" />
        </div>
        <select value={statusFilter} onChange={e => setStatus(e.target.value)}
          className="px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground">
          <option value="all">All Status</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
          <option value="overdue">Overdue</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {['Invoice', 'Client', 'Asset', 'Date', 'Amount', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? [1,2,3,4,5].map(i => (
                <tr key={i} className="animate-pulse">
                  {[1,2,3,4,5,6,7].map(j => <td key={j} className="px-4 py-3"><Sk className="h-4 w-full" /></td>)}
                </tr>
              )) : filtered.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-16 text-center text-muted-foreground text-sm">
                  No invoices found
                </td></tr>
              ) : filtered.map(inv => (
                <tr key={inv.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground">{inv.invoice_no}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-foreground">{inv.client_name}</p>
                    <p className="text-xs text-muted-foreground">{inv.account_no}</p>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{inv.asset || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground">{fmtDate(inv.date)}</td>
                  <td className="px-4 py-3 font-semibold text-foreground">{fmt(inv.amount)}</td>
                  <td className="px-4 py-3"><Badge status={inv.status} /></td>
                  <td className="px-4 py-3">
                    <button onClick={() => setSelected(inv)}
                      className="text-xs text-primary hover:underline font-medium">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && filtered.length > 0 && (
          <div className="px-4 py-3 border-t border-border bg-muted/20">
            <p className="text-xs text-muted-foreground">Showing {filtered.length} of {invoices.length} invoices</p>
          </div>
        )}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// TAB 2 — JOURNAL ENTRIES
// ══════════════════════════════════════════════════════════════════════════════
const DEBIT_ACCOUNTS  = ['Cash & Bank', 'Accounts Receivable', 'Fixed Assets', 'Prepaid Expenses', 'Inventory', 'Other Assets'];
const CREDIT_ACCOUNTS = ['Accounts Payable', 'Sales Revenue', 'Other Income', 'Accrued Liabilities', 'Owner Equity', 'Loan Payable'];

const JournalTab = ({ journalEntries, loading, onCreate }) => {
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    date: new Date().toISOString().split('T')[0],
    description: '', debitAccount: '', creditAccount: '',
    amount: '', entryType: 'general', reference: '',
  });

  const handleSubmit = async () => {
    if (!form.description || !form.debitAccount || !form.creditAccount || !form.amount) {
      setError('Please fill in all required fields.'); return;
    }
    setSubmitting(true); setError('');
    try {
      await onCreate(form);
      setShowForm(false);
      setForm({ date: new Date().toISOString().split('T')[0], description: '', debitAccount: '', creditAccount: '', amount: '', entryType: 'general', reference: '' });
    } catch (err) {
      setError(err.message);
    } finally { setSubmitting(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">{journalEntries.length} entries</p>
        <button onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white rounded-lg transition-all"
          style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
          <Icon name="Plus" size={14} color="currentColor" />
          New Journal Entry
        </button>
      </div>

      {/* Entry form */}
      {showForm && (
        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">New Journal Entry</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Date *</label>
              <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Type</label>
              <select value={form.entryType} onChange={e => setForm(f => ({ ...f, entryType: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground">
                <option value="general">General</option>
                <option value="expense">Expense</option>
                <option value="revenue">Revenue</option>
                <option value="adjustment">Adjustment</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-muted-foreground mb-1">Description *</label>
              <input type="text" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="e.g. Payment received for Plot A3"
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Debit Account *</label>
              <select value={form.debitAccount} onChange={e => setForm(f => ({ ...f, debitAccount: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground">
                <option value="">Select account...</option>
                {DEBIT_ACCOUNTS.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Credit Account *</label>
              <select value={form.creditAccount} onChange={e => setForm(f => ({ ...f, creditAccount: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground">
                <option value="">Select account...</option>
                {CREDIT_ACCOUNTS.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Amount (KES) *</label>
              <input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Reference</label>
              <input type="text" value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))}
                placeholder="e.g. INV-0042"
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground" />
            </div>
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}
          <div className="flex gap-3 justify-end pt-2 border-t border-border">
            <button onClick={() => setShowForm(false)}
              className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground border border-border rounded-lg hover:bg-muted transition-colors">
              Cancel
            </button>
            <button onClick={handleSubmit} disabled={submitting}
              className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white rounded-lg disabled:opacity-60 transition-all"
              style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
              {submitting ? <><svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg> Posting...</> : 'Post Entry'}
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {['Date', 'Description', 'Debit', 'Credit', 'Amount', 'Status'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? [1,2,3].map(i => (
                <tr key={i} className="animate-pulse">
                  {[1,2,3,4,5,6].map(j => <td key={j} className="px-4 py-3"><Sk className="h-4 w-full" /></td>)}
                </tr>
              )) : journalEntries.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-16 text-center">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Icon name="BookOpen" size={28} color="currentColor" />
                    <p className="text-sm font-medium text-foreground">No journal entries yet</p>
                    <p className="text-xs">Click "New Journal Entry" to get started</p>
                  </div>
                </td></tr>
              ) : journalEntries.map(j => (
                <tr key={j.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-muted-foreground">{fmtDate(j.entry_date)}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-foreground">{j.description}</p>
                    {j.reference && <p className="text-xs text-muted-foreground">{j.reference}</p>}
                  </td>
                  <td className="px-4 py-3 text-emerald-600 font-medium text-xs">{j.debit_account}</td>
                  <td className="px-4 py-3 text-red-500 font-medium text-xs">{j.credit_account}</td>
                  <td className="px-4 py-3 font-semibold text-foreground">{fmt(j.amount)}</td>
                  <td className="px-4 py-3"><Badge status={j.status || 'posted'} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// TAB 3 — PAYROLL
// ══════════════════════════════════════════════════════════════════════════════
const PayrollTab = ({ payrollRecords, employees, loading, onRunPayroll, onApprove }) => {
  const [showForm, setShowForm]   = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]         = useState('');
  const [preview, setPreview]     = useState(null);
  const [form, setForm] = useState({
    employeeId: '', grossSalary: '',
    payMonth: new Date().toISOString().slice(0, 7),
  });

  const handlePreview = () => {
    if (!form.grossSalary) return;
    setPreview(calcKenyaTax(parseFloat(form.grossSalary)));
  };

  const handleSubmit = async () => {
    if (!form.employeeId || !form.grossSalary || !form.payMonth) {
      setError('All fields are required.'); return;
    }
    setSubmitting(true); setError('');
    try {
      await onRunPayroll(form.employeeId, form.grossSalary, form.payMonth);
      setShowForm(false);
      setPreview(null);
      setForm({ employeeId: '', grossSalary: '', payMonth: new Date().toISOString().slice(0, 7) });
    } catch (err) { setError(err.message); }
    finally { setSubmitting(false); }
  };

  const totalGross = payrollRecords.reduce((s, p) => s + parseFloat(p.gross_salary || 0), 0);
  const totalNet   = payrollRecords.reduce((s, p) => s + parseFloat(p.net_salary   || 0), 0);
  const totalPAYE  = payrollRecords.reduce((s, p) => s + parseFloat(p.paye         || 0), 0);

  return (
    <div className="space-y-4">
      {/* Summary strip */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Gross', value: fmt(totalGross), color: 'text-foreground' },
          { label: 'Total PAYE',  value: fmt(totalPAYE),  color: 'text-red-500' },
          { label: 'Total Net',   value: fmt(totalNet),   color: 'text-emerald-600' },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">{s.label}</p>
            <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">{payrollRecords.length} payroll records</p>
        <button onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white rounded-lg transition-all"
          style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
          <Icon name="Plus" size={14} color="currentColor" /> Run Payroll
        </button>
      </div>

      {/* Payroll form */}
      {showForm && (
        <div className="bg-card border border-border rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Run Payroll — Kenya PAYE 2025/26</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Employee *</label>
              <select value={form.employeeId} onChange={e => setForm(f => ({ ...f, employeeId: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground">
                <option value="">Select employee...</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.full_name} — {e.role}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Gross Salary (KES) *</label>
              <input type="number" value={form.grossSalary}
                onChange={e => { setForm(f => ({ ...f, grossSalary: e.target.value })); setPreview(null); }}
                onBlur={handlePreview}
                placeholder="e.g. 85000"
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Pay Month *</label>
              <input type="month" value={form.payMonth} onChange={e => setForm(f => ({ ...f, payMonth: e.target.value }))}
                className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground" />
            </div>
          </div>

          {/* Live tax preview */}
          {preview && (
            <div className="bg-muted/30 rounded-xl p-4 border border-border">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Tax Breakdown Preview</p>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
                {[
                  { label: 'Gross',  value: fmt(preview.gross), color: 'text-foreground' },
                  { label: 'PAYE',   value: fmt(preview.paye),  color: 'text-red-500' },
                  { label: 'NSSF',   value: fmt(preview.nssf),  color: 'text-red-500' },
                  { label: 'SHIF',   value: fmt(preview.shif),  color: 'text-red-500' },
                  { label: 'Net Pay', value: fmt(preview.net),  color: 'text-emerald-600' },
                ].map(r => (
                  <div key={r.label} className="bg-card rounded-lg p-2 border border-border">
                    <p className="text-xs text-muted-foreground">{r.label}</p>
                    <p className={`text-sm font-bold ${r.color}`}>{r.value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && <p className="text-xs text-red-500">{error}</p>}
          <div className="flex gap-3 justify-end pt-2 border-t border-border">
            <button onClick={() => { setShowForm(false); setPreview(null); }}
              className="px-4 py-2 text-sm text-muted-foreground border border-border rounded-lg hover:bg-muted transition-colors">
              Cancel
            </button>
            <button onClick={handleSubmit} disabled={submitting}
              className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white rounded-lg disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
              {submitting ? 'Processing...' : 'Confirm & Save'}
            </button>
          </div>
        </div>
      )}

      {/* Payroll table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {['Employee', 'Department', 'Month', 'Gross', 'PAYE', 'NSSF', 'SHIF', 'Net Pay', 'Status', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading ? [1,2,3].map(i => (
                <tr key={i} className="animate-pulse">
                  {[1,2,3,4,5,6,7,8,9,10].map(j => <td key={j} className="px-4 py-3"><Sk className="h-4 w-full" /></td>)}
                </tr>
              )) : payrollRecords.length === 0 ? (
                <tr><td colSpan={10} className="px-4 py-16 text-center">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Icon name="Users" size={28} color="currentColor" />
                    <p className="text-sm font-medium text-foreground">No payroll records yet</p>
                    <p className="text-xs">Run payroll for your staff above</p>
                  </div>
                </td></tr>
              ) : payrollRecords.map(p => (
                <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{p.employee?.full_name || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{p.employee?.department || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground">{fmtMonth(p.pay_month)}</td>
                  <td className="px-4 py-3 font-semibold text-foreground">{fmt(p.gross_salary)}</td>
                  <td className="px-4 py-3 text-red-500">{fmt(p.paye)}</td>
                  <td className="px-4 py-3 text-red-500">{fmt(p.nssf)}</td>
                  <td className="px-4 py-3 text-red-500">{fmt(p.shif)}</td>
                  <td className="px-4 py-3 font-bold text-emerald-600">{fmt(p.net_salary)}</td>
                  <td className="px-4 py-3"><Badge status={p.status || 'pending'} /></td>
                  <td className="px-4 py-3">
                    {p.status === 'pending' && (
                      <button onClick={() => onApprove(p.id)}
                        className="text-xs text-primary hover:underline font-medium">Approve</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// TAB 4 — FINANCIAL STATEMENTS
// ══════════════════════════════════════════════════════════════════════════════
const StatementsTab = ({ financialSummary, invoices, companyProfile, loading }) => {
  const [view, setView] = useState('pl');
  const s = financialSummary;
  const companyName = companyProfile?.company_name || 'Your Company';
  const today = fmtDate(new Date().toISOString());

  const paidInvoices  = invoices.filter(i => i.status === 'paid');
  const totalRevenue  = paidInvoices.reduce((sum, i) => sum + i.amount, 0);

  if (loading) return (
    <div className="space-y-3 animate-pulse">
      <Sk className="h-8 w-48" />
      {[1,2,3,4,5].map(i => <Sk key={i} className="h-12 w-full" />)}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* View toggle */}
      <div className="flex gap-2">
        {[
          { id: 'pl',      label: 'P&L Statement',   icon: 'TrendingUp' },
          { id: 'balance', label: 'Balance Sheet',    icon: 'Scale' },
        ].map(v => (
          <button key={v.id} onClick={() => setView(v.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
              view === v.id ? 'border-primary/40 text-primary' : 'border-border text-muted-foreground hover:bg-muted'
            }`}
            style={view === v.id ? { background: 'rgba(26,86,219,0.08)' } : {}}>
            <Icon name={v.icon} size={14} color="currentColor" />
            {v.label}
          </button>
        ))}
      </div>

      {/* P&L Statement */}
      {view === 'pl' && (
        <div className="bg-card border border-border rounded-xl p-6 max-w-2xl">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-foreground">{companyName}</h2>
            <p className="text-sm text-muted-foreground">Profit & Loss Statement</p>
            <p className="text-xs text-muted-foreground">As of {today}</p>
          </div>

          {/* Revenue */}
          <div className="mb-4">
            <div className="flex justify-between py-2 border-b border-border">
              <span className="text-sm font-bold text-foreground uppercase tracking-wide">Revenue</span>
            </div>
            <div className="flex justify-between py-2 px-2">
              <span className="text-sm text-foreground">Payment Revenue</span>
              <span className="text-sm font-semibold text-foreground">{fmt(totalRevenue)}</span>
            </div>
            <div className="flex justify-between py-2 px-2 bg-emerald-50 border border-emerald-100 rounded-lg">
              <span className="text-sm font-bold text-emerald-700">Total Revenue</span>
              <span className="text-sm font-bold text-emerald-700">{fmt(totalRevenue)}</span>
            </div>
          </div>

          {/* Expenses */}
          <div className="mb-4">
            <div className="flex justify-between py-2 border-b border-border">
              <span className="text-sm font-bold text-foreground uppercase tracking-wide">Expenses</span>
            </div>
            <div className="flex justify-between py-2 px-2">
              <span className="text-sm text-foreground">Payroll & Staff Costs</span>
              <span className="text-sm font-semibold text-red-500">({fmt(s.totalExpenses)})</span>
            </div>
            <div className="flex justify-between py-2 px-2 bg-red-50 border border-red-100 rounded-lg">
              <span className="text-sm font-bold text-red-700">Total Expenses</span>
              <span className="text-sm font-bold text-red-700">({fmt(s.totalExpenses)})</span>
            </div>
          </div>

          {/* Net Profit */}
          <div className={`flex justify-between p-4 rounded-xl border-2 ${
            s.netProfit >= 0 ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'
          }`}>
            <span className={`text-base font-bold ${s.netProfit >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              Net {s.netProfit >= 0 ? 'Profit' : 'Loss'}
            </span>
            <span className={`text-base font-bold ${s.netProfit >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              {fmt(Math.abs(s.netProfit))}
            </span>
          </div>
        </div>
      )}

      {/* Balance Sheet */}
      {view === 'balance' && (
        <div className="bg-card border border-border rounded-xl p-6 max-w-2xl">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-foreground">{companyName}</h2>
            <p className="text-sm text-muted-foreground">Balance Sheet</p>
            <p className="text-xs text-muted-foreground">As of {today}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Assets */}
            <div>
              <div className="flex justify-between py-2 border-b border-border mb-2">
                <span className="text-sm font-bold text-foreground uppercase tracking-wide">Assets</span>
              </div>
              {[
                { label: 'Cash & Receivables',    value: totalRevenue },
                { label: 'Fixed Assets',          value: s.totalAssets * 0.5 },
                { label: 'Other Assets',          value: s.totalAssets * 0.2 },
              ].map(r => (
                <div key={r.label} className="flex justify-between py-2 px-2 text-sm">
                  <span className="text-muted-foreground">{r.label}</span>
                  <span className="font-medium text-foreground">{fmt(r.value)}</span>
                </div>
              ))}
              <div className="flex justify-between py-2 px-2 bg-blue-50 border border-blue-100 rounded-lg mt-2">
                <span className="text-sm font-bold text-blue-700">Total Assets</span>
                <span className="text-sm font-bold text-blue-700">{fmt(s.totalAssets + totalRevenue)}</span>
              </div>
            </div>

            {/* Liabilities + Equity */}
            <div>
              <div className="flex justify-between py-2 border-b border-border mb-2">
                <span className="text-sm font-bold text-foreground uppercase tracking-wide">Liabilities & Equity</span>
              </div>
              {[
                { label: 'Accounts Payable',      value: s.totalLiabilities * 0.6 },
                { label: 'Other Liabilities',     value: s.totalLiabilities * 0.4 },
                { label: "Owner's Equity",        value: s.equity },
                { label: 'Retained Earnings',     value: s.netProfit },
              ].map(r => (
                <div key={r.label} className="flex justify-between py-2 px-2 text-sm">
                  <span className="text-muted-foreground">{r.label}</span>
                  <span className="font-medium text-foreground">{fmt(r.value)}</span>
                </div>
              ))}
              <div className="flex justify-between py-2 px-2 bg-violet-50 border border-violet-100 rounded-lg mt-2">
                <span className="text-sm font-bold text-violet-700">Total L + E</span>
                <span className="text-sm font-bold text-violet-700">{fmt(s.totalAssets + totalRevenue)}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// MAIN FINANCE HUB PAGE
// ══════════════════════════════════════════════════════════════════════════════
const FinanceHub = () => {
  const { userProfile } = useAuth();
  const {
    invoices, journalEntries, payrollRecords, employees,
    financialSummary: fs, companyProfile, loading,
    createJournalEntry, runPayroll, approvePayroll,
  } = useFinanceHub();

  const [activeTab, setActiveTab] = useState('invoices');

  const tabs = [
    { id: 'invoices',    label: 'Invoices',              icon: 'FileText',  badge: fs.pendingInvoices },
    { id: 'journal',     label: 'Journal Entries',        icon: 'BookOpen',  badge: 0 },
    { id: 'payroll',     label: 'Payroll',                icon: 'Users',     badge: 0 },
    { id: 'statements',  label: 'Financial Statements',   icon: 'BarChart2', badge: 0 },
  ];

  return (
    <MainLayout>
      <div className="space-y-6 p-4 md:p-6">

        {/* ── Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}>
              <Icon name="TrendingUp" size={20} color="white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Finance Hub</h1>
              <p className="text-xs text-muted-foreground">
                {companyProfile?.company_name || userProfile?.full_name || 'Your Company'} · Powered by FINNOVA
              </p>
            </div>
          </div>
        </div>

        {/* ── KPI Cards ── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard title="Total Revenue"    value={fmt(fs.totalRevenue)}   icon="TrendingUp"  iconBg="bg-emerald-100" iconColor="#059669" sub="From paid invoices"      loading={loading} />
          <KPICard title="Total Expenses"   value={fmt(fs.totalExpenses)}  icon="TrendingDown" iconBg="bg-red-100"    iconColor="#dc2626" sub="Payroll + other costs"   loading={loading} />
          <KPICard title="Net Profit"       value={fmt(fs.netProfit)}      icon="DollarSign"  iconBg="bg-blue-100"   iconColor="#1A56DB" sub="Revenue minus expenses"  loading={loading} />
          <KPICard title="Pending Invoices" value={fs.pendingInvoices}     icon="Clock"       iconBg="bg-amber-100"  iconColor="#d97706" sub={`${fs.overdueInvoices} overdue`} loading={loading} />
        </div>

        {/* ── Tabs ── */}
        <div className="flex items-center gap-1 flex-wrap">
          {tabs.map(t => (
            <Tab key={t.id} active={activeTab === t.id} label={t.label}
              icon={t.icon} badge={t.badge} onClick={() => setActiveTab(t.id)} />
          ))}
        </div>

        {/* ── Tab Content ── */}
        {activeTab === 'invoices'   && <InvoicesTab   invoices={invoices} loading={loading} companyProfile={companyProfile} />}
        {activeTab === 'journal'    && <JournalTab     journalEntries={journalEntries} loading={loading} onCreate={createJournalEntry} />}
        {activeTab === 'payroll'    && <PayrollTab     payrollRecords={payrollRecords} employees={employees} loading={loading} onRunPayroll={runPayroll} onApprove={approvePayroll} />}
        {activeTab === 'statements' && <StatementsTab  financialSummary={fs} invoices={invoices} companyProfile={companyProfile} loading={loading} />}

      </div>
    </MainLayout>
  );
};

export default FinanceHub;
