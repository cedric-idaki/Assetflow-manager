import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import PaymentMethodSelector from './PaymentMethodSelector';
import StripePaymentForm from './StripePaymentForm';
import MpesaPaymentForm from './MpesaPaymentForm';
import { supabase } from '../../../lib/supabase';
import { clientsService } from '../../../services/supabaseService';
import KYCBlockedBanner from './KYCBlockedBanner';


const stripePromise = loadStripe(import.meta.env?.VITE_STRIPE_PUBLISHABLE_KEY || '');

const PaymentEntryForm = ({ onSubmit, linkedAssets }) => {
  const [formData, setFormData] = useState({
    clientId: '',
    paymentMethod: 'cash',
    amount: '',
    referenceNumber: '',
    notes: '',
  });
  const [errors, setErrors] = useState({});
  const [stripeClientSecret, setStripeClientSecret] = useState(null);
  const [stripeLoading, setStripeLoading] = useState(false);
  const [stripeError, setStripeError] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(null);
  const [selectedClientInfo, setSelectedClientInfo] = useState(null);
  const [kycStatus, setKycStatus] = useState(null);
  const [kycLoading, setKycLoading] = useState(false);

  const clientOptions = linkedAssets?.map(a => ({
    value: a?.id,
    label: a?.name || a?.id,
  })) || [
    { value: 'CLT001', label: 'John Anderson - ACC-2024-001' },
    { value: 'CLT002', label: 'Sarah Mitchell - ACC-2024-002' },
    { value: 'CLT003', label: 'Michael Chen - ACC-2024-003' },
  ];

  const isCardPayment = formData?.paymentMethod === 'card';
  const isMpesaPayment = formData?.paymentMethod === 'mpesa';
  const isPaymentBlocked = formData?.clientId && kycStatus && kycStatus !== 'verified';

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
    // Reset Stripe state when form changes
    if (stripeClientSecret) {
      setStripeClientSecret(null);
      setStripeError('');
    }
    // Fetch client info when client is selected
    if (field === 'clientId' && value) {
      fetchClientInfo(value);
    }
  };

  const fetchClientInfo = async (clientId) => {
    try {
      setKycLoading(true);
      setKycStatus(null);
      const clients = await clientsService?.getAll();
      const found = clients?.find(c => c?.account_number === clientId || c?.id === clientId);
      setSelectedClientInfo(found || null);
      setKycStatus(found?.kyc_status || 'unverified');
    } catch (err) {
      console.warn('Could not fetch client info for email:', err?.message);
      setSelectedClientInfo(null);
      setKycStatus(null);
    } finally {
      setKycLoading(false);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData?.clientId) newErrors.clientId = 'Please select a client';
    if (!formData?.amount || parseFloat(formData?.amount) <= 0) newErrors.amount = 'Please enter a valid amount';
    if (formData?.paymentMethod !== 'cash' && formData?.paymentMethod !== 'card' && !formData?.referenceNumber) {
      newErrors.referenceNumber = 'Reference number is required for this payment method';
    }
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleInitiateStripePayment = async () => {
    if (!validateForm()) return;
    setStripeLoading(true);
    setStripeError('');

    try {
      const { data: { user } } = await supabase?.auth?.getUser();

      const { data, error } = await supabase?.functions?.invoke('create-payment-intent', {
        body: {
          paymentData: {
            amount: parseFloat(formData?.amount),
            currency: 'usd',
            description: `Payment for client ${formData?.clientId}`,
            additionalFields: {
              clientId: formData?.clientId,
              notes: formData?.notes,
            },
          },
          customerInfo: {
            userId: user?.id || null,
            email: user?.email || null,
            firstName: user?.user_metadata?.full_name?.split(' ')?.[0] || 'Customer',
            lastName: user?.user_metadata?.full_name?.split(' ')?.[1] || '',
            stripeCustomerId: null,
          },
        },
      });

      if (error || data?.error) {
        setStripeError(data?.error || error?.message || 'Failed to initialize payment');
        return;
      }

      setStripeClientSecret(data?.clientSecret);
    } catch (err) {
      setStripeError('Failed to connect to payment service. Please try again.');
      console.error('Stripe init error:', err);
    } finally {
      setStripeLoading(false);
    }
  };

  const handleStripeSuccess = async (paymentIntent, record) => {
    setPaymentSuccess({
      transactionId: record?.transaction_id || paymentIntent?.id,
      amount: parseFloat(formData?.amount),
    });
    setStripeClientSecret(null);
    // Notify parent to refresh transactions
    onSubmit?.({
      ...formData,
      paymentMethod: 'card',
      status: 'completed',
      paymentIntentId: paymentIntent?.id,
      clientEmail: selectedClientInfo?.email || null,
      clientInfo: selectedClientInfo ? { name: selectedClientInfo?.full_name, email: selectedClientInfo?.email, accountNumber: selectedClientInfo?.account_number } : null,
    });
    // Reset form
    setFormData({ clientId: '', paymentMethod: 'cash', amount: '', referenceNumber: '', notes: '' });
    setSelectedClientInfo(null);
  };

  const handleNonCardSubmit = (e) => {
    e?.preventDefault();
    if (isPaymentBlocked) return;
    if (validateForm()) {
      onSubmit?.({
        ...formData,
        clientEmail: selectedClientInfo?.email || null,
        clientInfo: selectedClientInfo ? { name: selectedClientInfo?.full_name, email: selectedClientInfo?.email, accountNumber: selectedClientInfo?.account_number } : null,
      });
      setFormData({ clientId: '', paymentMethod: 'cash', amount: '', referenceNumber: '', notes: '' });
      setSelectedClientInfo(null);
      setKycStatus(null);
    }
  };

  // Success state
  if (paymentSuccess) {
    return (
      <div className="bg-card rounded-lg border border-border p-6 text-center space-y-4">
        <div className="flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/10 mx-auto">
          <Icon name="CheckCircle" size={32} color="var(--color-success, #10b981)" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Payment Successful!</h3>
          <p className="text-sm text-muted-foreground mt-1">
            ${paymentSuccess?.amount?.toFixed(2)} processed via Stripe card payment
          </p>
          <p className="text-xs text-muted-foreground mt-1 font-mono">{paymentSuccess?.transactionId}</p>
        </div>
        <Button
          variant="default"
          onClick={() => setPaymentSuccess(null)}
          iconName="Plus"
          iconPosition="left"
        >
          New Payment
        </Button>
      </div>
    );
  }

  // M-Pesa STK Push form
  if (isMpesaPayment && formData?.clientId && formData?.amount) {
    return (
      <div className="bg-card rounded-lg border border-border p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-green-100">
            <span className="text-green-700 font-bold text-sm">M</span>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">M-Pesa Payment</h3>
            <p className="text-sm text-muted-foreground">Lipa Na M-Pesa STK Push</p>
          </div>
        </div>
        <MpesaPaymentForm
          amount={parseFloat(formData?.amount || 0)}
          clientId={formData?.clientId}
          accountRef={selectedClientInfo?.account_number || formData?.clientId}
          onSuccess={(result) => {
            if (result) {
              onSubmit?.({
                ...formData,
                paymentMethod: 'mpesa',
                status: 'completed',
                referenceNumber: result.transactionId,
                clientEmail: selectedClientInfo?.email || null,
                clientInfo: selectedClientInfo ? {
                  name: selectedClientInfo?.full_name,
                  email: selectedClientInfo?.email,
                  accountNumber: selectedClientInfo?.account_number,
                } : null,
              });
            }
            setFormData({ clientId: '', paymentMethod: 'cash', amount: '', referenceNumber: '', notes: '' });
            setSelectedClientInfo(null);
            setKycStatus(null);
          }}
          onCancel={() => handleInputChange('paymentMethod', 'cash')}
        />
      </div>
    );
  }

  // Stripe Elements payment form
  if (isCardPayment && stripeClientSecret) {
    return (
      <div className="bg-card rounded-lg border border-border p-4 md:p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary bg-opacity-10">
            <Icon name="CreditCard" size={20} color="var(--color-primary)" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Card Payment</h3>
            <p className="text-sm text-muted-foreground">Enter your card details below</p>
          </div>
        </div>
        <Elements
          stripe={stripePromise}
          options={{
            clientSecret: stripeClientSecret,
            appearance: {
              theme: 'stripe',
              variables: {
                colorPrimary: '#7c3aed',
                borderRadius: '8px',
              },
            },
          }}
        >
          <StripePaymentForm
            clientSecret={stripeClientSecret}
            amount={formData?.amount}
            onSuccess={handleStripeSuccess}
            onCancel={() => setStripeClientSecret(null)}
          />
        </Elements>
      </div>
    );
  }

  return (
    <form
      onSubmit={isCardPayment ? (e) => { e?.preventDefault(); if (!isPaymentBlocked) handleInitiateStripePayment(); } : handleNonCardSubmit}
      className="bg-card rounded-lg border border-border p-4 md:p-6"
    >
      <div className="flex items-center space-x-3 mb-6">
        <div className="flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-lg bg-primary bg-opacity-10">
          <Icon name="DollarSign" size={20} color="var(--color-primary)" />
        </div>
        <h3 className="text-lg md:text-xl font-heading font-semibold text-foreground">Payment Entry</h3>
      </div>
      <div className="space-y-4 md:space-y-6">
        <Select
          label="Select Client"
          options={clientOptions}
          value={formData?.clientId}
          onChange={(value) => handleInputChange('clientId', value)}
          error={errors?.clientId}
          required
          searchable
          placeholder="Search and select client"
        />

        {/* KYC Loading indicator */}
        {kycLoading && formData?.clientId && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-muted border border-border">
            <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
            <span className="text-xs text-muted-foreground">Checking KYC verification status...</span>
          </div>
        )}

        {/* KYC Blocked Banner */}
        {!kycLoading && isPaymentBlocked && (
          <KYCBlockedBanner
            kycStatus={kycStatus}
            clientName={selectedClientInfo?.full_name}
          />
        )}

        {/* KYC Verified indicator */}
        {!kycLoading && formData?.clientId && kycStatus === 'verified' && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <Icon name="ShieldCheck" size={14} color="#10b981" />
            <span className="text-xs text-emerald-600 font-medium">KYC Verified — Payment processing enabled</span>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-foreground mb-3">
            Payment Method <span className="text-error">*</span>
          </label>
          <PaymentMethodSelector
            selectedMethod={formData?.paymentMethod}
            onMethodChange={(method) => handleInputChange('paymentMethod', method)}
          />
        </div>

        <Input
          label="Payment Amount"
          type="number"
          min="0"
          step="0.01"
          value={formData?.amount}
          onChange={(e) => handleInputChange('amount', e?.target?.value)}
          error={errors?.amount}
          required
          placeholder="0.00"
          description="Enter the total payment amount in USD"
        />

        {formData?.paymentMethod !== 'cash' && formData?.paymentMethod !== 'card' && (
          <Input
            label="Reference Number"
            type="text"
            value={formData?.referenceNumber}
            onChange={(e) => handleInputChange('referenceNumber', e?.target?.value)}
            error={errors?.referenceNumber}
            required
            placeholder="Enter transaction reference number"
            description="Transaction ID, receipt number, or confirmation code"
          />
        )}

        {isCardPayment && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <Icon name="Info" size={16} color="#3b82f6" />
            <p className="text-xs text-blue-600">
              You will be redirected to a secure Stripe payment form to enter your card details.
            </p>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Notes (Optional)</label>
          <textarea
            value={formData?.notes}
            onChange={(e) => handleInputChange('notes', e?.target?.value)}
            rows="3"
            className="w-full px-4 py-2 rounded-md border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background transition-smooth"
            placeholder="Add any additional notes about this payment"
          />
        </div>

        {stripeError && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-sm">
            <Icon name="AlertCircle" size={16} color="currentColor" />
            <span>{stripeError}</span>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-3 pt-4">
          <Button
            type="submit"
            variant="default"
            iconName={stripeLoading ? 'Loader' : isCardPayment ? 'CreditCard' : 'Check'}
            iconPosition="left"
            fullWidth
            disabled={stripeLoading || isPaymentBlocked || (isMpesaPayment && (!formData?.clientId || !formData?.amount))}
          >
            {stripeLoading ? 'Initializing...' : isCardPayment ? 'Proceed to Card Payment' : isMpesaPayment ? 'Continue to M-Pesa' : 'Process Payment'}
          </Button>
          <Button
            type="button"
            variant="outline"
            iconName="X"
            iconPosition="left"
            fullWidth
            onClick={() => {
              setFormData({ clientId: '', paymentMethod: 'cash', amount: '', referenceNumber: '', notes: '' });
              setSelectedClientInfo(null);
              setKycStatus(null);
            }}
          >
            Clear Form
          </Button>
        </div>
      </div>
    </form>
  );
};

export default PaymentEntryForm;