import React, { useState, useEffect, useCallback } from 'react';
import Icon from '../../../components/AppIcon';
import { supabase } from '../../../lib/supabase';

const ALERT_TYPES = [
  {
    key: 'payment_success',
    label: 'Payment Success',
    description: 'Notify when a payment is confirmed with transaction ID and amount',
    icon: 'CheckCircle',
    color: 'emerald',
    hasThreshold: false,
    hasDays: false,
  },
  {
    key: 'payment_failure',
    label: 'Payment Failure',
    description: 'Notify when a payment fails with reason and retry instructions',
    icon: 'XCircle',
    color: 'red',
    hasThreshold: false,
    hasDays: false,
  },
  {
    key: 'due_date_reminder_7',
    label: 'Due Date Reminder (7 days)',
    description: 'Send reminder 7 days before installment due date',
    icon: 'Calendar',
    color: 'blue',
    hasThreshold: false,
    hasDays: true,
    daysLabel: 'Days before due',
  },
  {
    key: 'due_date_reminder_3',
    label: 'Due Date Reminder (3 days)',
    description: 'Send urgent reminder 3 days before installment due date',
    icon: 'AlertTriangle',
    color: 'amber',
    hasThreshold: false,
    hasDays: true,
    daysLabel: 'Days before due',
  },
  {
    key: 'threshold_breach_transaction',
    label: 'Transaction Threshold',
    description: 'Alert when a single transaction exceeds the configured limit',
    icon: 'TrendingUp',
    color: 'purple',
    hasThreshold: true,
    hasDays: false,
    thresholdLabel: 'Max transaction amount (KES)',
  },
  {
    key: 'threshold_breach_balance',
    label: 'Balance Threshold',
    description: 'Alert when outstanding balance exceeds the configured limit',
    icon: 'DollarSign',
    color: 'violet',
    hasThreshold: true,
    hasDays: false,
    thresholdLabel: 'Max outstanding balance (KES)',
  },
];

const colorMap = {
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-600', border: 'border-emerald-500/20', dot: 'bg-emerald-500' },
  red: { bg: 'bg-red-500/10', text: 'text-red-600', border: 'border-red-500/20', dot: 'bg-red-500' },
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-600', border: 'border-blue-500/20', dot: 'bg-blue-500' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-600', border: 'border-amber-500/20', dot: 'bg-amber-500' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-600', border: 'border-purple-500/20', dot: 'bg-purple-500' },
  violet: { bg: 'bg-violet-500/10', text: 'text-violet-600', border: 'border-violet-500/20', dot: 'bg-violet-500' },
};

const statusColors = {
  sent: 'bg-emerald-500/10 text-emerald-600',
  failed: 'bg-red-500/10 text-red-600',
  skipped: 'bg-amber-500/10 text-amber-600',
  not_sent: 'bg-muted text-muted-foreground',
};

const formatCurrency = (val) =>
  new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', minimumFractionDigits: 0 })?.format(val || 0);

const formatDateTime = (ts) =>
  ts ? new Date(ts)?.toLocaleString('en-KE', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

const Toggle = ({ checked, onChange, disabled }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    disabled={disabled}
    onClick={() => onChange(!checked)}
    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${
      checked ? 'bg-primary' : 'bg-muted-foreground/30'
    } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
  >
    <span
      className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform ${
        checked ? 'translate-x-4.5' : 'translate-x-0.5'
      }`}
    />
  </button>
);

const PaymentAlertsPanel = () => {
  const [configs, setConfigs] = useState({});
  const [alertLogs, setAlertLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);
  const [testLoading, setTestLoading] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [activeSection, setActiveSection] = useState('config');
  const [testForm, setTestForm] = useState({ email: '', phone: '' });
  const [logsPage, setLogsPage] = useState(0);
  const LOGS_PER_PAGE = 10;

  const loadConfigs = useCallback(async () => {
    try {
      const { data, error } = await supabase?.from('payment_alert_configs')?.select('*');
      if (error) throw error;
      const map = {};
      (data || [])?.forEach(c => { map[c.alert_type] = c; });
      setConfigs(map);
    } catch (err) {
      console.error('Failed to load alert configs:', err);
    }
  }, []);

  const loadLogs = useCallback(async () => {
    try {
      const { data, error } = await supabase?.from('payment_alerts_log')?.select('*')?.order('sent_at', { ascending: false })?.limit(50);
      if (error) throw error;
      setAlertLogs(data || []);
    } catch (err) {
      console.error('Failed to load alert logs:', err);
    }
  }, []);

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      await Promise.all([loadConfigs(), loadLogs()]);
      setLoading(false);
    };
    init();
  }, [loadConfigs, loadLogs]);

  const handleToggle = async (alertType, enabled) => {
    setSaving(alertType);
    try {
      const existing = configs?.[alertType];
      if (existing) {
        await supabase?.from('payment_alert_configs')?.update({ enabled, updated_at: new Date()?.toISOString() })?.eq('alert_type', alertType);
      } else {
        await supabase?.from('payment_alert_configs')?.insert({ alert_type: alertType, enabled });
      }
      setConfigs(prev => ({
        ...prev,
        [alertType]: { ...(prev?.[alertType] || { alert_type: alertType }), enabled },
      }));
    } catch (err) {
      console.error('Failed to update config:', err);
    } finally {
      setSaving(null);
    }
  };

  const handleThresholdChange = async (alertType, field, value) => {
    const numVal = parseFloat(value) || null;
    setSaving(alertType);
    try {
      await supabase?.from('payment_alert_configs')?.update({ [field]: numVal, updated_at: new Date()?.toISOString() })?.eq('alert_type', alertType);
      setConfigs(prev => ({
        ...prev,
        [alertType]: { ...(prev?.[alertType] || {}), [field]: numVal },
      }));
    } catch (err) {
      console.error('Failed to update threshold:', err);
    } finally {
      setSaving(null);
    }
  };

  const handleTestAlert = async (alertType) => {
    if (!testForm?.email && !testForm?.phone) {
      setTestResult({ type: 'error', message: 'Please enter an email or phone number to test.' });
      return;
    }
    setTestLoading(alertType);
    setTestResult(null);
    try {
      const mockData = buildMockData(alertType);
      const { data, error } = await supabase?.functions?.invoke('payment-alerts', {
        body: {
          event_type: mapConfigToEvent(alertType),
          recipient_email: testForm?.email || null,
          recipient_phone: testForm?.phone || null,
          recipient_name: 'Test User',
          data: mockData,
        },
      });
      if (error) throw error;
      setTestResult({ type: 'success', message: `Test alert sent! Email: ${data?.email?.status || 'N/A'}, SMS: ${data?.sms?.status || 'N/A'}` });
      await loadLogs();
    } catch (err) {
      setTestResult({ type: 'error', message: `Failed: ${err?.message}` });
    } finally {
      setTestLoading(null);
    }
  };

  const mapConfigToEvent = (alertType) => {
    if (alertType?.startsWith('due_date_reminder')) return 'due_date_reminder';
    if (alertType?.startsWith('threshold_breach')) return 'threshold_breach';
    return alertType;
  };

  const buildMockData = (alertType) => {
    const base = {
      client: { name: 'John Doe', full_name: 'John Doe', account_number: 'ACC-001' },
      transaction: { transactionId: `TXN-TEST-${Date.now()}`, payment_method: 'Bank Transfer', payment_date: new Date()?.toISOString() },
      amount: 25000,
    };
    if (alertType === 'payment_success') return base;
    if (alertType === 'payment_failure') return { ...base, failureReason: 'Insufficient funds', retryInstructions: 'Please top up your account and retry the payment.' };
    if (alertType === 'due_date_reminder_7') return { ...base, installment: { amount: 15000, due_date: new Date(Date.now() + 7 * 86400000)?.toISOString(), installment_number: 3 }, asset: { description: 'Plot 45 Westlands', name: 'Plot 45 Westlands' }, daysUntilDue: 7 };
    if (alertType === 'due_date_reminder_3') return { ...base, installment: { amount: 15000, due_date: new Date(Date.now() + 3 * 86400000)?.toISOString(), installment_number: 3 }, asset: { description: 'Plot 45 Westlands', name: 'Plot 45 Westlands' }, daysUntilDue: 3 };
    if (alertType === 'threshold_breach_transaction') return { ...base, thresholdType: 'transaction', thresholdLimit: configs?.[alertType]?.threshold_amount || 50000, breachAmount: 75000, amount: 75000 };
    if (alertType === 'threshold_breach_balance') return { ...base, thresholdType: 'balance', thresholdLimit: configs?.[alertType]?.threshold_amount || 200000, breachAmount: 250000, amount: 250000 };
    return base;
  };

  const paginatedLogs = alertLogs?.slice(logsPage * LOGS_PER_PAGE, (logsPage + 1) * LOGS_PER_PAGE);
  const totalPages = Math.ceil(alertLogs?.length / LOGS_PER_PAGE);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48 text-muted-foreground">
        <svg className="animate-spin mr-2" width="20" height="20" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
        </svg>
        <span className="text-sm">Loading alert configuration...</span>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Section Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-lg w-fit">
        {[{ id: 'config', label: 'Configuration', icon: 'Settings' }, { id: 'history', label: 'Alert History', icon: 'Clock' }, { id: 'test', label: 'Test Alerts', icon: 'Send' }]?.map(s => (
          <button
            key={s?.id}
            onClick={() => setActiveSection(s?.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-smooth ${
              activeSection === s?.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon name={s?.icon} size={13} color="currentColor" />
            {s?.label}
          </button>
        ))}
      </div>
      {/* ── Configuration Section ── */}
      {activeSection === 'config' && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <Icon name="Bell" size={16} color="currentColor" className="text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Alert Types</h3>
            <span className="text-xs text-muted-foreground ml-auto">
              {Object.values(configs)?.filter(c => c?.enabled)?.length} of {ALERT_TYPES?.length} enabled
            </span>
          </div>

          {ALERT_TYPES?.map(alertDef => {
            const cfg = configs?.[alertDef?.key] || {};
            const colors = colorMap?.[alertDef?.color];
            const isSaving = saving === alertDef?.key;

            return (
              <div key={alertDef?.key} className="border border-border rounded-xl p-4 bg-card hover:border-primary/30 transition-smooth">
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-lg ${colors?.bg} ${colors?.border} border flex items-center justify-center flex-shrink-0`}>
                    <Icon name={alertDef?.icon} size={16} color="currentColor" className={colors?.text} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold text-foreground">{alertDef?.label}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{alertDef?.description}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {isSaving && (
                          <svg className="animate-spin text-muted-foreground" width="12" height="12" viewBox="0 0 24 24" fill="none">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                          </svg>
                        )}
                        <Toggle
                          checked={cfg?.enabled !== false}
                          onChange={(val) => handleToggle(alertDef?.key, val)}
                          disabled={isSaving}
                        />
                      </div>
                    </div>

                    {/* Threshold input */}
                    {alertDef?.hasThreshold && cfg?.enabled !== false && (
                      <div className="mt-3 flex items-center gap-2">
                        <label className="text-xs text-muted-foreground whitespace-nowrap">{alertDef?.thresholdLabel}:</label>
                        <input
                          type="number"
                          min="0"
                          step="1000"
                          defaultValue={cfg?.threshold_amount || ''}
                          placeholder="e.g. 50000"
                          onBlur={(e) => handleThresholdChange(alertDef?.key, 'threshold_amount', e?.target?.value)}
                          className="flex-1 px-2.5 py-1.5 text-xs rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 max-w-[180px]"
                        />
                        {cfg?.threshold_amount && (
                          <span className="text-xs text-muted-foreground">
                            Current: {formatCurrency(cfg?.threshold_amount)}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Days input */}
                    {alertDef?.hasDays && cfg?.enabled !== false && (
                      <div className="mt-3 flex items-center gap-2">
                        <label className="text-xs text-muted-foreground whitespace-nowrap">{alertDef?.daysLabel}:</label>
                        <input
                          type="number"
                          min="1"
                          max="30"
                          defaultValue={cfg?.days_before_due || (alertDef?.key === 'due_date_reminder_7' ? 7 : 3)}
                          onBlur={(e) => handleThresholdChange(alertDef?.key, 'days_before_due', e?.target?.value)}
                          className="w-20 px-2.5 py-1.5 text-xs rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                        />
                        <span className="text-xs text-muted-foreground">days</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {/* ── Alert History Section ── */}
      {activeSection === 'history' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Icon name="Clock" size={16} color="currentColor" className="text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Recent Alerts</h3>
              <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{alertLogs?.length}</span>
            </div>
            <button
              onClick={loadLogs}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-smooth"
            >
              <Icon name="RefreshCw" size={12} color="currentColor" />
              Refresh
            </button>
          </div>

          {alertLogs?.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Icon name="Bell" size={32} color="currentColor" className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">No alerts sent yet</p>
              <p className="text-xs mt-1">Alerts will appear here once triggered</p>
            </div>
          ) : (
            <>
              <div className="space-y-2">
                {paginatedLogs?.map(log => (
                  <div key={log?.id} className="border border-border rounded-xl p-3.5 bg-card">
                    <div className="flex items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium text-foreground capitalize">
                            {log?.event_type?.replace(/_/g, ' ')}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors?.[log?.email_status] || statusColors?.not_sent}`}>
                            Email: {log?.email_status}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors?.[log?.sms_status] || statusColors?.not_sent}`}>
                            SMS: {log?.sms_status}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                          {log?.recipient_name && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Icon name="User" size={10} color="currentColor" />
                              {log?.recipient_name}
                            </span>
                          )}
                          {log?.amount && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Icon name="DollarSign" size={10} color="currentColor" />
                              {formatCurrency(log?.amount)}
                            </span>
                          )}
                          {log?.transaction_id && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Icon name="Hash" size={10} color="currentColor" />
                              {log?.transaction_id}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground flex items-center gap-1 ml-auto">
                            <Icon name="Clock" size={10} color="currentColor" />
                            {formatDateTime(log?.sent_at)}
                          </span>
                        </div>
                        {log?.error_message && (
                          <p className="text-xs text-red-500 mt-1 truncate">{log?.error_message}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setLogsPage(p => Math.max(0, p - 1))}
                    disabled={logsPage === 0}
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition-smooth"
                  >
                    <Icon name="ChevronLeft" size={12} color="currentColor" /> Previous
                  </button>
                  <span className="text-xs text-muted-foreground">Page {logsPage + 1} of {totalPages}</span>
                  <button
                    onClick={() => setLogsPage(p => Math.min(totalPages - 1, p + 1))}
                    disabled={logsPage >= totalPages - 1}
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition-smooth"
                  >
                    Next <Icon name="ChevronRight" size={12} color="currentColor" />
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
      {/* ── Test Alerts Section ── */}
      {activeSection === 'test' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Icon name="Send" size={16} color="currentColor" className="text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Send Test Alerts</h3>
          </div>

          <div className="border border-border rounded-xl p-4 bg-card space-y-3">
            <p className="text-xs text-muted-foreground">Enter a recipient to test each alert type with mock data.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-foreground block mb-1">Email address</label>
                <input
                  type="email"
                  value={testForm?.email}
                  onChange={e => setTestForm(f => ({ ...f, email: e?.target?.value }))}
                  placeholder="test@example.com"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-foreground block mb-1">Phone number (E.164)</label>
                <input
                  type="tel"
                  value={testForm?.phone}
                  onChange={e => setTestForm(f => ({ ...f, phone: e?.target?.value }))}
                  placeholder="+254700000000"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                />
              </div>
            </div>
          </div>

          {testResult && (
            <div className={`flex items-start gap-2 p-3 rounded-lg text-sm ${
              testResult?.type === 'success' ?'bg-emerald-500/10 border border-emerald-500/20 text-emerald-700' :'bg-red-500/10 border border-red-500/20 text-red-700'
            }`}>
              <Icon name={testResult?.type === 'success' ? 'CheckCircle' : 'AlertCircle'} size={14} color="currentColor" className="mt-0.5 flex-shrink-0" />
              <span>{testResult?.message}</span>
              <button onClick={() => setTestResult(null)} className="ml-auto flex-shrink-0">
                <Icon name="X" size={12} color="currentColor" />
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ALERT_TYPES?.map(alertDef => {
              const colors = colorMap?.[alertDef?.color];
              const isLoading = testLoading === alertDef?.key;
              const isEnabled = configs?.[alertDef?.key]?.enabled !== false;

              return (
                <div key={alertDef?.key} className="border border-border rounded-xl p-3.5 bg-card">
                  <div className="flex items-center gap-2.5 mb-2.5">
                    <div className={`w-7 h-7 rounded-lg ${colors?.bg} ${colors?.border} border flex items-center justify-center flex-shrink-0`}>
                      <Icon name={alertDef?.icon} size={13} color="currentColor" className={colors?.text} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-foreground truncate">{alertDef?.label}</p>
                      {!isEnabled && <p className="text-xs text-amber-600">Currently disabled</p>}
                    </div>
                  </div>
                  <button
                    onClick={() => handleTestAlert(alertDef?.key)}
                    disabled={isLoading}
                    className={`w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-smooth ${
                      isLoading
                        ? 'bg-muted text-muted-foreground cursor-not-allowed'
                        : `${colors?.bg} ${colors?.text} hover:opacity-80`
                    }`}
                  >
                    {isLoading ? (
                      <><svg className="animate-spin" width="11" height="11" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" /></svg> Sending...</>
                    ) : (
                      <><Icon name="Send" size={11} color="currentColor" /> Send Test</>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentAlertsPanel;
