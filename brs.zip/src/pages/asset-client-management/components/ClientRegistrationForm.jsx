import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ClientRegistrationForm = ({ onClose, onSubmit, editData }) => {
  var initial = editData || {
    fullName: '',
    nationalId: '',
    passportNumber: '',
    kraPin: '',
    email: '',
    phone: '',
    alternatePhone: '',
    physicalAddress: '',
    postalAddress: '',
    city: '',
    country: 'Kenya',
    photoUrl: '',
  };

  var formState = useState(initial);
  var formData = formState[0];
  var setFormData = formState[1];

  var errorsState = useState({});
  var errors = errorsState[0];
  var setErrors = errorsState[1];

  var photoState = useState(editData ? editData.photoUrl || '' : '');
  var photoPreview = photoState[0];
  var setPhotoPreview = photoState[1];

  var handleChange = function(field, value) {
    setFormData(function(prev) {
      var next = Object.assign({}, prev);
      next[field] = value;
      return next;
    });
    setErrors(function(prev) {
      var next = Object.assign({}, prev);
      next[field] = '';
      return next;
    });
  };

  var handlePhotoUpload = function(e) {
    var file = e.target.files && e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrors(function(prev) {
          return Object.assign({}, prev, { photoUrl: 'Photo must be less than 2MB' });
        });
        return;
      }
      var validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      if (!validTypes.includes(file.type)) {
        setErrors(function(prev) {
          return Object.assign({}, prev, { photoUrl: 'Only JPG and PNG images are allowed' });
        });
        return;
      }
      var reader = new FileReader();
      reader.onloadend = function() {
        setPhotoPreview(reader.result);
        handleChange('photoUrl', reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  var validateForm = function() {
    var newErrors = {};

    if (!formData.fullName || formData.fullName.trim().length < 3) {
      newErrors.fullName = 'Full name must be at least 3 characters';
    } else if (!/^[a-zA-Z\s'-]+$/.test(formData.fullName.trim())) {
      newErrors.fullName = 'Full name should only contain letters';
    }

    if (!formData.nationalId && !formData.passportNumber) {
      newErrors.nationalId = 'National ID or Passport number is required';
    }

    if (formData.kraPin && formData.kraPin.trim() !== '') {
      if (!/^[A-Z]\d{9}[A-Z]$/.test(formData.kraPin.trim().toUpperCase())) {
        newErrors.kraPin = 'Enter a valid KRA PIN (e.g. A123456789B)';
      }
    }

    if (!formData.email || formData.email.trim() === '') {
      newErrors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone || formData.phone.trim() === '') {
      newErrors.phone = 'Phone number is required';
    } else if (!/^[+\d\s()-]{7,15}$/.test(formData.phone.trim())) {
      newErrors.phone = 'Enter a valid phone number';
    }

    if (formData.alternatePhone && formData.alternatePhone.trim() !== '') {
      if (!/^[+\d\s()-]{7,15}$/.test(formData.alternatePhone.trim())) {
        newErrors.alternatePhone = 'Enter a valid alternate phone number';
      }
    }

    if (!formData.physicalAddress || formData.physicalAddress.trim().length < 5) {
      newErrors.physicalAddress = 'Please enter a valid physical address';
    }

    if (!formData.photoUrl) {
      newErrors.photoUrl = 'Passport photo is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  var handleSubmit = function(e) {
    if (e) e.preventDefault();
    if (validateForm()) {
      onSubmit({
        fullName: formData.fullName.trim(),
        nationalId: formData.nationalId.trim(),
        passportNumber: formData.passportNumber.trim(),
        kraPin: formData.kraPin.trim().toUpperCase(),
        email: formData.email.trim().toLowerCase(),
        phone: formData.phone.trim(),
        alternatePhone: formData.alternatePhone.trim(),
        physicalAddress: formData.physicalAddress.trim(),
        postalAddress: formData.postalAddress.trim(),
        city: formData.city.trim(),
        country: formData.country.trim() || 'Kenya',
        photoUrl: formData.photoUrl,
        status: 'active',
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-background bg-opacity-50 z-[110] flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">

        <div className="flex items-center justify-between p-4 md:p-6 border-b border-border">
          <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground">
            {editData ? 'Edit Client' : 'Register New Client'}
          </h2>
          <button onClick={onClose} className="p-2 rounded-md hover:bg-muted transition-smooth">
            <Icon name="X" size={20} color="var(--color-foreground)" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="space-y-4 md:space-y-5">

            <div className="flex flex-col items-center gap-4 p-4 bg-muted rounded-lg">
              <div className="relative">
                {photoPreview ? (
                  <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-primary">
                    <img src={photoPreview} alt="Client photo" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-muted-foreground/10 flex items-center justify-center border-4 border-dashed border-muted-foreground">
                    <Icon name="User" size={40} color="var(--color-muted-foreground)" />
                  </div>
                )}
              </div>
              <div className="text-center">
                <label
                  htmlFor="photo-upload"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-sm font-medium cursor-pointer hover:bg-muted transition-all"
                >
                  <Icon name="Upload" size={14} color="currentColor" />
                  {photoPreview ? 'Change Photo' : 'Upload Photo'}
                </label>
                <input
                  id="photo-upload"
                  type="file"
                  accept="image/jpeg,image/jpg,image/png"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <p className="text-xs text-muted-foreground mt-1">JPG or PNG, max 2MB</p>
                {errors.photoUrl && (
                  <p className="text-xs text-red-500 mt-1">{errors.photoUrl}</p>
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <h3 className="text-base font-semibold text-foreground mb-3">Personal Information</h3>
            </div>

            <Input
              label="Full Name"
              type="text"
              required
              value={formData.fullName}
              onChange={function(e) { handleChange('fullName', e.target.value); }}
              error={errors.fullName}
              placeholder="Enter full legal name"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="National ID"
                type="text"
                value={formData.nationalId}
                onChange={function(e) { handleChange('nationalId', e.target.value); }}
                error={errors.nationalId}
                placeholder="Enter national ID number"
              />
              <Input
                label="Passport Number"
                type="text"
                value={formData.passportNumber}
                onChange={function(e) { handleChange('passportNumber', e.target.value.toUpperCase()); }}
                placeholder="Enter passport number"
              />
            </div>

            <Input
              label="KRA PIN"
              type="text"
              value={formData.kraPin}
              onChange={function(e) { handleChange('kraPin', e.target.value.toUpperCase()); }}
              error={errors.kraPin}
              placeholder="e.g. A123456789B"
              description="Kenya Revenue Authority Personal Identification Number"
            />

            <div className="pt-4 border-t border-border">
              <h3 className="text-base font-semibold text-foreground mb-3">Contact Information</h3>
            </div>

            <Input
              label="Email Address"
              type="email"
              required
              value={formData.email}
              onChange={function(e) { handleChange('email', e.target.value); }}
              error={errors.email}
              placeholder="email@example.com"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Phone Number"
                type="tel"
                required
                value={formData.phone}
                onChange={function(e) { handleChange('phone', e.target.value); }}
                error={errors.phone}
                placeholder="+254 7XX XXX XXX"
              />
              <Input
                label="Alternate Phone"
                type="tel"
                value={formData.alternatePhone}
                onChange={function(e) { handleChange('alternatePhone', e.target.value); }}
                error={errors.alternatePhone}
                placeholder="+254 7XX XXX XXX"
              />
            </div>

            <div className="pt-4 border-t border-border">
              <h3 className="text-base font-semibold text-foreground mb-3">Address Information</h3>
            </div>

            <Input
              label="Physical Address"
              type="text"
              required
              value={formData.physicalAddress}
              onChange={function(e) { handleChange('physicalAddress', e.target.value); }}
              error={errors.physicalAddress}
              placeholder="e.g. 123 Moi Avenue, Nairobi"
            />

            <Input
              label="Postal Address"
              type="text"
              value={formData.postalAddress}
              onChange={function(e) { handleChange('postalAddress', e.target.value); }}
              placeholder="P.O. Box number"
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="City"
                type="text"
                value={formData.city}
                onChange={function(e) { handleChange('city', e.target.value); }}
                placeholder="e.g. Nairobi"
              />
              <Input
                label="Country"
                type="text"
                value={formData.country}
                onChange={function(e) { handleChange('country', e.target.value); }}
                placeholder="e.g. Kenya"
              />
            </div>

            {Object.keys(errors).length > 0 && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
                <Icon name="AlertCircle" size={16} color="currentColor" />
                Please fix the errors above before submitting.
              </div>
            )}
          </div>
        </form>

        <div className="flex items-center justify-end gap-3 p-4 md:p-6 border-t border-border">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button variant="default" onClick={handleSubmit}>
            {editData ? 'Update Client' : 'Register Client'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ClientRegistrationForm;
