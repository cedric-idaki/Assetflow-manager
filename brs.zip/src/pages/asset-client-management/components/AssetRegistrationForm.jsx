import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

// ── Asset-type smart field configs ────────────────────────────────────────────
const ASSET_CONFIGS = {
  vehicle: {
    label: 'Vehicle / Car',
    icon: 'Car',
    color: 'bg-blue-50 border-blue-200',
    iconColor: '#1d4ed8',
    fields: [
      { key: 'vehicleMake',    label: 'Make',           placeholder: 'e.g. Toyota',         required: true,  col: 1 },
      { key: 'vehicleModel',   label: 'Model',          placeholder: 'e.g. Land Cruiser',   required: true,  col: 1 },
      { key: 'vehicleYear',    label: 'Year',           placeholder: '2023',                required: true,  col: 1, type: 'number' },
      { key: 'vehicleColor',   label: 'Color',          placeholder: 'e.g. Pearl White',    required: false, col: 1 },
      { key: 'vehiclePlate',   label: 'Plate Number',   placeholder: 'e.g. KAA 123B',       required: true,  col: 1, upper: true },
      { key: 'vehicleChassis', label: 'Chassis Number', placeholder: 'Enter chassis no.',   required: true,  col: 1, upper: true },
      { key: 'vehicleEngine',  label: 'Engine CC',      placeholder: 'e.g. 2000',           required: false, col: 1 },
      { key: 'vehicleFuel',    label: 'Fuel Type',      placeholder: 'Petrol/Diesel/Hybrid', required: false, col: 1 },
      { key: 'vehicleMileage', label: 'Mileage (km)',   placeholder: 'e.g. 45000',          required: false, col: 1, type: 'number' },
      { key: 'vehicleGearbox', label: 'Gearbox',        placeholder: 'Automatic / Manual',  required: false, col: 1 },
    ],
  },
  property: {
    label: 'Property / Land',
    icon: 'Home',
    color: 'bg-emerald-50 border-emerald-200',
    iconColor: '#059669',
    fields: [
      { key: 'propertyType',     label: 'Property Type',  placeholder: '',          required: true,  col: 1, select: ['land','house','apartment','commercial','plot','bungalow','maisonette'] },
      { key: 'propertySize',     label: 'Size',           placeholder: 'e.g. 0.5 acres or 2500 sq ft', required: true, col: 1 },
      { key: 'propertyLocation', label: 'Location',       placeholder: 'e.g. Westlands, Nairobi',       required: true, col: 2 },
      { key: 'propertyTitle',    label: 'Title Deed No.', placeholder: 'e.g. IR 12345',   required: false, col: 1 },
      { key: 'propertyBedsath',  label: 'Beds / Baths',   placeholder: 'e.g. 3 bed / 2 bath', required: false, col: 1 },
      { key: 'propertyLandRef',  label: 'Land Reference', placeholder: 'e.g. LR No. 209/123', required: false, col: 1 },
    ],
  },
  construction_dealers: {
    label: 'Construction Materials',
    icon: 'HardHat',
    color: 'bg-orange-50 border-orange-200',
    iconColor: '#c2410c',
    fields: [
      { key: 'constCategory',   label: 'Category',        placeholder: 'e.g. Steel, Cement, Timber',  required: true,  col: 1 },
      { key: 'constBrand',      label: 'Brand / Supplier',placeholder: 'e.g. Bamburi, Mabati Rolling', required: false, col: 1 },
      { key: 'constUnit',       label: 'Unit of Measure', placeholder: 'e.g. bags, tons, metres',      required: true,  col: 1 },
      { key: 'constQty',        label: 'Quantity',        placeholder: '100',                          required: true,  col: 1, type: 'number' },
      { key: 'constGrade',      label: 'Grade / Standard',placeholder: 'e.g. Grade 43, BS 8500',       required: false, col: 1 },
      { key: 'constWarehouse',  label: 'Warehouse / Location', placeholder: 'e.g. Embakasi Warehouse', required: false, col: 2 },
      { key: 'specifications',  label: 'Specifications',  placeholder: 'Additional technical details',  required: false, col: 2 },
    ],
  },
  electronics: {
    label: 'Electronics',
    icon: 'Tv2',
    color: 'bg-purple-50 border-purple-200',
    iconColor: '#7c3aed',
    fields: [
      { key: 'elecBrand',   label: 'Brand',          placeholder: 'e.g. Samsung, LG, Apple',     required: true,  col: 1 },
      { key: 'elecModel',   label: 'Model / SKU',    placeholder: 'e.g. UA55AU8000',             required: true,  col: 1 },
      { key: 'elecSerial',  label: 'Serial Number',  placeholder: 'Enter serial number',          required: false, col: 1, upper: true },
      { key: 'elecCondition', label: 'Condition',    placeholder: 'New / Refurbished / Used',     required: true,  col: 1 },
      { key: 'elecWarranty', label: 'Warranty',      placeholder: 'e.g. 1 Year Samsung',          required: false, col: 1 },
      { key: 'elecColor',   label: 'Color / Finish', placeholder: 'e.g. Space Grey',              required: false, col: 1 },
      { key: 'specifications', label: 'Specifications', placeholder: 'e.g. 55" 4K UHD, OLED',    required: false, col: 2 },
    ],
  },
  furnitures: {
    label: 'Furniture',
    icon: 'Armchair',
    color: 'bg-amber-50 border-amber-200',
    iconColor: '#d97706',
    fields: [
      { key: 'furnCategory', label: 'Category',      placeholder: 'e.g. Sofa, Bed, Dining Set',  required: true,  col: 1 },
      { key: 'furnMaterial', label: 'Material',      placeholder: 'e.g. Oak Wood, Leather',       required: true,  col: 1 },
      { key: 'furnBrand',    label: 'Brand / Maker', placeholder: 'e.g. Mobilis, IKEA',           required: false, col: 1 },
      { key: 'furnColor',    label: 'Color / Finish',placeholder: 'e.g. Walnut Brown',            required: false, col: 1 },
      { key: 'furnDimension',label: 'Dimensions',    placeholder: 'e.g. L180 x W90 x H75 cm',    required: false, col: 1 },
      { key: 'furnCondition',label: 'Condition',     placeholder: 'New / Refurbished / Used',     required: true,  col: 1 },
      { key: 'specifications', label: 'Additional Notes', placeholder: 'Other details',           required: false, col: 2 },
    ],
  },
  heavy_equipment: {
    label: 'Heavy Equipment',
    icon: 'Truck',
    color: 'bg-red-50 border-red-200',
    iconColor: '#b91c1c',
    fields: [
      { key: 'heavyBrand',    label: 'Brand / Make',     placeholder: 'e.g. Caterpillar, Komatsu', required: true,  col: 1 },
      { key: 'heavyModel',    label: 'Model',            placeholder: 'e.g. CAT 320D',             required: true,  col: 1 },
      { key: 'heavySerial',   label: 'Serial / VIN',     placeholder: 'Enter serial number',        required: true,  col: 1, upper: true },
      { key: 'heavyYear',     label: 'Year of Manufacture', placeholder: '2020',                   required: true,  col: 1, type: 'number' },
      { key: 'heavyHours',    label: 'Operating Hours',  placeholder: 'e.g. 3200 hrs',             required: false, col: 1, type: 'number' },
      { key: 'heavyLocation', label: 'Current Location', placeholder: 'e.g. Mombasa Port',         required: false, col: 2 },
      { key: 'specifications', label: 'Specifications',  placeholder: 'Engine size, capacity etc.', required: false, col: 2 },
    ],
  },
  other: {
    label: 'Other Asset',
    icon: 'Package',
    color: 'bg-gray-50 border-gray-200',
    iconColor: '#6b7280',
    fields: [
      { key: 'category',     label: 'Category',       placeholder: 'Describe the asset category',  required: true,  col: 1 },
      { key: 'specifications', label: 'Specifications', placeholder: 'Detailed specifications',    required: false, col: 2 },
    ],
  },
};

// ── Image Upload Component ─────────────────────────────────────────────────────
const ImageUpload = ({ images, onAdd, onRemove }) => {
  const fileRef = useRef();
  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (ev) => onAdd({ file, preview: ev.target.result, name: file.name });
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <div className="w-6 h-6 rounded-md bg-indigo-100 flex items-center justify-center">
          <Icon name="Image" size={13} color="#4338ca" />
        </div>
        <span className="text-sm font-semibold text-foreground">Asset Photos</span>
        <span className="text-xs text-muted-foreground ml-1">(optional, up to 5)</span>
      </div>
      <div className="flex flex-wrap gap-3">
        {images.map((img, i) => (
          <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border-2 border-border group">
            <img src={img.preview} alt={img.name} className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => onRemove(i)}
              className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
            >
              <Icon name="Trash2" size={14} color="white" />
            </button>
          </div>
        ))}
        {images.length < 5 && (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="w-20 h-20 rounded-xl border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition-colors flex flex-col items-center justify-center gap-1"
          >
            <Icon name="Plus" size={16} color="var(--color-muted-foreground)" />
            <span className="text-xs text-muted-foreground">Add</span>
          </button>
        )}
      </div>
      <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFiles} />
    </div>
  );
};

// ── Main Form ─────────────────────────────────────────────────────────────────
const AssetRegistrationForm = ({ onClose, onSubmit, editData, allowedAssetTypes }) => {
  const yr = new Date().getFullYear();

  const initial = editData || {
    assetType: '', description: '', sellingPrice: '', status: 'available',
    // property
    propertySize: '', propertyLocation: '', propertyType: '', propertyTitle: '', propertyBedsath: '', propertyLandRef: '',
    // vehicle
    vehicleMake: '', vehicleModel: '', vehicleYear: '', vehiclePlate: '', vehicleChassis: '',
    vehicleColor: '', vehicleEngine: '', vehicleFuel: '', vehicleMileage: '', vehicleGearbox: '',
    // construction
    constCategory: '', constBrand: '', constUnit: '', constQty: '', constGrade: '', constWarehouse: '',
    // electronics
    elecBrand: '', elecModel: '', elecSerial: '', elecCondition: '', elecWarranty: '', elecColor: '',
    // furniture
    furnCategory: '', furnMaterial: '', furnBrand: '', furnColor: '', furnDimension: '', furnCondition: '',
    // heavy equipment
    heavyBrand: '', heavyModel: '', heavySerial: '', heavyYear: '', heavyHours: '', heavyLocation: '',
    // generic
    category: '', specifications: '',
  };

  const [formData, setFormData] = useState(initial);
  const [errors, setErrors]     = useState({});
  const [images, setImages]     = useState([]);

  const defaultAssetTypes = [
    { value: 'vehicle',              label: 'Vehicle / Car Dealer' },
    { value: 'property',             label: 'Property / Land' },
    { value: 'construction_dealers', label: 'Construction Materials' },
    { value: 'electronics',          label: 'Electronics' },
    { value: 'furnitures',           label: 'Furniture' },
    { value: 'heavy_equipment',      label: 'Heavy Equipment' },
    { value: 'other',                label: 'Other' },
  ];

  const assetTypeOptions = (allowedAssetTypes && allowedAssetTypes.length > 0)
    ? allowedAssetTypes : defaultAssetTypes;

  const statusOptions = [
    { value: 'available', label: 'Available' },
    { value: 'reserved',  label: 'Reserved' },
    { value: 'sold',      label: 'Sold' },
  ];

  const cfg = formData.assetType ? ASSET_CONFIGS[formData.assetType] || ASSET_CONFIGS.other : null;

  const set = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setErrors(prev => ({ ...prev, [field]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!formData.assetType) e.assetType = 'Asset type is required';
    if (!formData.description || formData.description.trim().length < 3)
      e.description = 'Description must be at least 3 characters';
    if (!formData.sellingPrice || isNaN(formData.sellingPrice) || parseFloat(formData.sellingPrice) <= 0)
      e.sellingPrice = 'Enter a valid selling price greater than 0';

    // Type-specific required fields
    if (cfg) {
      cfg.fields.filter(f => f.required).forEach(f => {
        if (!formData[f.key] || String(formData[f.key]).trim() === '')
          e[f.key] = `${f.label} is required`;
      });
    }

    // Vehicle year range
    if (formData.assetType === 'vehicle' && formData.vehicleYear) {
      const y = parseInt(formData.vehicleYear);
      if (isNaN(y) || y < 1900 || y > yr + 1)
        e.vehicleYear = `Enter a valid year (1900–${yr + 1})`;
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev) => {
    if (ev) ev.preventDefault();
    if (!validate()) return;
    onSubmit({
      type: formData.assetType,
      description: formData.description.trim(),
      sellingPrice: parseFloat(formData.sellingPrice),
      status: formData.status,
      // property
      location: formData.propertyLocation || '',
      propertyType: formData.propertyType || '',
      propertySize: formData.propertySize || '',
      propertyTitle: formData.propertyTitle || '',
      propertyBedsath: formData.propertyBedsath || '',
      propertyLandRef: formData.propertyLandRef || '',
      // vehicle
      make: formData.vehicleMake || '',
      model: formData.vehicleModel || '',
      year: formData.vehicleYear ? parseInt(formData.vehicleYear) : null,
      color: formData.vehicleColor || '',
      plateNumber: formData.vehiclePlate || '',
      chassisNumber: formData.vehicleChassis || '',
      engineCC: formData.vehicleEngine || '',
      fuelType: formData.vehicleFuel || '',
      mileage: formData.vehicleMileage ? parseInt(formData.vehicleMileage) : null,
      gearbox: formData.vehicleGearbox || '',
      // construction
      constCategory: formData.constCategory || '',
      constBrand: formData.constBrand || '',
      constUnit: formData.constUnit || '',
      constQty: formData.constQty ? parseFloat(formData.constQty) : null,
      constGrade: formData.constGrade || '',
      constWarehouse: formData.constWarehouse || '',
      // electronics
      elecBrand: formData.elecBrand || '',
      elecModel: formData.elecModel || '',
      elecSerial: formData.elecSerial || '',
      elecCondition: formData.elecCondition || '',
      elecWarranty: formData.elecWarranty || '',
      // furniture
      furnCategory: formData.furnCategory || '',
      furnMaterial: formData.furnMaterial || '',
      furnDimension: formData.furnDimension || '',
      furnCondition: formData.furnCondition || '',
      // heavy equipment
      heavyBrand: formData.heavyBrand || '',
      heavyModel: formData.heavyModel || '',
      heavySerial: formData.heavySerial || '',
      heavyYear: formData.heavyYear ? parseInt(formData.heavyYear) : null,
      heavyHours: formData.heavyHours ? parseInt(formData.heavyHours) : null,
      heavyLocation: formData.heavyLocation || '',
      // generic
      category: formData.category || formData.constCategory || formData.furnCategory || formData.elecBrand || '',
      specifications: formData.specifications || '',
      // images (base64 previews for display; actual upload handled separately)
      images: images.map(img => ({ name: img.name, preview: img.preview })),
    });
  };

  // Render a group of fields for the active asset type
  const renderTypeFields = () => {
    if (!cfg) return null;
    const pairs = [];
    const singleCols = cfg.fields.filter(f => f.col === 1);
    const fullCols   = cfg.fields.filter(f => f.col === 2);

    // Pair up single-col fields into rows of 2
    for (let i = 0; i < singleCols.length; i += 2) {
      pairs.push(singleCols.slice(i, i + 2));
    }

    return (
      <div className={`space-y-4 pt-4 border-t border-border rounded-xl p-4 ${cfg.color} border`}>
        <div className="flex items-center gap-2">
          <Icon name={cfg.icon} size={16} color={cfg.iconColor} />
          <h3 className="text-sm font-semibold text-foreground">{cfg.label} Details</h3>
        </div>

        {pairs.map((row, ri) => (
          <div key={ri} className={`grid grid-cols-1 ${row.length > 1 ? 'md:grid-cols-2' : ''} gap-4`}>
            {row.map(f => (
              f.select ? (
                <div key={f.key}>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">
                    {f.label}{f.required && <span className="text-red-500 ml-0.5">*</span>}
                  </label>
                  <select
                    value={formData[f.key] || ''}
                    onChange={e => set(f.key, e.target.value)}
                    className={`w-full px-3 py-2 text-sm bg-background border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 text-foreground ${errors[f.key] ? 'border-red-400' : 'border-border'}`}
                  >
                    <option value="">Select {f.label}</option>
                    {f.select.map(opt => (
                      <option key={opt} value={opt}>{opt.charAt(0).toUpperCase() + opt.slice(1)}</option>
                    ))}
                  </select>
                  {errors[f.key] && <p className="text-xs text-red-500 mt-1">{errors[f.key]}</p>}
                </div>
              ) : (
                <Input
                  key={f.key}
                  label={`${f.label}${f.required ? ' *' : ''}`}
                  type={f.type || 'text'}
                  value={formData[f.key] || ''}
                  onChange={e => set(f.key, f.upper ? e.target.value.toUpperCase() : e.target.value)}
                  error={errors[f.key]}
                  placeholder={f.placeholder}
                />
              )
            ))}
          </div>
        ))}

        {fullCols.map(f => (
          <Input
            key={f.key}
            label={`${f.label}${f.required ? ' *' : ''}`}
            type={f.type || 'text'}
            value={formData[f.key] || ''}
            onChange={e => set(f.key, e.target.value)}
            error={errors[f.key]}
            placeholder={f.placeholder}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <Icon name="Package" size={18} color="var(--color-primary)" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">
                {editData ? 'Edit Asset' : 'Register New Asset'}
              </h2>
              <p className="text-xs text-muted-foreground">Fill in the details below</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <Icon name="X" size={18} color="var(--color-foreground)" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5">
          <div className="space-y-4">

            {/* Asset Type */}
            <Select
              label="Asset Type"
              required
              options={assetTypeOptions}
              value={formData.assetType}
              onChange={v => set('assetType', v)}
              error={errors.assetType}
              placeholder="Select asset type"
            />

            {/* Description */}
            <Input
              label="Description"
              type="text"
              required
              value={formData.description}
              onChange={e => set('description', e.target.value)}
              error={errors.description}
              placeholder={
                formData.assetType === 'vehicle' ? 'e.g. 2022 Toyota Prado TX – Pearl White' :
                formData.assetType === 'property' ? 'e.g. 3-Bedroom House on 0.25 acres, Kileleshwa' :
                formData.assetType === 'electronics' ? 'e.g. Samsung 55" 4K QLED Smart TV' :
                formData.assetType === 'furnitures' ? 'e.g. 7-Seater L-Shaped Leather Sofa' :
                formData.assetType === 'heavy_equipment' ? 'e.g. CAT 320D Excavator – Good Condition' :
                formData.assetType === 'construction_dealers' ? 'e.g. Bamburi Cement 50kg bags x100' :
                'Enter asset description (min 3 characters)'
              }
            />

            {/* Selling Price only (no purchase price) */}
            <Input
              label="Selling Price (KES)"
              type="number"
              required
              value={formData.sellingPrice}
              onChange={e => set('sellingPrice', e.target.value)}
              error={errors.sellingPrice}
              placeholder="0"
            />

            {/* Status */}
            <Select
              label="Status"
              required
              options={statusOptions}
              value={formData.status}
              onChange={v => set('status', v)}
              placeholder="Select status"
            />

            {/* Dynamic type-specific fields */}
            {renderTypeFields()}

            {/* Image Upload */}
            {formData.assetType && (
              <div className="pt-2">
                <ImageUpload
                  images={images}
                  onAdd={img => setImages(prev => [...prev, img])}
                  onRemove={i => setImages(prev => prev.filter((_, idx) => idx !== i))}
                />
              </div>
            )}

            {/* Error summary */}
            {Object.keys(errors).length > 0 && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
                <Icon name="AlertCircle" size={15} color="currentColor" />
                Please fill in all required fields before submitting.
              </div>
            )}
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-border">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button variant="default" onClick={handleSubmit}>
            {editData ? 'Update Asset' : 'Register Asset'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AssetRegistrationForm;
