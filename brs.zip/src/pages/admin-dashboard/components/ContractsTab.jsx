import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const UploadContractModal = ({ onClose, onUpload, clients }) => {
  const [form, setForm] = useState({
    name: '', type: 'general', clientId: '', isTemplate: false,
  });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSubmit = async () => {
    if (!form.name) return setError('Contract name is required.');
    if (!file) return setError('Please select a PDF file to upload.');
    setLoading(true);
    setError('');
    try {
      await onUpload(form, file);
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to upload contract.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-100 flex items-center justify-center">
              <Icon name="FileText" size={18} color="#ea580c" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground">Upload Contract</h3>
              <p className="text-xs text-muted-foreground">Upload a PDF contract template or client contract</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
            <Icon name="X" size={18} color="var(--color-muted-foreground)" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
              <Icon name="AlertCircle" size={15} color="currentColor" />
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Contract Name *</label>
            <input
              type="text"
              value={form.name}
              onChange={e => set('name', e.target.value)}
              placeholder="e.g. Vehicle Sale Agreement"
              className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Contract Type</label>
            <select
              value={form.type}
              onChange={e => set('type', e.target.value)}
              className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground"
            >
              <option value="general">General Contract</option>
              <option value="sale">Sale Agreement</option>
              <option value="lease">Lease Agreement</option>
              <option value="installment">Installment Agreement</option>
              <option value="service">Service Agreement</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">
              Link to Client (optional)
            </label>
            <select
              value={form.clientId}
              onChange={e => set('clientId', e.target.value)}
              className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-1 focus:ring-primary text-foreground"
            >
              <option value="">No client — save as template</option>
              {clients.map(c => (
                <option key={c.id} value={c.id}>{c.full_name} — {c.account_number}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">
              PDF File *
            </label>
            <div
              className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => document.getElementById('contract-file').click()}
            >
              {file ? (
                <div className="flex items-center justify-center gap-2">
                  <Icon name="FileText" size={20} color="#ea580c" />
                  <div className="text-left">
                    <p className="text-sm font-medium text-foreground">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); setFile(null); }}
                    className="ml-2 p-1 rounded hover:bg-muted"
                  >
                    <Icon name="X" size={14} color="var(--color-muted-foreground)" />
                  </button>
                </div>
              ) : (
                <>
                  <Icon name="Upload" size={24} color="var(--color-muted-foreground)" />
                  <p className="text-sm text-muted-foreground mt-2">Click to upload PDF</p>
                  <p className="text-xs text-muted-foreground mt-1">PDF files only, max 10MB</p>
                </>
              )}
            </div>
            <input
              id="contract-file"
              type="file"
              accept=".pdf"
              className="hidden"
              onChange={e => setFile(e.target.files[0])}
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="is-template"
              checked={form.isTemplate}
              onChange={e => set('isTemplate', e.target.checked)}
              className="w-4 h-4 rounded border-border"
            />
            <label htmlFor="is-template" className="text-sm text-foreground cursor-pointer">
              Save as reusable template
            </label>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-border">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold text-white transition-all disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg, #ea580c, #c2410c)' }}
          >
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/>
                </svg>
                Uploading...
              </>
            ) : (
              <>
                <Icon name="Upload" size={15} color="currentColor" />
                Upload Contract
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

const ContractsTab = ({ contracts, clients, onUpload, onExport }) => {
  const [showUpload, setShowUpload] = useState(false);
  const [filter, setFilter] = useState('all');

  const filtered = contracts.filter(c => {
    if (filter === 'templates') return c.is_template;
    if (filter === 'client') return !c.is_template && c.client_id;
    return true;
  });

  const handleDownload = (contract) => {
    if (contract.file_url) {
      window.open(contract.file_url, '_blank');
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between bg-card border border-border rounded-xl px-5 py-4">
        <div>
          <h2 className="text-base font-semibold text-foreground">Contracts</h2>
          <p className="text-xs text-muted-foreground">
            {contracts.length} contract{contracts.length !== 1 ? 's' : ''} ·{' '}
            {contracts.filter(c => c.is_template).length} templates
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onExport(contracts.map(c => ({
              name: c.contract_name,
              type: c.contract_type,
              client: c.client?.full_name || 'Template',
              status: c.status,
              created: c.created_at,
            })), 'contracts')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-all"
          >
            <Icon name="Download" size={13} color="currentColor" />
            Export List
          </button>
          <button
            onClick={() => setShowUpload(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white transition-all"
            style={{ background: 'linear-gradient(135deg, #ea580c, #c2410c)' }}
          >
            <Icon name="Plus" size={13} color="currentColor" />
            Upload Contract
          </button>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-1">
        {[
          { value: 'all', label: 'All Contracts' },
          { value: 'templates', label: 'Templates' },
          { value: 'client', label: 'Client Contracts' },
        ].map(f => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              filter === f.value
                ? 'bg-primary text-white'
                : 'bg-card border border-border text-muted-foreground hover:text-foreground'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Contracts Grid */}
      {filtered.length === 0 ? (
        <div className="bg-card border border-border rounded-xl flex flex-col items-center justify-center py-12 text-muted-foreground">
          <Icon name="FileText" size={32} color="currentColor" />
          <p className="text-sm mt-2">No contracts yet</p>
          <button
            onClick={() => setShowUpload(true)}
            className="mt-3 px-4 py-2 rounded-lg text-sm font-medium text-white"
            style={{ background: 'linear-gradient(135deg, #ea580c, #c2410c)' }}
          >
            Upload First Contract
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(contract => (
            <div key={contract.id} className="bg-card border border-border rounded-xl p-4 hover:shadow-md transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center flex-shrink-0">
                  <Icon name="FileText" size={20} color="#ea580c" />
                </div>
                <div className="flex items-center gap-1">
                  {contract.is_template && (
                    <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
                      Template
                    </span>
                  )}
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold capitalize ${
                    contract.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {contract.status}
                  </span>
                </div>
              </div>

              <h3 className="font-semibold text-foreground text-sm mb-1 line-clamp-1">
                {contract.contract_name}
              </h3>
              <p className="text-xs text-muted-foreground capitalize mb-1">
                {(contract.contract_type || 'general').replace(/_/g, ' ')}
              </p>
              {contract.client && (
                <p className="text-xs text-blue-600 mb-1">
                  Client: {contract.client.full_name}
                </p>
              )}
              <p className="text-xs text-muted-foreground">
                {contract.created_at ? new Date(contract.created_at).toLocaleDateString() : '—'}
              </p>

              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
                <button
                  onClick={() => handleDownload(contract)}
                  disabled={!contract.file_url}
                  className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-medium transition-all disabled:opacity-40"
                  style={{ background: 'rgba(26,86,219,0.1)', color: '#1A56DB' }}
                >
                  <Icon name="Download" size={13} color="currentColor" />
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showUpload && (
        <UploadContractModal
          onClose={() => setShowUpload(false)}
          onUpload={onUpload}
          clients={clients}
        />
      )}
    </div>
  );
};

export default ContractsTab;