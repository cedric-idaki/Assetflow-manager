import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';

// ── Kenya Tax Calculator 2025/26 ──────────────────────────────────────────────
export const calcKenyaTax = (gross) => {
  // PAYE bands 2025/26
  const bands = [
    { limit: 24000,  rate: 0.10 },
    { limit: 8333,   rate: 0.25 },
    { limit: 467667, rate: 0.30 },
    { limit: 300000, rate: 0.325 },
    { limit: Infinity, rate: 0.35 },
  ];
  let paye = 0, remaining = gross;
  for (const band of bands) {
    if (remaining <= 0) break;
    const taxable = Math.min(remaining, band.limit);
    paye += taxable * band.rate;
    remaining -= taxable;
  }
  // Personal relief
  paye = Math.max(0, paye - 2400);

  // NSSF Tier I + II (2025): 6% up to 18,000
  const nssfTierI  = Math.min(gross, 7000)  * 0.06;
  const nssfTierII = Math.min(Math.max(gross - 7000, 0), 11000) * 0.06;
  const nssf = nssfTierI + nssfTierII;

  // SHIF (formerly NHIF) — 2.75% of gross, min 300
  const shif = Math.max(gross * 0.0275, 300);

  const totalDeductions = paye + nssf + shif;
  const net = gross - totalDeductions;

  return {
    gross,
    paye:   Math.round(paye),
    nssf:   Math.round(nssf),
    shif:   Math.round(shif),
    totalDeductions: Math.round(totalDeductions),
    net:    Math.round(net),
  };
};

// ── Hook ──────────────────────────────────────────────────────────────────────
export const useFinanceHub = () => {
  const [adminId, setAdminId]               = useState(null);
  const [companyProfile, setCompanyProfile] = useState(null);
  const [invoices, setInvoices]             = useState([]);
  const [journalEntries, setJournalEntries] = useState([]);
  const [payrollRecords, setPayrollRecords] = useState([]);
  const [employees, setEmployees]           = useState([]);
  const [financialSummary, setFinancialSummary] = useState({
    totalRevenue: 0, totalExpenses: 0, netProfit: 0,
    totalAssets: 0, totalLiabilities: 0, equity: 0,
    pendingInvoices: 0, overdueInvoices: 0,
  });
  const [loading, setLoading]               = useState(true);
  const [error, setError]                   = useState(null);

  // ── Get admin ID ────────────────────────────────────────────────────────────
  const getAdminId = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');
    // Check if user is an admin or get their admin_id
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('id, role, admin_id')
      .eq('id', user.id)
      .single();
    // Admin uses their own ID; staff use admin_id
    return profile?.role === 'admin' ? user.id : (profile?.admin_id || user.id);
  }, []);

  // ── Fetch company profile ───────────────────────────────────────────────────
  const fetchCompanyProfile = useCallback(async (aId) => {
    try {
      const { data } = await supabase
        .from('company_profiles')
        .select('*')
        .eq('admin_id', aId)
        .single();
      setCompanyProfile(data);
    } catch { setCompanyProfile(null); }
  }, []);

  // ── Fetch invoices (from payments table) ────────────────────────────────────
  const fetchInvoices = useCallback(async (aId) => {
    try {
      const { data, error: err } = await supabase
        .from('payments')
        .select(`
          id, amount, payment_date, payment_status, transaction_id,
          reference_number, payment_method, notes,
          client:clients(full_name, email, account_number),
          asset:assets(description, asset_code)
        `)
        .eq('processed_by', aId)
        .order('payment_date', { ascending: false });
      if (err) throw err;
      // Map payments → invoice shape
      const mapped = (data || []).map((p, i) => ({
        id:           p.id,
        invoice_no:   `INV-${String(p.transaction_id || i + 1000).slice(-4)}`,
        date:         p.payment_date,
        due_date:     p.payment_date,
        client_name:  p.client?.full_name || 'Unknown Client',
        client_email: p.client?.email || '',
        account_no:   p.client?.account_number || '',
        asset:        p.asset?.description || '—',
        asset_code:   p.asset?.asset_code || '',
        amount:       parseFloat(p.amount || 0),
        status:       p.payment_status === 'completed' ? 'paid' :
                      p.payment_status === 'pending'   ? 'pending' : 'overdue',
        method:       p.payment_method || '—',
        reference:    p.reference_number || '—',
        notes:        p.notes || '',
      }));
      setInvoices(mapped);
      return mapped;
    } catch (err) {
      console.error('fetchInvoices error:', err.message);
      setInvoices([]);
      return [];
    }
  }, []);

  // ── Fetch journal entries ───────────────────────────────────────────────────
  const fetchJournalEntries = useCallback(async (aId) => {
    try {
      // Try to fetch from journal_entries table — create it if missing
      const { data, error: err } = await supabase
        .from('journal_entries')
        .select('*')
        .eq('admin_id', aId)
        .order('entry_date', { ascending: false });
      if (err) throw err;
      setJournalEntries(data || []);
    } catch {
      // Table may not exist yet — seed with derived entries from payments
      setJournalEntries([]);
    }
  }, []);

  // ── Fetch payroll records ───────────────────────────────────────────────────
  const fetchPayrollRecords = useCallback(async (aId) => {
    try {
      const { data, error: err } = await supabase
        .from('payroll_records')
        .select('*, employee:user_profiles(full_name, email, department)')
        .eq('admin_id', aId)
        .order('pay_month', { ascending: false });
      if (err) throw err;
      setPayrollRecords(data || []);
    } catch {
      setPayrollRecords([]);
    }
  }, []);

  // ── Fetch employees (staff under this admin) ────────────────────────────────
  const fetchEmployees = useCallback(async (aId) => {
    try {
      const { data, error: err } = await supabase
        .from('user_profiles')
        .select('id, full_name, email, role, department, is_active')
        .eq('admin_id', aId)
        .eq('is_active', true)
        .neq('role', 'client')
        .neq('role', 'admin');
      if (err) throw err;
      setEmployees(data || []);
    } catch {
      setEmployees([]);
    }
  }, []);

  // ── Compute financial summary ───────────────────────────────────────────────
  const computeSummary = useCallback((invList, journalList, payrollList) => {
    const totalRevenue = invList
      .filter(i => i.status === 'paid')
      .reduce((s, i) => s + i.amount, 0);

    const pendingInvoices = invList.filter(i => i.status === 'pending').length;
    const overdueInvoices = invList.filter(i => i.status === 'overdue').length;

    const totalPayroll = payrollList.reduce((s, p) => s + parseFloat(p.gross_salary || 0), 0);

    const journalExpenses = journalList
      .filter(j => j.entry_type === 'expense' && j.status === 'posted')
      .reduce((s, j) => s + parseFloat(j.amount || 0), 0);

    const totalExpenses = totalPayroll + journalExpenses;
    const netProfit = totalRevenue - totalExpenses;

    // Simple balance sheet approximation
    const totalAssets = totalRevenue * 0.8;
    const totalLiabilities = totalExpenses * 0.3;
    const equity = totalAssets - totalLiabilities;

    setFinancialSummary({
      totalRevenue, totalExpenses, netProfit,
      totalAssets, totalLiabilities, equity,
      pendingInvoices, overdueInvoices,
    });
  }, []);

  // ── Load all ────────────────────────────────────────────────────────────────
  const loadAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const aId = await getAdminId();
      setAdminId(aId);

      const [invList, , , ,] = await Promise.all([
        fetchInvoices(aId),
        fetchJournalEntries(aId),
        fetchPayrollRecords(aId),
        fetchEmployees(aId),
        fetchCompanyProfile(aId),
      ]);

      // Re-fetch state for summary computation
      const { data: journals } = await supabase
        .from('journal_entries').select('amount, entry_type, status')
        .eq('admin_id', aId).catch(() => ({ data: [] }));
      const { data: payrolls } = await supabase
        .from('payroll_records').select('gross_salary')
        .eq('admin_id', aId).catch(() => ({ data: [] }));

      computeSummary(invList, journals || [], payrolls || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [getAdminId, fetchInvoices, fetchJournalEntries, fetchPayrollRecords, fetchEmployees, fetchCompanyProfile, computeSummary]);

  useEffect(() => { loadAll(); }, []);

  // ── Mutations ───────────────────────────────────────────────────────────────
  const createJournalEntry = useCallback(async (entryData) => {
    if (!adminId) throw new Error('Not ready');
    const { data, error: err } = await supabase
      .from('journal_entries')
      .insert({
        admin_id:     adminId,
        entry_date:   entryData.date || new Date().toISOString().split('T')[0],
        description:  entryData.description,
        debit_account:  entryData.debitAccount,
        credit_account: entryData.creditAccount,
        amount:       parseFloat(entryData.amount),
        entry_type:   entryData.entryType || 'general',
        reference:    entryData.reference || null,
        status:       'posted',
      })
      .select()
      .single();
    if (err) throw err;
    await fetchJournalEntries(adminId);
    return data;
  }, [adminId, fetchJournalEntries]);

  const runPayroll = useCallback(async (employeeId, grossSalary, payMonth) => {
    if (!adminId) throw new Error('Not ready');
    const tax = calcKenyaTax(parseFloat(grossSalary));
    const { data, error: err } = await supabase
      .from('payroll_records')
      .insert({
        admin_id:     adminId,
        employee_id:  employeeId,
        pay_month:    payMonth,
        gross_salary: tax.gross,
        paye:         tax.paye,
        nssf:         tax.nssf,
        shif:         tax.shif,
        total_deductions: tax.totalDeductions,
        net_salary:   tax.net,
        status:       'pending',
      })
      .select()
      .single();
    if (err) throw err;
    await fetchPayrollRecords(adminId);
    return { ...data, ...tax };
  }, [adminId, fetchPayrollRecords]);

  const approvePayroll = useCallback(async (payrollId) => {
    const { error: err } = await supabase
      .from('payroll_records')
      .update({ status: 'approved', approved_at: new Date().toISOString() })
      .eq('id', payrollId);
    if (err) throw err;
    await fetchPayrollRecords(adminId);
  }, [adminId, fetchPayrollRecords]);

  return {
    adminId, companyProfile,
    invoices, journalEntries, payrollRecords, employees,
    financialSummary, loading, error,
    createJournalEntry, runPayroll, approvePayroll,
    refetch: loadAll,
  };
};

export default useFinanceHub;
