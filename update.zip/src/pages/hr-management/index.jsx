import React, { useState, useEffect, useCallback, useRef } from 'react';
import MainLayout from '../../layouts/MainLayout';
import { supabase } from '../../lib/supabase';
import Icon from '../../components/AppIcon';

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
const fmt     = (n) => `KES ${parseFloat(n || 0).toLocaleString('en-KE', { maximumFractionDigits: 0 })}`;
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

const ROLES = ['accountant','collections_officer','manager','finance','operations','sales_agent'];
const DEPTS = ['Finance','Sales','Operations','Administration','HR','IT','Management'];
const EMP_TYPES = ['full_time','part_time','contract','intern'];

const S = {
  input:  'w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all',
  select: 'w-full bg-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all',
  label:  'block text-xs font-semibold text-muted-foreground mb-1.5',
  btnPri: 'inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors',
  btnSec: 'inline-flex items-center gap-2 bg-muted text-foreground px-4 py-2 rounded-lg text-sm font-medium border border-border hover:bg-muted/70 transition-colors',
  th:     'text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider bg-muted/40',
  td:     'px-4 py-3 text-sm text-muted-foreground border-t border-border',
  tdF:    'px-4 py-3 text-sm font-medium text-foreground border-t border-border',
};

const Sk = ({ className = '' }) => <div className={`animate-pulse bg-muted rounded-md ${className}`} />;

const Badge = ({ status }) => {
  const map = {
    true:      'bg-emerald-100 text-emerald-700',
    false:     'bg-red-100    text-red-700',
    full_time: 'bg-blue-100   text-blue-700',
    part_time: 'bg-amber-100  text-amber-700',
    contract:  'bg-violet-100 text-violet-700',
    intern:    'bg-gray-100   text-gray-600',
  };
  const label = status === true ? 'Active' : status === false ? 'Inactive' : String(status).replace(/_/g, ' ');
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${map[String(status)] || 'bg-gray-100 text-gray-500'}`}>
      {label}
    </span>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// EMPLOYEE FORM MODAL
// ─────────────────────────────────────────────────────────────────────────────
const EmployeeModal = ({ employee, adminId, onClose, onSaved }) => {
  const isEdit = !!employee;
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState('');
  const [form, setForm] = useState({
    full_name:           employee?.full_name           || '',
    email:               employee?.email               || '',
    phone:               employee?.phone               || '',
    role:                employee?.role                || 'operations',
    department:          employee?.department          || '',
    employment_type:     employee?.employment_type     || 'full_time',
    date_joined:         employee?.date_joined         || '',
    basic_salary:        employee?.basic_salary        || '',
    housing_allowance:   employee?.housing_allowance   || '',
    transport_allowance: employee?.transport_allowance || '',
    national_id:         employee?.national_id         || '',
    kra_pin:             employee?.kra_pin             || '',
    nssf_number:         employee?.nssf_number         || '',
    sha_number:          employee?.sha_number          || '',
    bank_name:           employee?.bank_name           || '',
    bank_account:        employee?.bank_account        || '',
    bank_branch:         employee?.bank_branch         || '',
    leave_balance:       employee?.leave_balance       ?? 21,
    is_active:           employee?.is_active           ?? true,
  });

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!form.full_name || !form.email) { setError('Full name and email are required'); return; }
    setSaving(true); setError('');
    try {
      const payload = {
        full_name:           form.full_name,
        phone:               form.phone               || null,
        role:                form.role,
        department:          form.department          || null,
        employment_type:     form.employment_type,
        date_joined:         form.date_joined         || null,
        basic_salary:        parseFloat(form.basic_salary)        || 0,
        housing_allowance:   parseFloat(form.housing_allowance)   || 0,
        transport_allowance: parseFloat(form.transport_allowance) || 0,
        national_id:         form.national_id         || null,
        kra_pin:             form.kra_pin             || null,
        nssf_number:         form.nssf_number         || null,
        sha_number:          form.sha_number          || null,
        bank_name:           form.bank_name           || null,
        bank_account:        form.bank_account        || null,
        bank_branch:         form.bank_branch         || null,
        leave_balance:       parseInt(form.leave_balance) || 21,
        is_active:           form.is_active,
        admin_id:            adminId,
        updated_at:          new Date().toISOString(),
      };

      if (isEdit) {
        const { error: err } = await supabase.from('user_profiles').update(payload).eq('id', employee.id);
        if (err) throw err;
      } else {
        // For new employees, admin creates the auth user then profile
        // Here we just create the profile record directly
        const { error: err } = await supabase.from('user_profiles')
          .insert({ ...payload, email: form.email });
        if (err) throw err;
      }
      onSaved();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const Section = ({ title }) => (
    <div className="col-span-2 pt-2 pb-1 border-b border-border">
      <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{title}</p>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h3 className="text-base font-bold text-foreground">{isEdit ? `Edit — ${employee.full_name}` : 'Add New Employee'}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
            <Icon name="X" size={18} color="var(--muted-foreground)" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-6 py-5">
          <div className="grid grid-cols-2 gap-4">
            <Section title="Personal Information" />
            <div>
              <label className={S.label}>Full Name *</label>
              <input className={S.input} value={form.full_name} onChange={e => set('full_name', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Email *</label>
              <input type="email" className={S.input} value={form.email} onChange={e => set('email', e.target.value)} disabled={isEdit} />
            </div>
            <div>
              <label className={S.label}>Phone</label>
              <input className={S.input} placeholder="+254 7XX XXX XXX" value={form.phone} onChange={e => set('phone', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>National ID</label>
              <input className={S.input} value={form.national_id} onChange={e => set('national_id', e.target.value)} />
            </div>

            <Section title="Employment Details" />
            <div>
              <label className={S.label}>Role</label>
              <select className={S.select} value={form.role} onChange={e => set('role', e.target.value)}>
                {ROLES.map(r => <option key={r} value={r}>{r.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</option>)}
              </select>
            </div>
            <div>
              <label className={S.label}>Department</label>
              <select className={S.select} value={form.department} onChange={e => set('department', e.target.value)}>
                <option value="">— Select —</option>
                {DEPTS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className={S.label}>Employment Type</label>
              <select className={S.select} value={form.employment_type} onChange={e => set('employment_type', e.target.value)}>
                {EMP_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</option>)}
              </select>
            </div>
            <div>
              <label className={S.label}>Date Joined</label>
              <input type="date" className={S.input} value={form.date_joined} onChange={e => set('date_joined', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Leave Balance (days)</label>
              <input type="number" className={S.input} value={form.leave_balance} onChange={e => set('leave_balance', e.target.value)} />
            </div>
            <div className="flex items-center gap-3 pt-5">
              <input type="checkbox" id="is_active" checked={form.is_active} onChange={e => set('is_active', e.target.checked)}
                className="w-4 h-4 accent-primary" />
              <label htmlFor="is_active" className="text-sm font-medium text-foreground">Active Employee</label>
            </div>

            <Section title="Compensation" />
            <div>
              <label className={S.label}>Basic Salary (KES)</label>
              <input type="number" className={S.input} placeholder="0" value={form.basic_salary} onChange={e => set('basic_salary', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Housing Allowance (KES)</label>
              <input type="number" className={S.input} placeholder="0" value={form.housing_allowance} onChange={e => set('housing_allowance', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Transport Allowance (KES)</label>
              <input type="number" className={S.input} placeholder="0" value={form.transport_allowance} onChange={e => set('transport_allowance', e.target.value)} />
            </div>

            <Section title="Statutory Details" />
            <div>
              <label className={S.label}>KRA PIN</label>
              <input className={S.input} placeholder="A000000000X" value={form.kra_pin} onChange={e => set('kra_pin', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>NSSF Number</label>
              <input className={S.input} value={form.nssf_number} onChange={e => set('nssf_number', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>SHA Number</label>
              <input className={S.input} value={form.sha_number} onChange={e => set('sha_number', e.target.value)} />
            </div>

            <Section title="Bank Details" />
            <div>
              <label className={S.label}>Bank Name</label>
              <input className={S.input} placeholder="e.g. Equity Bank" value={form.bank_name} onChange={e => set('bank_name', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Account Number</label>
              <input className={S.input} value={form.bank_account} onChange={e => set('bank_account', e.target.value)} />
            </div>
            <div>
              <label className={S.label}>Branch</label>
              <input className={S.input} value={form.bank_branch} onChange={e => set('bank_branch', e.target.value)} />
            </div>
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-600">{error}</div>
          )}
        </div>

        <div className="flex gap-3 px-6 py-4 border-t border-border">
          <button onClick={onClose} className={S.btnSec}>Cancel</button>
          <button onClick={handleSave} disabled={saving} className={S.btnPri}>
            {saving ? <><Icon name="Loader" size={14} color="currentColor" className="animate-spin" /> Saving…</> : <><Icon name="CheckCircle" size={14} color="currentColor" /> {isEdit ? 'Save Changes' : 'Add Employee'}</>}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// EMPLOYEE DETAIL DRAWER
// ─────────────────────────────────────────────────────────────────────────────
const EmployeeDetail = ({ employee, payrollHistory, onEdit, onClose }) => {
  const gross = parseFloat(employee.basic_salary || 0) + parseFloat(employee.housing_allowance || 0) + parseFloat(employee.transport_allowance || 0);

  const Row = ({ label, value }) => (
    <div className="flex justify-between items-center py-2.5 border-b border-border">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground text-right max-w-48 truncate">{value || '—'}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end md:items-center justify-end p-0 md:p-4">
      <div className="bg-card border-l border-border w-full md:w-[480px] h-full md:h-auto md:max-h-[90vh] flex flex-col shadow-2xl md:rounded-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <span className="text-base font-bold text-primary">{employee.full_name?.charAt(0)}</span>
            </div>
            <div>
              <p className="font-bold text-foreground">{employee.full_name}</p>
              <p className="text-xs text-muted-foreground capitalize">{(employee.role || '').replace(/_/g, ' ')} · {employee.department || '—'}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={onEdit} className={S.btnSec + ' text-xs py-1.5'}>
              <Icon name="Edit" size={13} color="currentColor" /> Edit
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
              <Icon name="X" size={18} color="var(--muted-foreground)" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-1 px-6 py-4 space-y-5">
          {/* Status + type */}
          <div className="flex gap-2">
            <Badge status={employee.is_active} />
            <Badge status={employee.employment_type} />
          </div>

          {/* Compensation */}
          <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Compensation</p>
            <div className="grid grid-cols-3 gap-3 text-center">
              {[
                { label: 'Basic Salary',    value: fmt(employee.basic_salary) },
                { label: 'Housing',         value: fmt(employee.housing_allowance) },
                { label: 'Transport',       value: fmt(employee.transport_allowance) },
              ].map(({ label, value }) => (
                <div key={label} className="bg-card rounded-lg p-2.5">
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className="text-sm font-bold font-mono text-foreground mt-0.5">{value}</p>
                </div>
              ))}
            </div>
            <div className="flex justify-between items-center mt-3 pt-3 border-t border-primary/20">
              <span className="text-sm font-bold text-foreground">Gross Package</span>
              <span className="text-lg font-black font-mono text-primary">{fmt(gross)}</span>
            </div>
          </div>

          {/* Personal */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Personal</p>
            <Row label="Email"       value={employee.email} />
            <Row label="Phone"       value={employee.phone} />
            <Row label="National ID" value={employee.national_id} />
            <Row label="Date Joined" value={fmtDate(employee.date_joined)} />
            <Row label="Leave Balance" value={`${employee.leave_balance ?? 21} days`} />
          </div>

          {/* Statutory */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Statutory</p>
            <Row label="KRA PIN"     value={employee.kra_pin} />
            <Row label="NSSF No."    value={employee.nssf_number} />
            <Row label="SHA No."     value={employee.sha_number} />
          </div>

          {/* Bank */}
          <div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Bank Details</p>
            <Row label="Bank"    value={employee.bank_name} />
            <Row label="Account" value={employee.bank_account} />
            <Row label="Branch"  value={employee.bank_branch} />
          </div>

          {/* Payroll history */}
          {payrollHistory.length > 0 && (
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Recent Payroll</p>
              {payrollHistory.slice(0, 4).map(p => (
                <div key={p.id} className="flex justify-between items-center py-2.5 border-b border-border">
                  <span className="text-xs text-muted-foreground">{p.pay_month}</span>
                  <div className="text-right">
                    <p className="text-sm font-mono font-semibold text-emerald-600">{fmt(p.net_salary)}</p>
                    <p className="text-xs text-muted-foreground">Gross {fmt(p.gross_salary)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
const HRPage = () => {
  const [employees,      setEmployees]      = useState([]);
  const [payrollRecords, setPayrollRecords] = useState([]);
  const [loading,        setLoading]        = useState(true);
  const [adminId,        setAdminId]        = useState(null);
  const [search,         setSearch]         = useState('');
  const [deptFilter,     setDeptFilter]     = useState('all');
  const [selected,       setSelected]       = useState(null);
  const [showModal,      setShowModal]      = useState(false);
  const [editEmployee,   setEditEmployee]   = useState(null);
  const [activeTab,      setActiveTab]      = useState('employees');
  const adminIdRef = useRef(null);

  const resolveAdminId = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;
    const { data: profile } = await supabase.from('user_profiles').select('id, role, admin_id').eq('id', user.id).single();
    return profile?.role === 'admin' ? user.id : (profile?.admin_id || user.id);
  }, []);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const aId = await resolveAdminId();
    setAdminId(aId);
    adminIdRef.current = aId;
    if (!aId) { setLoading(false); return; }

    const [empRes, payRes] = await Promise.all([
      supabase.from('user_profiles')
        .select('id, full_name, email, role, department, phone, is_active, employment_type, date_joined, leave_balance, basic_salary, housing_allowance, transport_allowance, kra_pin, nssf_number, sha_number, national_id, bank_name, bank_account, bank_branch')
        .eq('admin_id', aId)
        .not('role', 'in', '("client","super_admin")')
        .order('full_name'),
      supabase.from('payroll_records')
        .select('id, employee_id, pay_month, gross_salary, net_salary, paye, nssf, shif, status')
        .eq('admin_id', aId)
        .order('pay_month', { ascending: false })
        .limit(200),
    ]);

    setEmployees(empRes.data || []);
    setPayrollRecords(payRes.data || []);
    setLoading(false);
  }, [resolveAdminId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const filtered = employees.filter(e => {
    const q = search.toLowerCase();
    const matchSearch = !search || e.full_name.toLowerCase().includes(q) || e.email.toLowerCase().includes(q) || (e.department || '').toLowerCase().includes(q);
    const matchDept = deptFilter === 'all' || e.department === deptFilter;
    return matchSearch && matchDept;
  });

  const depts = [...new Set(employees.map(e => e.department).filter(Boolean))];

  const empPayroll = (empId) => payrollRecords.filter(p => p.employee_id === empId);

  // KPI totals
  const totalPayroll = employees.reduce((s, e) => s + parseFloat(e.basic_salary || 0) + parseFloat(e.housing_allowance || 0) + parseFloat(e.transport_allowance || 0), 0);
  const activeCount  = employees.filter(e => e.is_active).length;

  return (
    <MainLayout>
      <div className="p-6 space-y-6">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black text-foreground tracking-tight">HR Management</h1>
            <p className="text-sm text-muted-foreground mt-1">Employee records, compensation and statutory details</p>
          </div>
          <button className={S.btnPri} onClick={() => { setEditEmployee(null); setShowModal(true); }}>
            <Icon name="UserPlus" size={15} color="currentColor" /> Add Employee
          </button>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Employees', value: employees.length, icon: 'Users',       bg: 'bg-blue-100 dark:bg-blue-900/30',    color: '#3b82f6' },
            { label: 'Active',          value: activeCount,      icon: 'UserCheck',   bg: 'bg-emerald-100 dark:bg-emerald-900/30', color: '#10b981' },
            { label: 'Departments',     value: depts.length,     icon: 'Building2',   bg: 'bg-violet-100 dark:bg-violet-900/30', color: '#8b5cf6' },
            { label: 'Monthly Payroll', value: fmt(totalPayroll), icon: 'DollarSign', bg: 'bg-amber-100 dark:bg-amber-900/30',  color: '#f59e0b' },
          ].map(({ label, value, icon, bg, color }) => (
            <div key={label} className="bg-card border border-border rounded-xl p-5">
              {loading ? <Sk className="h-12 w-full" /> : (
                <>
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${bg}`}>
                      <Icon name={icon} size={15} color={color} />
                    </div>
                  </div>
                  <p className="text-2xl font-bold text-foreground font-mono">{value}</p>
                </>
              )}
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-border pb-1">
          {[
            { id: 'employees', label: 'Employee Records', icon: 'Users' },
            { id: 'payroll',   label: 'Payroll Summary',  icon: 'Receipt' },
          ].map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
                activeTab === t.id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}>
              <Icon name={t.icon} size={13} color="currentColor" />
              {t.label}
            </button>
          ))}
        </div>

        {/* ── EMPLOYEES TAB ─────────────────────────────────────────────── */}
        {activeTab === 'employees' && (
          <div className="space-y-4">
            {/* Filters */}
            <div className="flex flex-wrap gap-3">
              <div className="relative flex-1 min-w-48">
                <Icon name="Search" size={14} color="var(--muted-foreground)" className="absolute left-3 top-1/2 -translate-y-1/2" />
                <input className={`${S.input} pl-9`} placeholder="Search by name, email, department…" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <select className={`${S.select} w-auto`} value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
                <option value="all">All Departments</option>
                {depts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>

            {/* Table */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr>
                      {['Employee', 'Role', 'Department', 'Type', 'Gross Package', 'Leave', 'Status', ''].map(h => (
                        <th key={h} className={S.th}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      Array(5).fill(0).map((_, i) => (
                        <tr key={i}>{Array(8).fill(0).map((_, j) => <td key={j} className={S.td}><Sk className="h-4 w-full" /></td>)}</tr>
                      ))
                    ) : filtered.length === 0 ? (
                      <tr><td colSpan={8}>
                        <div className="flex flex-col items-center justify-center py-16">
                          <Icon name="Users" size={28} color="var(--muted-foreground)" />
                          <p className="text-sm font-medium text-foreground mt-3">No employees found</p>
                          <p className="text-xs text-muted-foreground">Click "Add Employee" to create the first record</p>
                        </div>
                      </td></tr>
                    ) : filtered.map(emp => {
                      const gross = parseFloat(emp.basic_salary || 0) + parseFloat(emp.housing_allowance || 0) + parseFloat(emp.transport_allowance || 0);
                      return (
                        <tr key={emp.id} className="hover:bg-muted/30 transition-colors cursor-pointer" onClick={() => setSelected(emp)}>
                          <td className={S.tdF}>
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <span className="text-xs font-bold text-primary">{emp.full_name?.charAt(0)}</span>
                              </div>
                              <div>
                                <p className="font-medium text-foreground">{emp.full_name}</p>
                                <p className="text-xs text-muted-foreground">{emp.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className={S.td + ' capitalize'}>{(emp.role || '').replace(/_/g, ' ')}</td>
                          <td className={S.td}>{emp.department || '—'}</td>
                          <td className={S.td}><Badge status={emp.employment_type} /></td>
                          <td className={`${S.td} font-mono font-semibold text-foreground`}>{fmt(gross)}</td>
                          <td className={S.td}>{emp.leave_balance ?? 21} days</td>
                          <td className={S.td}><Badge status={emp.is_active} /></td>
                          <td className={S.td}>
                            <button className="text-xs text-primary hover:underline" onClick={e => { e.stopPropagation(); setEditEmployee(emp); setShowModal(true); }}>
                              Edit
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── PAYROLL SUMMARY TAB ───────────────────────────────────────── */}
        {activeTab === 'payroll' && (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    {['Employee', 'Pay Month', 'Gross', 'PAYE', 'NSSF', 'SHA', 'Net Pay', 'Status'].map(h => (
                      <th key={h} className={S.th}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    Array(5).fill(0).map((_, i) => <tr key={i}>{Array(8).fill(0).map((_, j) => <td key={j} className={S.td}><Sk className="h-4 w-full" /></td>)}</tr>)
                  ) : payrollRecords.length === 0 ? (
                    <tr><td colSpan={8}>
                      <div className="flex flex-col items-center justify-center py-16">
                        <Icon name="Receipt" size={28} color="var(--muted-foreground)" />
                        <p className="text-sm font-medium text-foreground mt-3">No payroll records yet</p>
                        <p className="text-xs text-muted-foreground">Run payroll from the Finance Hub to see records here</p>
                      </div>
                    </td></tr>
                  ) : payrollRecords.map(p => {
                    const emp = employees.find(e => e.id === p.employee_id);
                    return (
                      <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                        <td className={S.tdF}>{emp?.full_name || '—'}</td>
                        <td className={S.td}>{p.pay_month}</td>
                        <td className={`${S.td} font-mono`}>{fmt(p.gross_salary)}</td>
                        <td className={`${S.td} font-mono text-red-500`}>({fmt(p.paye)})</td>
                        <td className={`${S.td} font-mono text-red-500`}>({fmt(p.nssf)})</td>
                        <td className={`${S.td} font-mono text-red-500`}>({fmt(p.shif)})</td>
                        <td className={`${S.td} font-mono font-bold text-emerald-600`}>{fmt(p.net_salary)}</td>
                        <td className={S.td}>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${
                            p.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}>{p.status}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Employee detail drawer */}
      {selected && (
        <EmployeeDetail
          employee={selected}
          payrollHistory={empPayroll(selected.id)}
          onEdit={() => { setEditEmployee(selected); setSelected(null); setShowModal(true); }}
          onClose={() => setSelected(null)}
        />
      )}

      {/* Add/Edit modal */}
      {showModal && (
        <EmployeeModal
          employee={editEmployee}
          adminId={adminIdRef.current || adminId}
          onClose={() => { setShowModal(false); setEditEmployee(null); }}
          onSaved={fetchAll}
        />
      )}
    </MainLayout>
  );
};

export default HRPage;
