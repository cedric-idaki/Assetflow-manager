import { useState, useRef, useEffect, useCallback } from "react";
import { supabase } from "../../lib/supabase";
import MainLayout from "../../layouts/MainLayout";

const fmt = (n) => `KES ${(parseFloat(n) || 0).toLocaleString("en-KE", { maximumFractionDigits: 0 })}`;
const fmtDate = (d) => d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const fmtDateTime = (d) => d ? new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

const MOCK_USER = { name: "Eric Nganga", role: "Administrator", email: "eric@signflowpro.co.ke", initials: "EN", plan: "Gold" };

const MOCK_DOCS = [
  { id: "SFP-20260428-1001", name: "Employment Contract — James M.", type: "PDF", pages: 4, status: "pending", signers: [{ name: "Eric Nganga", initials: "EN", signed: false, role: "Employer" }, { name: "James Mwangi", initials: "JM", signed: false, role: "Employee" }], sent: "2026-04-24", due: "2026-05-01", external: true, urgent: true },
  { id: "SFP-20260420-9821", name: "Q2 Financial Report 2025", type: "XLSX", pages: 12, status: "completed", signers: [{ name: "Finance Dept", initials: "FD", signed: true }, { name: "Eric Nganga", initials: "EN", signed: true }, { name: "M. Ochieng", initials: "MD", signed: true }], sent: "2026-04-20", due: "2026-04-22", external: false },
  { id: "SFP-20260418-0033", name: "Vendor Agreement — TechParts Ltd", type: "DOCX", pages: 8, status: "in_review", signers: [{ name: "V. Patel", initials: "VP", signed: false, role: "Vendor Rep" }], sent: "2026-04-18", due: "2026-05-05", external: true },
  { id: "SFP-20260412-0055", name: "NDA — Startup Partnership", type: "PDF", pages: 2, status: "completed", signers: [{ name: "Eric Nganga", initials: "EN", signed: true }, { name: "S. Patel", initials: "SP", signed: true }], sent: "2026-04-12", due: "2026-04-20", external: true },
  { id: "SFP-20260410-0071", name: "Board Resolution — Expansion", type: "PDF", pages: 3, status: "completed", signers: [{ name: "Dir 1", initials: "D1", signed: true }, { name: "Dir 2", initials: "D2", signed: true }, { name: "Dir 3", initials: "D3", signed: true }], sent: "2026-04-10", due: "2026-04-14", external: false },
  { id: "SFP-20260405-0088", name: "Lease Agreement — Office Space", type: "PDF", pages: 20, status: "expired", signers: [{ name: "Landlord", initials: "LM", signed: false }], sent: "2026-04-05", due: "2026-04-15", external: true },
  { id: "SFP-DRAFT-0099", name: "Purchase Order #4821", type: "DOCX", pages: 2, status: "draft", signers: [], sent: null, due: null, external: false },
  { id: "SFP-20260426-0101", name: "IT Policy Update v3", type: "PDF", pages: 2, status: "pending", signers: [{ name: "IT Admin", initials: "IT", signed: true }, { name: "Eric Nganga", initials: "EN", signed: false }], sent: "2026-04-26", due: "2026-05-10", external: false },
];

const AUDIT_EVENTS = [
  { id: 1, action: "Document Created & Uploaded", actor: "Eric Nganga", time: "Apr 20, 2026, 09:14 AM EAT", ip: "197.232.xx.xx", device: "MacBook Pro (Chrome 124)", detail: "Uploaded original XLSX, converted to PDF for signing", hash: "3a7f9e2b…d41c8e4f", status: "complete" },
  { id: 2, action: "Sent for Signature", actor: "Eric Nganga → Finance Dept., MD Office", time: "Apr 20, 2026, 09:22 AM EAT", ip: "197.232.xx.xx", device: "MacBook Pro (Chrome 124)", detail: "Sequential order set. Expiry: Apr 22, 2026", hash: "b82c5d1a…9f3e7b2c", status: "complete" },
  { id: 3, action: "Document Viewed", actor: "Janet Kamau (Finance)", time: "Apr 21, 2026, 10:05 AM EAT", ip: "154.123.xx.xx", device: "Windows 11 (Edge 123)", detail: "12 minutes viewing time", hash: "7d4e1b9c…2a6f8d3e", status: "view" },
  { id: 4, action: "Signed — Finance Department", actor: "Janet Kamau", time: "Apr 21, 2026, 10:18 AM EAT", ip: "154.123.xx.xx", device: "Windows 11 (Edge 123)", detail: "Auth: PIN + OTP (SMS to +254 7xx xxx x78)", hash: "e9a1c4f2…71d3b9e8", status: "signed" },
  { id: 5, action: "Signed — Managing Director", actor: "M. Ochieng (MD)", time: "Apr 22, 2026, 02:45 PM EAT", ip: "41.90.xx.xx", device: "iOS 18 (Safari)", detail: "Auth: PIN + OTP + Biometric (Face ID). All pages notarized.", hash: "c3b7a2f9…5e1d4c8b", status: "signed" },
  { id: 6, action: "Document Completed & Sealed", actor: "System", time: "Apr 22, 2026, 02:46 PM EAT", ip: "—", device: "—", detail: "All signatures verified. Company seal applied. PDF/A archived. Notifications sent to all parties.", hash: "a1b2c3d4…z9y8x7w6", status: "final" },
];

const NOTIFICATIONS = [
  { id: 1, type: "warning", title: "Security: Signature used on Board Resolution", detail: "IP: 41.107.xx.xx · Device: iPhone 15 · Apr 25, 2026", time: "5 min ago", read: false },
  { id: 2, type: "success", title: "James Mwangi completed signing Employment Contract", detail: "All required signatures collected · Ready to download", time: "1 hr ago", read: false },
  { id: 3, type: "info", title: "Vendor Agreement expires in 7 days", detail: "Janet Kamau hasn't signed yet · Send reminder?", time: "2 hrs ago", read: false },
  { id: 4, type: "info", title: "Invited to co-sign Partnership MOU", detail: "Requested by: ceo@partner.co.ke · Due: May 15", time: "Yesterday", read: true },
  { id: 5, type: "neutral", title: "NDA audit log exported by Finance", detail: "Exported as PDF · 6 events recorded", time: "Apr 24", read: true },
];

const PLAN_LIMITS = { Bronze: { external: 15, addon: 1200 }, Silver: { external: 38, addon: 2200 }, Gold: { external: 56, addon: 3200 } };
const CURRENT_EXTERNAL_USED = 23;
// ─── OTP MODAL ────────────────────────────────────────────────────────────────
function OTPModal({ signer, onVerified, onClose }) {
  const [step, setStep] = useState("enter_otp");
  const [otp, setOtp] = useState(["","","","","",""]);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [generatedOtp] = useState(() => String(Math.floor(100000 + Math.random() * 900000)));
  const refs = [useRef(),useRef(),useRef(),useRef(),useRef(),useRef()];

  const handleOtpChange = (i, val) => {
    if (!/^\d*$/.test(val)) return;
    const n = [...otp]; n[i] = val.slice(-1); setOtp(n);
    if (val && i < 5) refs[i+1].current?.focus();
  };
  const handleKeyDown = (i, e) => { if (e.key === "Backspace" && !otp[i] && i > 0) refs[i-1].current?.focus(); };
  const handleVerify = async () => {
    const entered = otp.join("");
    if (entered.length !== 6) { setError("Please enter the complete 6-digit OTP"); return; }
    if (!password.trim()) { setError("Please enter your signing password"); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    if (entered !== generatedOtp) { setError("Invalid OTP."); setLoading(false); return; }
    if (password.trim().length < 4) { setError("Invalid password."); setLoading(false); return; }
    setStep("verified"); setLoading(false);
    setTimeout(() => onVerified({ otp: entered, verifiedAt: new Date().toISOString(), ip: "197.232.xx.xx", device: navigator.userAgent.slice(0,50) }), 800);
  };
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",backdropFilter:"blur(4px)",zIndex:999,display:"flex",alignItems:"center",justifyContent:"center",padding:16 }}>
      <div style={{ background:"#fff",borderRadius:20,width:"100%",maxWidth:420,overflow:"hidden",boxShadow:"0 25px 60px rgba(0,0,0,0.3)" }}>
        <div style={{ background:"linear-gradient(135deg, #0F172A, #1E3A5F)",padding:"24px 28px" }}>
          <div style={{ fontSize:16,fontWeight:800,color:"#fff" }}>🔐 SignFlow Verification</div>
          <div style={{ fontSize:12,color:"#CBD5E1",marginTop:8 }}>Signing as: <strong style={{ color:"#60A5FA" }}>{signer?.name}</strong></div>
        </div>
        {step === "verified" ? (
          <div style={{ padding:32,textAlign:"center" }}>
            <div style={{ fontSize:48,marginBottom:12 }}>✅</div>
            <div style={{ fontSize:18,fontWeight:800,color:"#166534" }}>Identity Verified!</div>
            <div style={{ fontSize:13,color:"#6B7280",marginTop:8 }}>Applying your signature...</div>
          </div>
        ) : (
          <div style={{ padding:"24px 28px" }}>
            <div style={{ background:"#F0FDF4",border:"1px solid #BBF7D0",borderRadius:10,padding:"12px 16px",marginBottom:20 }}>
              <div style={{ fontSize:12,fontWeight:600,color:"#166534" }}>📱 Demo OTP: <strong>{generatedOtp}</strong></div>
            </div>
            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:12,fontWeight:600,color:"#374151",marginBottom:10 }}>Enter 6-Digit OTP</div>
              <div style={{ display:"flex",gap:8,justifyContent:"center" }}>
                {otp.map((digit, i) => (
                  <input key={i} ref={refs[i]} type="text" inputMode="numeric" maxLength={1} value={digit}
                    onChange={e => handleOtpChange(i, e.target.value)} onKeyDown={e => handleKeyDown(i, e)}
                    style={{ width:48,height:56,textAlign:"center",fontSize:22,fontWeight:700,border:`2px solid ${digit?"#1E3A5F":"#E5E7EB"}`,borderRadius:10,outline:"none",background:digit?"#EFF6FF":"#F9FAFB",color:"#1E3A5F" }} />
                ))}
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:12,fontWeight:600,color:"#374151",marginBottom:8 }}>Signing Password</div>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your signing password"
                style={{ width:"100%",padding:"10px 14px",border:"1.5px solid #E5E7EB",borderRadius:10,fontSize:13,outline:"none",boxSizing:"border-box" }} />
            </div>
            {error && <div style={{ background:"#FEF2F2",border:"1px solid #FECACA",borderRadius:8,padding:"10px 14px",fontSize:12,color:"#DC2626",marginBottom:16 }}>⚠️ {error}</div>}
            <div style={{ display:"flex",gap:10 }}>
              <button onClick={onClose} style={{ flex:1,padding:11,border:"1.5px solid #E5E7EB",borderRadius:10,background:"#fff",fontSize:13,fontWeight:600,color:"#6B7280",cursor:"pointer" }}>Cancel</button>
              <button onClick={handleVerify} disabled={loading} style={{ flex:2,padding:11,background:loading?"#94A3B8":"linear-gradient(135deg,#1E3A5F,#0369A1)",border:"none",borderRadius:10,fontSize:13,fontWeight:700,color:"#fff",cursor:loading?"not-allowed":"pointer" }}>
                {loading ? "Verifying..." : "Verify & Sign"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── SIGNATURE CANVAS ─────────────────────────────────────────────────────────
function SignatureCanvas({ onCapture }) {
  const canvasRef = useRef();
  const drawing = useRef(false);
  const [hasSign, setHasSign] = useState(false);
  const [mode, setMode] = useState("draw");
  const [typedSig, setTypedSig] = useState("");
  const FONTS = ["Dancing Script","Pacifico","Satisfy","Caveat"];
  const [font, setFont] = useState(FONTS[0]);
  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Pacifico&family=Satisfy&family=Caveat:wght@700&display=swap";
    document.head.appendChild(link);
  }, []);
  const getPos = (e, canvas) => { const r = canvas.getBoundingClientRect(); const t = e.touches ? e.touches[0] : e; return { x: t.clientX-r.left, y: t.clientY-r.top }; };
  const start = (e) => { e.preventDefault(); drawing.current=true; const canvas=canvasRef.current; const ctx=canvas.getContext("2d"); const {x,y}=getPos(e,canvas); ctx.beginPath(); ctx.moveTo(x,y); };
  const draw = (e) => { e.preventDefault(); if(!drawing.current) return; const canvas=canvasRef.current; const ctx=canvas.getContext("2d"); ctx.strokeStyle="#1E3A5F"; ctx.lineWidth=2.5; ctx.lineCap="round"; ctx.lineJoin="round"; const {x,y}=getPos(e,canvas); ctx.lineTo(x,y); ctx.stroke(); setHasSign(true); };
  const stop = () => { drawing.current=false; };
  const clear = () => { const canvas=canvasRef.current; canvas.getContext("2d").clearRect(0,0,canvas.width,canvas.height); setHasSign(false); };
  const capture = () => {
    if (mode==="draw") { if(!hasSign) return; onCapture({ type:"drawn", data:canvasRef.current.toDataURL() }); }
    else { if(!typedSig.trim()) return; onCapture({ type:"typed", data:typedSig, font }); }
  };
  return (
    <div style={{ background:"#F8FAFC",border:"1.5px solid #E2E8F0",borderRadius:14,overflow:"hidden" }}>
      <div style={{ display:"flex",borderBottom:"1px solid #E2E8F0" }}>
        {[{id:"draw",label:"✍️ Draw"},{id:"type",label:"⌨️ Type"},{id:"upload",label:"⬆️ Upload"}].map(m => (
          <button key={m.id} onClick={() => setMode(m.id)} style={{ flex:1,padding:10,fontSize:12,fontWeight:600,border:"none",cursor:"pointer",background:mode===m.id?"#fff":"#F1F5F9",color:mode===m.id?"#1E3A5F":"#64748B",borderBottom:mode===m.id?"2px solid #1E3A5F":"2px solid transparent" }}>{m.label}</button>
        ))}
      </div>
      {mode==="draw" && (
        <>
          <canvas ref={canvasRef} width={420} height={150} style={{ display:"block",cursor:"crosshair",touchAction:"none",width:"100%",background:"#fff" }}
            onMouseDown={start} onMouseMove={draw} onMouseUp={stop} onMouseLeave={stop} onTouchStart={start} onTouchMove={draw} onTouchEnd={stop} />
          <div style={{ padding:"8px 12px",display:"flex",justifyContent:"space-between",background:"#F8FAFC" }}>
            <span style={{ fontSize:11,color:"#94A3B8" }}>Draw your signature above</span>
            <button onClick={clear} style={{ fontSize:11,color:"#EF4444",background:"none",border:"none",cursor:"pointer",fontWeight:600 }}>Clear</button>
          </div>
        </>
      )}
      {mode==="type" && (
        <div style={{ padding:16,background:"#fff" }}>
          <input type="text" value={typedSig} onChange={e => setTypedSig(e.target.value)} placeholder="Type your full name" style={{ width:"100%",padding:"8px 12px",border:"1.5px solid #E2E8F0",borderRadius:8,fontSize:13,outline:"none",marginBottom:12,boxSizing:"border-box" }} />
          <div style={{ height:80,display:"flex",alignItems:"center",justifyContent:"center",background:"#F8FAFC",borderRadius:8,border:"1px dashed #CBD5E1",marginBottom:10 }}>
            <span style={{ fontFamily:font,fontSize:32,color:"#1E3A5F" }}>{typedSig || "Your Signature"}</span>
          </div>
          <div style={{ display:"flex",gap:6,flexWrap:"wrap" }}>
            {FONTS.map(f => <button key={f} onClick={() => setFont(f)} style={{ padding:"4px 10px",border:`1.5px solid ${font===f?"#1E3A5F":"#E2E8F0"}`,borderRadius:20,fontSize:11,cursor:"pointer",background:font===f?"#EFF6FF":"#fff",fontFamily:f,color:font===f?"#1E3A5F":"#6B7280" }}>{f.split(" ")[0]}</button>)}
          </div>
        </div>
      )}
      {mode==="upload" && <div style={{ padding:32,textAlign:"center",color:"#94A3B8",fontSize:13,background:"#fff" }}>Click to upload signature image (PNG/SVG)</div>}
      <div style={{ padding:"12px 16px",borderTop:"1px solid #E2E8F0" }}>
        <button onClick={capture} style={{ width:"100%",padding:11,background:"linear-gradient(135deg,#1E3A5F,#0369A1)",border:"none",borderRadius:10,fontSize:13,fontWeight:700,color:"#fff",cursor:"pointer" }}>Apply Signature</button>
      </div>
    </div>
  );
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function statusBadge(status) {
  const map = {
    pending: { label: "Pending", bg: "#FEF9C3", color: "#854D0E" },
    completed: { label: "Completed", bg: "#DCFCE7", color: "#166534" },
    in_review: { label: "In Review", bg: "#DBEAFE", color: "#1E40AF" },
    expired: { label: "Expired", bg: "#FEE2E2", color: "#991B1B" },
    draft: { label: "Draft", bg: "#F3F4F6", color: "#4B5563" },
  };
  const s = map[status] || map.draft;
  return (
    <span style={{ background: s.bg, color: s.color, fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 99, letterSpacing: 0.3 }}>
      {s.label}
    </span>
  );
}

function Avatar({ initials, size = 32, color = "#1E3A5F" }) {
  const colors = { EN: "#1E3A5F", JM: "#0369A1", FD: "#166534", MD: "#5B21B6", VP: "#9A3412", SP: "#0F766E", LM: "#92400E", IT: "#1D4ED8", D1: "#6D28D9", D2: "#BE185D", D3: "#065F46" };
  const bg = colors[initials] || color;
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: size * 0.35, fontWeight: 700, flexShrink: 0, fontFamily: "Georgia, serif", letterSpacing: 0.5 }}>
      {initials}
    </div>
  );
}

function FileIcon({ type }) {
  const colors = { PDF: "#DC2626", DOCX: "#2563EB", XLSX: "#16A34A" };
  return (
    <div style={{ width: 36, height: 44, background: colors[type] || "#6B7280", borderRadius: 4, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0, position: "relative" }}>
      <div style={{ position: "absolute", top: 0, right: 0, width: 10, height: 10, background: "rgba(255,255,255,0.35)", borderBottomLeftRadius: 4 }} />
      <span style={{ color: "#fff", fontSize: 9, fontWeight: 800, letterSpacing: 0.5 }}>{type}</span>
    </div>
  );
}

// ─── SIDEBAR ─────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", icon: "⊞", label: "Dashboard" },
  { id: "documents", icon: "📄", label: "All Documents" },
  { id: "sign", icon: "✍️", label: "Sign a Document" },
  { id: "upload", icon: "⬆", label: "Upload & Convert" },
  { id: "workflow", icon: "⛓", label: "Approval Chains" },
  { id: "cosign", icon: "👥", label: "Co-Signing" },
  { id: "audit", icon: "🔍", label: "Audit Trail" },
  { id: "notifications", icon: "🔔", label: "Notifications" },
  { id: "settings", icon: "⚙", label: "Settings" },
];

function Sidebar({ active, setActive, notifCount }) {
  return (
    <div style={{ width: 230, background: "#0F172A", height: "100vh", display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0 }}>
      <div style={{ padding: "24px 20px 16px" }}>
        <div style={{ fontSize: 20, fontWeight: 800, color: "#60A5FA", letterSpacing: -0.5, fontFamily: "Georgia, serif" }}>SignFlowPro</div>
        <div style={{ fontSize: 10, color: "#475569", letterSpacing: 1.5, marginTop: 2, textTransform: "uppercase" }}>Document Signing</div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
        {NAV.map(n => (
          <button key={n.id} onClick={() => setActive(n.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 20px", background: active === n.id ? "rgba(96,165,250,0.15)" : "transparent", border: "none", borderLeft: active === n.id ? "3px solid #60A5FA" : "3px solid transparent", color: active === n.id ? "#93C5FD" : "#64748B", fontSize: 13, cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
            <span style={{ fontSize: 14 }}>{n.icon}</span>
            {n.label}
            {n.id === "notifications" && notifCount > 0 && <span style={{ marginLeft: "auto", background: "#EF4444", color: "#fff", fontSize: 10, fontWeight: 700, borderRadius: 99, padding: "1px 6px" }}>{notifCount}</span>}
          </button>
        ))}
      </div>
      <div style={{ padding: "16px 20px", borderTop: "1px solid #1E293B" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Avatar initials="EN" size={34} />
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#E2E8F0" }}>{MOCK_USER.name}</div>
            <div style={{ fontSize: 10, color: "#475569" }}>{MOCK_USER.role}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ docs, setActive, setSelectedDoc }) {
  const completed = docs.filter(d => d.status === "completed").length;
  const pending = docs.filter(d => d.status === "pending").length;
  const total = docs.length;
  const signers = 34;
  const planLimit = PLAN_LIMITS[MOCK_USER.plan].external;
  const pct = Math.round((CURRENT_EXTERNAL_USED / planLimit) * 100);

  const recentDocs = docs.filter(d => d.status !== "draft").slice(0, 5);

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "#1E293B", letterSpacing: -0.5 }}>Dashboard</h1>
          <div style={{ fontSize: 13, color: "#94A3B8", marginTop: 2 }}>Tuesday, April 28, 2026</div>
        </div>
        <button onClick={() => setActive("upload")} style={{ background: "#1E3A5F", color: "#fff", border: "none", padding: "10px 20px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
          + New Document
        </button>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28 }}>
        {[
          { label: "Total Documents", val: total, sub: "+12 this month", color: "#1E3A5F" },
          { label: "Completed", val: completed, sub: `${Math.round((completed / total) * 100)}% completion rate`, color: "#166534" },
          { label: "Awaiting", val: pending, sub: "2 urgent (expiring soon)", color: "#854D0E" },
          { label: "Team Signatories", val: signers, sub: "Active team members", color: "#5B21B6" },
        ].map(s => (
          <div key={s.label} style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: "18px 20px", borderTop: `3px solid ${s.color}` }}>
            <div style={{ fontSize: 11, color: "#94A3B8", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontSize: 30, fontWeight: 800, color: s.color, lineHeight: 1 }}>{s.val}</div>
            <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 6 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
        {/* Recent Docs */}
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12 }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid #F1F5F9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontWeight: 700, fontSize: 14, color: "#1E293B" }}>Recent Documents</span>
            <button onClick={() => setActive("documents")} style={{ fontSize: 12, color: "#0EA5E9", background: "none", border: "none", cursor: "pointer" }}>View all →</button>
          </div>
          {recentDocs.map(doc => (
            <div key={doc.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 20px", borderBottom: "1px solid #F8FAFC", cursor: "pointer" }}
              onClick={() => { setSelectedDoc(doc); setActive("documents"); }}>
              <FileIcon type={doc.type} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#1E293B", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{doc.name}</div>
                <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 2 }}>{doc.type} · {doc.pages} pages</div>
              </div>
              <div style={{ display: "flex", gap: -6, marginRight: 8 }}>
                {doc.signers.slice(0, 3).map((s, i) => (
                  <div key={i} style={{ marginLeft: i ? -8 : 0, border: "2px solid #fff", borderRadius: "50%" }}><Avatar initials={s.initials} size={24} /></div>
                ))}
              </div>
              {statusBadge(doc.status)}
            </div>
          ))}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* External Signing Usage */}
          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: "18px 20px" }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 4 }}>External Signing Usage</div>
            <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 12 }}>{MOCK_USER.plan} Plan · {CURRENT_EXTERNAL_USED}/{planLimit} docs used</div>
            <div style={{ background: "#F1F5F9", borderRadius: 99, height: 8, overflow: "hidden" }}>
              <div style={{ width: `${pct}%`, height: "100%", background: pct > 85 ? "#EF4444" : pct > 65 ? "#F59E0B" : "#10B981", borderRadius: 99, transition: "width 0.5s" }} />
            </div>
            <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 6 }}>{planLimit - CURRENT_EXTERNAL_USED} remaining · KES 25/doc overage</div>
          </div>

          {/* Signing Progress */}
          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: "18px 20px" }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Signing Progress</div>
            {docs.filter(d => d.status === "pending" || d.status === "in_review").slice(0, 3).map(doc => {
              const signed = doc.signers.filter(s => s.signed).length;
              const total = doc.signers.length || 1;
              const pct = Math.round((signed / total) * 100);
              return (
                <div key={doc.id} style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: "#64748B", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{doc.name.split("—")[0].trim()}</span>
                    <span style={{ fontSize: 11, color: "#94A3B8" }}>{signed}/{total}</span>
                  </div>
                  <div style={{ background: "#F1F5F9", borderRadius: 99, height: 6 }}>
                    <div style={{ width: `${pct}%`, height: "100%", background: "#0EA5E9", borderRadius: 99 }} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Actions */}
          <div style={{ background: "#1E3A5F", borderRadius: 12, padding: "18px 20px" }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#93C5FD", marginBottom: 12 }}>Quick Actions</div>
            {[
              { label: "Upload New Document", icon: "⬆", page: "upload" },
              { label: "View Audit Trail", icon: "🔍", page: "audit" },
              { label: "Manage Team", icon: "👥", page: "settings" },
            ].map(a => (
              <button key={a.label} onClick={() => setActive(a.page)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.08)", border: "none", borderRadius: 8, padding: "8px 12px", color: "#CBD5E1", fontSize: 12, cursor: "pointer", marginBottom: 6, textAlign: "left" }}>
                <span>{a.icon}</span>{a.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── DOCUMENTS LIST ───────────────────────────────────────────────────────────
function Documents({ docs, setDocs, setActive }) {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [showAudit, setShowAudit] = useState(false);

  const filtered = docs.filter(d => {
    const matchFilter = filter === "all" || d.status === filter || (filter === "draft" && d.status === "draft");
    const matchSearch = d.name.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  function handleAction(doc, action) {
    if (action === "audit") { setSelected(doc); setShowAudit(true); }
    else if (action === "sign") { setActive("sign"); }
    else if (action === "resend") {
      setDocs(prev => prev.map(d => d.id === doc.id ? { ...d, status: "pending" } : d));
    }
  }

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      {showAudit && selected ? (
        <AuditModal doc={selected} onClose={() => setShowAudit(false)} />
      ) : (
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1E293B" }}>All Documents</h1>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search documents..." style={{ padding: "8px 14px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 13, width: 220, outline: "none" }} />
          </div>

          <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
            {[["all", "All"], ["pending", "Pending"], ["completed", "Completed"], ["in_review", "In Review"], ["draft", "Drafts"], ["expired", "Expired"]].map(([val, label]) => (
              <button key={val} onClick={() => setFilter(val)} style={{ padding: "6px 14px", borderRadius: 99, fontSize: 12, fontWeight: 600, border: filter === val ? "none" : "1px solid #E2E8F0", background: filter === val ? "#1E3A5F" : "#fff", color: filter === val ? "#fff" : "#64748B", cursor: "pointer" }}>
                {label}
              </button>
            ))}
          </div>

          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, overflow: "hidden" }}>
            <div style={{ display: "grid", gridTemplateColumns: "2fr 80px 120px 100px 90px 130px", gap: 0, padding: "10px 20px", background: "#F8FAFC", borderBottom: "1px solid #E2E8F0" }}>
              {["Name", "Type", "Status", "Signers", "Due Date", "Action"].map(h => (
                <div key={h} style={{ fontSize: 11, fontWeight: 700, color: "#94A3B8", textTransform: "uppercase", letterSpacing: 0.6 }}>{h}</div>
              ))}
            </div>
            {filtered.map(doc => (
              <div key={doc.id} style={{ display: "grid", gridTemplateColumns: "2fr 80px 120px 100px 90px 130px", gap: 0, padding: "14px 20px", borderBottom: "1px solid #F8FAFC", alignItems: "center" }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <FileIcon type={doc.type} />
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#1E293B" }}>{doc.name}</div>
                    <div style={{ fontSize: 11, color: "#94A3B8" }}>{doc.id}</div>
                  </div>
                </div>
                <div style={{ fontSize: 12, color: "#64748B" }}>{doc.type} · {doc.pages}p</div>
                <div>{statusBadge(doc.status)}</div>
                <div style={{ display: "flex", gap: -4 }}>
                  {doc.signers.slice(0, 4).map((s, i) => (
                    <div key={i} style={{ marginLeft: i ? -6 : 0, border: "2px solid #fff", borderRadius: "50%" }} title={s.name}><Avatar initials={s.initials} size={26} /></div>
                  ))}
                </div>
                <div style={{ fontSize: 12, color: doc.status === "expired" ? "#EF4444" : "#64748B" }}>{doc.due ? doc.due.split("-").reverse().join("/") : "—"}</div>
                <div style={{ display: "flex", gap: 6 }}>
                  {doc.status === "pending" && <button onClick={() => handleAction(doc, "sign")} style={{ padding: "4px 10px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>Sign</button>}
                  {doc.status === "completed" && <button onClick={() => handleAction(doc, "audit")} style={{ padding: "4px 10px", background: "#DCFCE7", color: "#166534", border: "none", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>Audit</button>}
                  {doc.status === "expired" && <button onClick={() => handleAction(doc, "resend")} style={{ padding: "4px 10px", background: "#FEF9C3", color: "#854D0E", border: "none", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>Resend</button>}
                  {["in_review", "draft"].includes(doc.status) && <button onClick={() => handleAction(doc, "view")} style={{ padding: "4px 10px", background: "#F1F5F9", color: "#475569", border: "none", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>View</button>}
                </div>
              </div>
            ))}
            {filtered.length === 0 && <div style={{ padding: 40, textAlign: "center", color: "#94A3B8", fontSize: 14 }}>No documents found</div>}
          </div>
        </>
      )}
    </div>
  );
}

// ─── AUDIT MODAL ──────────────────────────────────────────────────────────────
function AuditModal({ doc, onClose }) {
  const events = doc.id === "SFP-20260420-9821" ? AUDIT_EVENTS : AUDIT_EVENTS.slice(0, 3);
  const statusColors = { complete: "#0EA5E9", view: "#8B5CF6", signed: "#10B981", final: "#1E3A5F" };
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#0EA5E9", cursor: "pointer", fontSize: 13, marginBottom: 8, padding: 0 }}>← Back to Documents</button>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800, color: "#1E293B" }}>Audit Trail — {doc.name}</h2>
          <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>Document ID: {doc.id} · SHA-256 verified</div>
        </div>
        <button style={{ padding: "8px 16px", background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer", color: "#475569" }}>Export PDF</button>
      </div>
      <div style={{ position: "relative" }}>
        <div style={{ position: "absolute", left: 19, top: 0, bottom: 0, width: 2, background: "#E2E8F0" }} />
        {events.map((ev, i) => (
          <div key={ev.id} style={{ display: "flex", gap: 16, marginBottom: 20, position: "relative" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: statusColors[ev.status] || "#94A3B8", border: "3px solid #fff", boxShadow: "0 0 0 2px " + (statusColors[ev.status] || "#94A3B8"), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, zIndex: 1 }}>
              <span style={{ fontSize: 14, color: "#fff" }}>{ev.status === "signed" ? "✓" : ev.status === "view" ? "👁" : ev.status === "final" ? "🔒" : "●"}</span>
            </div>
            <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, padding: "14px 18px", flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 4 }}>{ev.action}</div>
              <div style={{ fontSize: 12, color: "#64748B", marginBottom: 6 }}>By: {ev.actor} · {ev.time}</div>
              <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 6 }}>IP: {ev.ip} · Device: {ev.device}</div>
              <div style={{ fontSize: 11, color: "#475569", marginBottom: 8 }}>{ev.detail}</div>
              <div style={{ background: "#F8FAFC", borderRadius: 6, padding: "6px 10px", fontFamily: "monospace", fontSize: 11, color: "#64748B" }}>
                hash: {ev.hash} {ev.status === "final" && <span style={{ color: "#166534", fontWeight: 700 }}>· IMMUTABLE</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── SIGN DOCUMENT ────────────────────────────────────────────────────────────
function SignDocument({ docs }) {
  const [step, setStep] = useState(1);
  const [pin, setPin] = useState("");
  const [otp, setOtp] = useState("");
  const [otpTimer, setOtpTimer] = useState(45);
  const [sigMode, setSigMode] = useState("draw");
  const [typedSig, setTypedSig] = useState("Eric Nganga");
  const [isDrawing, setIsDrawing] = useState(false);
  const [signed, setSigned] = useState(false);
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const pendingDoc = docs.find(d => d.status === "pending" && d.signers.some(s => s.initials === "EN" && !s.signed));

  useEffect(() => {
    if (step === 2) {
      const t = setInterval(() => setOtpTimer(p => p > 0 ? p - 1 : 0), 1000);
      return () => clearInterval(t);
    }
  }, [step]);

  useEffect(() => {
    if (step === 3 && sigMode === "draw" && canvasRef.current) {
      const canvas = canvasRef.current;
      canvas.width = canvas.offsetWidth;
      canvas.height = 140;
      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = "#1E3A5F";
      ctx.lineWidth = 2.5;
      ctx.lineCap = "round";
      ctxRef.current = ctx;
    }
  }, [step, sigMode]);

  function startDraw(e) {
    if (!ctxRef.current) return;
    setIsDrawing(true);
    const r = canvasRef.current.getBoundingClientRect();
    ctxRef.current.beginPath();
    ctxRef.current.moveTo(e.clientX - r.left, e.clientY - r.top);
  }
  function draw(e) {
    if (!isDrawing || !ctxRef.current) return;
    const r = canvasRef.current.getBoundingClientRect();
    ctxRef.current.lineTo(e.clientX - r.left, e.clientY - r.top);
    ctxRef.current.stroke();
  }
  function stopDraw() { setIsDrawing(false); }
  function clearCanvas() { if (ctxRef.current && canvasRef.current) ctxRef.current.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height); }

  function handlePin(d) {
    if (d === "CLR") return setPin("");
    if (d === "⌫") return setPin(p => p.slice(0, -1));
    if (pin.length < 6) setPin(p => p + d);
  }

  const steps = ["Upload", "Place Fields", "Authenticate", "Sign", "Send"];

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Sign a Document</h1>
      <div style={{ fontSize: 13, color: "#94A3B8", marginBottom: 28 }}>{pendingDoc ? `Signing: ${pendingDoc.name}` : "No pending signatures"}</div>

      {/* Progress Steps */}
      <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: 32, background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: "14px 20px" }}>
        {steps.map((s, i) => (
          <div key={s} style={{ display: "flex", alignItems: "center", flex: i < steps.length - 1 ? 1 : 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: step > i + 1 ? "#10B981" : step === i + 1 ? "#1E3A5F" : "#F1F5F9", color: step > i + 1 ? "#fff" : step === i + 1 ? "#fff" : "#94A3B8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>
                {step > i + 1 ? "✓" : i + 1}
              </div>
              <span style={{ fontSize: 12, color: step === i + 1 ? "#1E3A5F" : "#94A3B8", fontWeight: step === i + 1 ? 700 : 400 }}>{s}</span>
            </div>
            {i < steps.length - 1 && <div style={{ flex: 1, height: 1, background: step > i + 1 ? "#10B981" : "#E2E8F0", margin: "0 8px" }} />}
          </div>
        ))}
      </div>

      {signed ? (
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 48, textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
          <h2 style={{ color: "#166534", fontWeight: 800, fontSize: 22, margin: "0 0 8px" }}>Document Signed Successfully!</h2>
          <p style={{ color: "#64748B", fontSize: 14 }}>Your signature has been cryptographically hashed and time-stamped. All parties will receive a notification.</p>
          <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 8, padding: "12px 20px", display: "inline-block", marginTop: 12, fontFamily: "monospace", fontSize: 12, color: "#166534" }}>
            sig: {Math.random().toString(36).substring(2, 10)}…{Math.random().toString(36).substring(2, 10)} · VALID
          </div>
          <div style={{ marginTop: 20 }}>
            <button onClick={() => { setStep(1); setPin(""); setOtp(""); setSigned(false); }} style={{ padding: "10px 24px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Sign Another Document</button>
          </div>
        </div>
      ) : step === 1 ? (
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 32 }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 16, color: "#1E293B" }}>Enter your PIN to proceed</h3>
          <div style={{ display: "flex", gap: 10, marginBottom: 24, justifyContent: "center" }}>
            {[0, 1, 2, 3, 4, 5].map(i => (
              <div key={i} style={{ width: 44, height: 44, borderRadius: 8, border: "2px solid", borderColor: pin.length > i ? "#1E3A5F" : "#E2E8F0", background: pin.length > i ? "#EFF6FF" : "#F8FAFC", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: "#1E3A5F" }}>
                {pin.length > i ? "●" : ""}
              </div>
            ))}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, maxWidth: 240, margin: "0 auto 24px" }}>
            {["1","2","3","4","5","6","7","8","9","CLR","0","⌫"].map(d => (
              <button key={d} onClick={() => handlePin(d)} style={{ padding: "14px", background: d === "CLR" ? "#FEF9C3" : d === "⌫" ? "#FEE2E2" : "#F1F5F9", border: "none", borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: "pointer", color: "#1E293B" }}>{d}</button>
            ))}
          </div>
          <button onClick={() => pin.length >= 4 && setStep(2)} disabled={pin.length < 4} style={{ width: "100%", padding: 12, background: pin.length >= 4 ? "#1E3A5F" : "#E2E8F0", color: pin.length >= 4 ? "#fff" : "#94A3B8", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: pin.length >= 4 ? "pointer" : "not-allowed" }}>
            Verify PIN →
          </button>
        </div>
      ) : step === 2 ? (
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 32 }}>
          <h3 style={{ margin: "0 0 8px", fontSize: 16, color: "#1E293B" }}>OTP Verification</h3>
          <p style={{ fontSize: 13, color: "#64748B", margin: "0 0 20px" }}>Enter the 6-digit code sent to +254 7** *** *78</p>
          <input value={otp} onChange={e => setOtp(e.target.value.slice(0, 6))} placeholder="000000" style={{ width: "100%", textAlign: "center", fontSize: 28, letterSpacing: 12, padding: "16px", border: "2px solid #E2E8F0", borderRadius: 8, outline: "none", fontWeight: 700, color: "#1E3A5F", boxSizing: "border-box" }} />
          <div style={{ fontSize: 12, color: "#94A3B8", textAlign: "center", margin: "12px 0" }}>
            {otpTimer > 0 ? `Resend code in 00:${String(otpTimer).padStart(2, "0")}` : <button onClick={() => setOtpTimer(45)} style={{ background: "none", border: "none", color: "#0EA5E9", cursor: "pointer", fontSize: 12 }}>Resend Code</button>}
          </div>
          <button onClick={() => (otp.length === 6 || otp === "") && setStep(3)} style={{ width: "100%", padding: 12, background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
            Verify & Proceed →
          </button>
        </div>
      ) : step === 3 ? (
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 28 }}>
          <h3 style={{ margin: "0 0 16px", fontSize: 16, color: "#1E293B" }}>Place Your Signature</h3>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            {["draw", "type", "upload"].map(m => (
              <button key={m} onClick={() => setSigMode(m)} style={{ flex: 1, padding: "8px", borderRadius: 8, border: sigMode === m ? "2px solid #1E3A5F" : "1px solid #E2E8F0", background: sigMode === m ? "#EFF6FF" : "#fff", color: sigMode === m ? "#1E3A5F" : "#64748B", fontSize: 12, fontWeight: 600, cursor: "pointer", textTransform: "capitalize" }}>{m}</button>
            ))}
          </div>
          {sigMode === "draw" && (
            <>
              <canvas ref={canvasRef} onMouseDown={startDraw} onMouseMove={draw} onMouseUp={stopDraw} onMouseLeave={stopDraw} style={{ width: "100%", height: 140, border: "2px dashed #CBD5E1", borderRadius: 8, cursor: "crosshair", display: "block" }} />
              <button onClick={clearCanvas} style={{ marginTop: 8, fontSize: 12, color: "#94A3B8", background: "none", border: "none", cursor: "pointer" }}>Clear</button>
            </>
          )}
          {sigMode === "type" && (
            <div style={{ border: "2px dashed #CBD5E1", borderRadius: 8, padding: 20, textAlign: "center" }}>
              <input value={typedSig} onChange={e => setTypedSig(e.target.value)} style={{ border: "none", outline: "none", fontSize: 32, fontFamily: "Georgia, serif", color: "#1E3A5F", textAlign: "center", width: "100%" }} />
            </div>
          )}
          {sigMode === "upload" && (
            <div style={{ border: "2px dashed #CBD5E1", borderRadius: 8, padding: 32, textAlign: "center", color: "#94A3B8", fontSize: 13 }}>
              Click to upload signature image (PNG/SVG)
            </div>
          )}
          <div style={{ background: "#F0F9FF", borderRadius: 8, padding: "10px 14px", fontSize: 11, color: "#0369A1", marginTop: 16, marginBottom: 16 }}>
            🔒 Your signature will be cryptographically hashed and time-stamped. Any tampering will invalidate the document.
          </div>
          <button onClick={() => setSigned(true)} style={{ width: "100%", padding: 12, background: "#166534", color: "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
            ✓ Confirm & Sign Document
          </button>
        </div>
      ) : null}
    </div>
  );
}

// ─── UPLOAD ────────────────────────────────────────────────────────────────────
function Upload({ setDocs, setActive }) {
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState(null);
  const [signers, setSigners] = useState([{ email: "", role: "Signer" }]);
  const [order, setOrder] = useState("sequential");
  const [sent, setSent] = useState(false);

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) setFile(f);
  }

  function handleSend() {
    if (!file) return;
    const newDoc = {
      id: `SFP-${Date.now()}`,
      name: file.name.replace(/\.[^.]+$/, ""),
      type: file.name.split(".").pop().toUpperCase(),
      pages: Math.floor(Math.random() * 10) + 1,
      status: "pending",
      signers: signers.filter(s => s.email).map(s => ({ name: s.email.split("@")[0], initials: s.email.slice(0, 2).toUpperCase(), signed: false, role: s.role })),
      sent: new Date().toISOString().split("T")[0],
      due: new Date(Date.now() + 7 * 864e5).toISOString().split("T")[0],
      external: true,
    };
    setDocs(prev => [newDoc, ...prev]);
    setSent(true);
  }

  if (sent) return (
    <div style={{ padding: "32px 36px", flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center", maxWidth: 400 }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>📨</div>
        <h2 style={{ color: "#1E3A5F", fontWeight: 800, margin: "0 0 8px" }}>Document Sent!</h2>
        <p style={{ color: "#64748B", fontSize: 14 }}>Secure signing links have been dispatched to all signers. You'll be notified when each party signs.</p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 20 }}>
          <button onClick={() => { setSent(false); setFile(null); setSigners([{ email: "", role: "Signer" }]); }} style={{ padding: "10px 20px", background: "#F1F5F9", border: "none", borderRadius: 8, fontSize: 13, cursor: "pointer", color: "#475569", fontWeight: 600 }}>Upload Another</button>
          <button onClick={() => setActive("documents")} style={{ padding: "10px 20px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, cursor: "pointer", fontWeight: 600 }}>View Documents →</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Upload & Send Document</h1>
      <p style={{ fontSize: 13, color: "#94A3B8", margin: "0 0 28px" }}>Upload a document, place signature fields, and send secure signing links.</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>
        <div>
          {/* Drop Zone */}
          <div onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={handleDrop}
            style={{ border: `2px dashed ${dragOver ? "#1E3A5F" : "#CBD5E1"}`, borderRadius: 12, padding: 48, textAlign: "center", background: dragOver ? "#EFF6FF" : "#F8FAFC", transition: "all 0.2s", marginBottom: 20 }}>
            {file ? (
              <div>
                <div style={{ fontSize: 40, marginBottom: 8 }}>📄</div>
                <div style={{ fontWeight: 700, color: "#1E293B", fontSize: 15 }}>{file.name}</div>
                <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>{(file.size / 1024).toFixed(1)} KB</div>
                <button onClick={() => setFile(null)} style={{ marginTop: 12, fontSize: 12, color: "#EF4444", background: "none", border: "none", cursor: "pointer" }}>Remove</button>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 40, marginBottom: 12, color: "#CBD5E1" }}>⬆</div>
                <div style={{ fontWeight: 600, color: "#475569", fontSize: 14 }}>Drag & drop your document here</div>
                <div style={{ fontSize: 12, color: "#94A3B8", margin: "6px 0 16px" }}>PDF, Word (.docx), Excel (.xlsx) · Max 50MB</div>
                <label style={{ padding: "8px 20px", background: "#1E3A5F", color: "#fff", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                  Browse Files
                  <input type="file" accept=".pdf,.docx,.xlsx" onChange={e => setFile(e.target.files[0])} style={{ display: "none" }} />
                </label>
              </>
            )}
          </div>

          {/* Convert Tools */}
          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Convert Document</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10 }}>
              {[
                { from: "Word", to: "PDF", icon: "📄→🔴", label: "Word → PDF" },
                { from: "PDF", to: "Form", icon: "🔴→📝", label: "PDF → Editable" },
                { from: "Excel", to: "PDF", icon: "📊→🔴", label: "Excel → PDF" },
                { from: "PDFs", to: "One", icon: "📄📄→📋", label: "Merge PDFs" },
              ].map(c => (
                <button key={c.label} style={{ display: "flex", gap: 10, alignItems: "center", padding: "10px 14px", background: "#F8FAFC", border: "1px solid #E2E8F0", borderRadius: 8, cursor: "pointer", textAlign: "left" }}>
                  <span style={{ fontSize: 18 }}>{c.icon}</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#475569" }}>{c.label}</div>
                    <div style={{ fontSize: 10, color: "#94A3B8" }}>Convert for signing</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Signer Config */}
        <div>
          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Add Signers</div>
            {signers.map((s, i) => (
              <div key={i} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 4 }}>Signer {i + 1} email</div>
                <input value={s.email} onChange={e => setSigners(prev => prev.map((p, j) => j === i ? { ...p, email: e.target.value } : p))} placeholder={`signer${i + 1}@example.com`} style={{ width: "100%", padding: "8px 12px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                <select value={s.role} onChange={e => setSigners(prev => prev.map((p, j) => j === i ? { ...p, role: e.target.value } : p))} style={{ width: "100%", marginTop: 6, padding: "6px 10px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, background: "#F8FAFC", color: "#475569" }}>
                  {["Signer", "Approver", "Witness", "Final Authority"].map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
            ))}
            <button onClick={() => setSigners(p => [...p, { email: "", role: "Signer" }])} style={{ fontSize: 12, color: "#0EA5E9", background: "none", border: "none", cursor: "pointer", padding: 0 }}>+ Add Signer</button>
          </div>

          <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Signing Order</div>
            {["sequential", "parallel"].map(o => (
              <label key={o} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, cursor: "pointer" }}>
                <input type="radio" name="order" value={o} checked={order === o} onChange={() => setOrder(o)} />
                <span style={{ fontSize: 13, color: "#475569", textTransform: "capitalize" }}>{o}</span>
                <span style={{ fontSize: 11, color: "#94A3B8" }}>{o === "sequential" ? "(A→B→C)" : "(all at once)"}</span>
              </label>
            ))}
          </div>

          <button onClick={handleSend} disabled={!file} style={{ width: "100%", padding: "14px", background: file ? "#1E3A5F" : "#E2E8F0", color: file ? "#fff" : "#94A3B8", border: "none", borderRadius: 10, fontSize: 14, fontWeight: 700, cursor: file ? "pointer" : "not-allowed" }}>
            Send for Signature →
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── APPROVAL CHAINS ──────────────────────────────────────────────────────────
function Workflow() {
  const [chains, setChains] = useState([
    { id: 1, name: "Vendor Agreement Approval", type: "sequential", steps: ["Eric N.", "Janet K.", "Finance Dept.", "Director"], active: 1 },
    { id: 2, name: "HR Document Flow", type: "parallel", steps: ["HR Manager", "Legal", "MD Office"], active: 0 },
  ]);
  const [newName, setNewName] = useState("");
  const [newType, setNewType] = useState("sequential");

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Approval Chains</h1>
      <p style={{ fontSize: 13, color: "#94A3B8", margin: "0 0 28px" }}>Build multi-step signing workflows with sequential, parallel, or delegated approvals.</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
        <div>
          {chains.map(chain => (
            <div key={chain.id} style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20, marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B" }}>{chain.name}</div>
                  <span style={{ fontSize: 11, fontWeight: 600, background: "#EFF6FF", color: "#1D4ED8", padding: "2px 8px", borderRadius: 99, textTransform: "capitalize" }}>{chain.type}</span>
                </div>
                <span style={{ fontSize: 12, color: "#94A3B8" }}>In Progress</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 0, overflowX: "auto" }}>
                {chain.steps.map((step, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center" }}>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ width: 44, height: 44, borderRadius: "50%", background: i < chain.active ? "#10B981" : i === chain.active ? "#1E3A5F" : "#F1F5F9", border: `2px solid ${i < chain.active ? "#10B981" : i === chain.active ? "#1E3A5F" : "#E2E8F0"}`, display: "flex", alignItems: "center", justifyContent: "center", color: i <= chain.active ? "#fff" : "#94A3B8", fontSize: 13, fontWeight: 700, margin: "0 auto 4px" }}>
                        {i < chain.active ? "✓" : i + 1}
                      </div>
                      <div style={{ fontSize: 10, color: i === chain.active ? "#1E3A5F" : "#94A3B8", fontWeight: i === chain.active ? 700 : 400, maxWidth: 60, textAlign: "center" }}>{step}</div>
                    </div>
                    {i < chain.steps.length - 1 && <div style={{ width: 32, height: 2, background: i < chain.active ? "#10B981" : "#E2E8F0", flexShrink: 0, margin: "0 4px 16px" }} />}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 16 }}>Create New Chain</div>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 4 }}>Chain Name</div>
            <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. Purchase Order Flow" style={{ width: "100%", padding: "8px 12px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, outline: "none", boxSizing: "border-box" }} />
          </div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 8 }}>Type</div>
            {["sequential", "parallel", "delegated"].map(t => (
              <label key={t} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, cursor: "pointer" }}>
                <input type="radio" name="chaintype" value={t} checked={newType === t} onChange={() => setNewType(t)} />
                <span style={{ fontSize: 12, color: "#475569", textTransform: "capitalize" }}>{t}</span>
              </label>
            ))}
          </div>
          <button onClick={() => { if (newName) { setChains(p => [...p, { id: Date.now(), name: newName, type: newType, steps: ["Step 1", "Step 2", "Step 3"], active: 0 }]); setNewName(""); } }}
            style={{ width: "100%", padding: "10px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
            Create Chain
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
function NotificationsPage({ notifs, setNotifs }) {
  const iconMap = { warning: "⚠️", success: "✅", info: "ℹ️", neutral: "📋" };
  const bgMap = { warning: "#FEF9C3", success: "#DCFCE7", info: "#DBEAFE", neutral: "#F3F4F6" };
  const colMap = { warning: "#854D0E", success: "#166534", info: "#1D4ED8", neutral: "#374151" };

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Notifications</h1>
        <button onClick={() => setNotifs(p => p.map(n => ({ ...n, read: true })))} style={{ fontSize: 12, color: "#0EA5E9", background: "none", border: "none", cursor: "pointer" }}>Mark all read</button>
      </div>
      <div>
        {notifs.map(n => (
          <div key={n.id} onClick={() => setNotifs(p => p.map(x => x.id === n.id ? { ...x, read: true } : x))}
            style={{ display: "flex", gap: 14, padding: 18, background: n.read ? "#fff" : "#F0F9FF", border: `1px solid ${n.read ? "#E2E8F0" : "#BAE6FD"}`, borderRadius: 10, marginBottom: 10, cursor: "pointer", transition: "all 0.15s" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: bgMap[n.type], display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{iconMap[n.type]}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: n.read ? 500 : 700, color: "#1E293B", marginBottom: 3 }}>{n.title}</div>
              <div style={{ fontSize: 11, color: "#64748B" }}>{n.detail}</div>
            </div>
            <div style={{ fontSize: 11, color: "#94A3B8", whiteSpace: "nowrap" }}>{n.time}</div>
            {!n.read && <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#0EA5E9", flexShrink: 0, marginTop: 6 }} />}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
function Settings() {
  const [pinEnabled, setPinEnabled] = useState(true);
  const [otpEnabled, setOtpEnabled] = useState(true);
  const [sigAlert, setSigAlert] = useState(true);
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      canvas.width = canvas.offsetWidth;
      canvas.height = 80;
      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = "#1E3A5F";
      ctx.lineWidth = 2;
      ctx.lineCap = "round";
      ctxRef.current = ctx;
      ctx.font = "italic 28px Georgia, serif";
      ctx.fillStyle = "#1E3A5F";
      ctx.fillText("Eric Nganga", 20, 55);
    }
  }, []);

  function Toggle({ value, onChange }) {
    return (
      <div onClick={onChange} style={{ width: 40, height: 22, borderRadius: 99, background: value ? "#1E3A5F" : "#E2E8F0", position: "relative", cursor: "pointer", transition: "background 0.2s" }}>
        <div style={{ position: "absolute", top: 3, left: value ? 21 : 3, width: 16, height: 16, borderRadius: "50%", background: "#fff", transition: "left 0.2s" }} />
      </div>
    );
  }

  const plan = MOCK_USER.plan;
  const limits = PLAN_LIMITS[plan];

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 28px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Settings</h1>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Auth Settings */}
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 24 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B", marginBottom: 16 }}>Signature & Authentication</div>
          {[
            { label: "Require PIN before signing", val: pinEnabled, fn: () => setPinEnabled(p => !p) },
            { label: "OTP confirmation after signing", val: otpEnabled, fn: () => setOtpEnabled(p => !p) },
            { label: "Signature Alert — notify when signature is used", val: sigAlert, fn: () => setSigAlert(p => !p) },
          ].map(s => (
            <div key={s.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 0", borderBottom: "1px solid #F1F5F9" }}>
              <span style={{ fontSize: 13, color: "#475569" }}>{s.label}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: s.val ? "#166534" : "#94A3B8" }}>{s.val ? "Enabled" : "Disabled"}</span>
                <Toggle value={s.val} onChange={s.fn} />
              </div>
            </div>
          ))}
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 12, color: "#94A3B8", marginBottom: 8 }}>My Saved Signature</div>
            <canvas ref={canvasRef} style={{ width: "100%", height: 80, border: "1px solid #E2E8F0", borderRadius: 8, display: "block" }} />
            <button style={{ marginTop: 8, fontSize: 12, color: "#0EA5E9", background: "none", border: "none", cursor: "pointer" }}>Update Signature</button>
          </div>
        </div>

        {/* Profile */}
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 24 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B", marginBottom: 16 }}>Profile</div>
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 20 }}>
            <Avatar initials="EN" size={52} />
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: "#1E293B" }}>{MOCK_USER.name}</div>
              <div style={{ fontSize: 12, color: "#94A3B8" }}>{MOCK_USER.role} · {MOCK_USER.email}</div>
            </div>
          </div>
          {[["Full Name", MOCK_USER.name], ["Email", MOCK_USER.email], ["Organization", "SignFlow Co. Ltd"]].map(([label, val]) => (
            <div key={label} style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 4 }}>{label}</div>
              <input defaultValue={val} style={{ width: "100%", padding: "8px 12px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, outline: "none", boxSizing: "border-box", background: "#F8FAFC" }} />
            </div>
          ))}
        </div>

        {/* Team */}
        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 24 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1E293B", marginBottom: 16 }}>Team Members</div>
          {[
            { name: "Janet Kamau", role: "Finance", initials: "JK" },
            { name: "M. Ochieng", role: "Director", initials: "MD" },
            { name: "HR Department", role: "HR Admin", initials: "HR" },
          ].map(m => (
            <div key={m.name} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: "1px solid #F1F5F9" }}>
              <Avatar initials={m.initials} size={34} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#1E293B" }}>{m.name}</div>
                <div style={{ fontSize: 11, color: "#94A3B8" }}>{m.role}</div>
              </div>
              <select style={{ fontSize: 11, color: "#64748B", border: "1px solid #E2E8F0", borderRadius: 6, padding: "3px 6px", background: "#F8FAFC" }}>
                <option>Internal Signer</option>
                <option>Administrator</option>
                <option>Viewer</option>
              </select>
            </div>
          ))}
          <button style={{ marginTop: 12, width: "100%", padding: "8px", background: "#F1F5F9", border: "1px dashed #CBD5E1", borderRadius: 8, fontSize: 12, color: "#64748B", cursor: "pointer" }}>+ Invite Team Member</button>
        </div>
      </div>
    </div>
  );
}

// ─── AUDIT TRAIL PAGE ─────────────────────────────────────────────────────────
function AuditPage({ docs }) {
  const [selectedId, setSelectedId] = useState("SFP-20260420-9821");
  const doc = docs.find(d => d.id === selectedId) || docs.find(d => d.status === "completed");

  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Audit Trail</h1>
      <p style={{ fontSize: 13, color: "#94A3B8", margin: "0 0 20px" }}>Tamper-proof, immutable event log for all document activity.</p>
      <div style={{ marginBottom: 20 }}>
        <select value={selectedId} onChange={e => setSelectedId(e.target.value)} style={{ padding: "8px 14px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 13, outline: "none", minWidth: 320 }}>
          {docs.filter(d => d.status === "completed" || d.status === "pending").map(d => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
      </div>
      {doc && <AuditModal doc={doc} onClose={() => {}} />}
    </div>
  );
}

// ─── CO-SIGNING PAGE ──────────────────────────────────────────────────────────
function CoSign({ docs }) {
  const pending = [
    { doc: "Vendor Agreement", from: "Procurement", due: "May 2", waiting: "Janet K." },
    { doc: "NDA Amendment", from: "Legal Dept", due: "May 10", waiting: "Legal Dept." },
  ];
  return (
    <div style={{ padding: "32px 36px", flex: 1, overflowY: "auto" }}>
      <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, color: "#1E293B" }}>Co-Signing</h1>
      <p style={{ fontSize: 13, color: "#94A3B8", margin: "0 0 28px" }}>Manage parallel signing and co-signatory invitations.</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Pending Co-Sign Requests</div>
          {pending.map(p => (
            <div key={p.doc} style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 10, padding: "16px 20px", marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B" }}>{p.doc}</div>
                <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 4 }}>Awaiting {p.waiting} · Expires {p.due}</div>
              </div>
              <button style={{ padding: "6px 14px", background: "#FEF9C3", color: "#854D0E", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Remind</button>
            </div>
          ))}

          <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", margin: "20px 0 12px" }}>Awaiting Your Signature</div>
          {[{ doc: "Employment Contract — James M.", from: "HR Dept.", due: "May 1", role: "Employer", urgent: true }, { doc: "Vendor Agreement — TechParts", from: "Procurement", due: "May 5", role: "Approver" }].map(d => (
            <div key={d.doc} style={{ background: d.urgent ? "#FFF7ED" : "#fff", border: `1px solid ${d.urgent ? "#FED7AA" : "#E2E8F0"}`, borderRadius: 10, padding: "16px 20px", marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B" }}>{d.doc}</div>
                <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 3 }}>From: {d.from} · Role: {d.role} · Due: {d.due} {d.urgent && "⚠️"}</div>
              </div>
              <button style={{ padding: "6px 14px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Sign Now</button>
            </div>
          ))}
        </div>

        <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: "#1E293B", marginBottom: 12 }}>Invite Co-Signers</div>
          {[{ email: "james@co.ke", initials: "JM", role: "Signer 1 · Approver" }, { email: "finance@co.ke", initials: "FD", role: "Signer 2 · Witness" }, { email: "md@co.ke", initials: "MD", role: "Signer 3 · Final Auth." }].map(s => (
            <div key={s.email} style={{ display: "flex", gap: 10, alignItems: "center", padding: "10px 0", borderBottom: "1px solid #F8FAFC" }}>
              <Avatar initials={s.initials} size={32} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#1E293B" }}>{s.email}</div>
                <div style={{ fontSize: 10, color: "#94A3B8" }}>{s.role}</div>
              </div>
              <button style={{ fontSize: 14, color: "#EF4444", background: "none", border: "none", cursor: "pointer" }}>×</button>
            </div>
          ))}
          <button style={{ marginTop: 12, fontSize: 12, color: "#0EA5E9", background: "none", border: "none", cursor: "pointer" }}>+ Add Co-Signer</button>
          <div style={{ marginTop: 16 }}>
            <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 8 }}>Signing Order</div>
            <select style={{ width: "100%", padding: "8px", border: "1px solid #E2E8F0", borderRadius: 8, fontSize: 12, background: "#F8FAFC" }}>
              <option>Sequential A→B→C</option>
              <option>Parallel (all at once)</option>
            </select>
          </div>
          <button style={{ width: "100%", marginTop: 16, padding: "10px", background: "#1E3A5F", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Send Invitations</button>
        </div>
      </div>
    </div>
  );
}



// ─── E-SIGNATURE PAGE (AssetFlow + Supabase) ──────────────────────────────────
export default function ESignaturePage() {
  const [active, setActive]           = useState("dashboard");
  const [adminId, setAdminId]         = useState(null);
  const [dbContracts, setDbContracts] = useState([]);
  const [localDocs, setLocalDocs]     = useState([]);
  const [loading, setLoading]         = useState(true);
  const [selectedContract, setSelected] = useState(null);
  const [showOTP, setShowOTP]         = useState(false);
  const [signature, setSignature]     = useState(null);
  const [signingStep, setSigningStep] = useState(1);
  const [auditEvents, setAuditEvents] = useState([]);
  const [notifs, setNotifs]           = useState([
    { id: 1, type: "info", title: "E-Signature module loaded", detail: "Contracts synced from database", time: "Just now", read: false },
  ]);
  const [selectedDoc, setSelectedDoc] = useState(null);

  // Convert DB contracts to SignFlowPro doc format
  const dbDocs = dbContracts.map(c => ({
    id: c.invoice_number || c.id,
    _dbId: c.id,
    name: (c.pricing_model === "installment" ? "Hire Purchase Agreement" : "Sale Agreement") + " — " + (c.client_name || "Client"),
    type: "PDF",
    pages: 4,
    status: c.esign_status || "pending",
    signers: [
      { name: c.client_name || "Client", initials: (c.client_name || "CL").slice(0,2).toUpperCase(), signed: ["signed","completed","settled"].includes(c.esign_status), role: "Buyer" },
      { name: "Authorized Officer", initials: "AO", signed: ["signed","completed","settled"].includes(c.esign_status), role: "Vendor" },
    ],
    sent: c.generated_at,
    due: null,
    external: false,
    amount: c.sale?.total_amount,
    _raw: c,
  }));

  const docs = [...dbDocs, ...localDocs];
  const unread = notifs.filter(n => !n.read).length;

  useEffect(() => {
    const boot = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        const { data: profile } = await supabase.from("user_profiles").select("role, admin_id").eq("id", user.id).single();
        const aId = profile?.role === "admin" ? user.id : (profile?.admin_id || user.id);
        setAdminId(aId);
        await fetchContracts(aId);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    boot();
  }, []);

  const fetchContracts = async (aId) => {
    if (!aId) return;
    try {
      const { data } = await supabase
        .from("generated_contracts")
        .select("id, invoice_number, client_name, pricing_model, generated_at, esign_status, signed_at, admin_id, sale:sales(total_amount, sale_date), client:clients(full_name, phone, email)")
        .eq("admin_id", aId)
        .order("generated_at", { ascending: false });
      setDbContracts(data || []);
    } catch (err) { console.error("fetchContracts:", err.message); }
  };

  const updateStatus = async (docId, newStatus) => {
    const doc = docs.find(d => d.id === docId || d._dbId === docId);
    const dbId = doc?._dbId || docId;
    await supabase.from("generated_contracts").update({ esign_status: newStatus }).eq("id", dbId);
    if (adminId) await fetchContracts(adminId);
  };

  const startSigning = (doc) => {
    setSelected(doc._raw || doc);
    setSigningStep(1);
    setSignature(null);
    setAuditEvents([{ type: "view", action: "Contract Opened for Signing", actor: "Admin", time: new Date().toISOString(), ip: "197.232.xx.xx", hash: btoa(doc.id || "x").slice(0,16) + "…" }]);
    setActive("sign");
  };

  const handleOTPVerified = async (otpData) => {
    setShowOTP(false);
    if (!signature || !selectedContract) return;
    const hashInput = (selectedContract.invoice_number || selectedContract.id) + otpData.verifiedAt + (signature.data || "");
    const hash = btoa(hashInput).slice(0,16) + "…" + btoa(hashInput).slice(-8);
    const event = { type: "signed", action: "Document Signed — OTP Verified", actor: "Authorized Officer", time: new Date().toISOString(), ip: otpData.ip, hash };
    setAuditEvents(prev => [...prev, event]);
    try {
      await supabase.from("generated_contracts").update({ esign_status: "signed", signed_at: new Date().toISOString(), signature_hash: hash, signature_type: signature.type }).eq("id", selectedContract.id);
    } catch (err) { console.error(err); }
    setSigningStep(3);
    if (adminId) await fetchContracts(adminId);
  };

  const NAV_ITEMS = [
    { id: "dashboard",     icon: "⊞",  label: "Dashboard" },
    { id: "documents",     icon: "📄", label: "All Documents" },
    { id: "sign",          icon: "✍️", label: "Sign a Document" },
    { id: "upload",        icon: "⬆",  label: "Upload & Convert" },
    { id: "workflow",      icon: "⛓",  label: "Approval Chains" },
    { id: "cosign",        icon: "👥", label: "Co-Signing" },
    { id: "audit",         icon: "🔍", label: "Audit Trail" },
    { id: "notifications", icon: "🔔", label: "Notifications" },
    { id: "settings",      icon: "⚙",  label: "Settings" },
  ];

  const stats = {
    total: docs.length,
    pending: docs.filter(d => ["pending","sent"].includes(d.status)).length,
    signed: docs.filter(d => d.status === "signed").length,
    completed: docs.filter(d => d.status === "completed").length,
  };

  return (
    <MainLayout>
      <div style={{ display: "flex", height: "calc(100vh - 64px)", fontFamily: "\'Segoe UI\', system-ui, sans-serif", background: "#F8FAFC", overflow: "hidden" }}>
        {/* ── Sidebar ── */}
        <div style={{ width: 230, background: "#0F172A", display: "flex", flexDirection: "column", flexShrink: 0 }}>
          <div style={{ padding: "20px 16px 12px" }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#60A5FA", letterSpacing: -0.5, fontFamily: "Georgia, serif" }}>SignFlowPro</div>
            <div style={{ fontSize: 10, color: "#475569", letterSpacing: 1.5, marginTop: 2, textTransform: "uppercase" }}>E-Signature Engine</div>
            <div style={{ fontSize: 10, color: "#334155", marginTop: 4 }}>Powered by AssetFlow · BRS 6.3</div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
            {NAV_ITEMS.map(n => (
              <button key={n.id} onClick={() => setActive(n.id)}
                style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 20px", background: active === n.id ? "rgba(96,165,250,0.15)" : "transparent", border: "none", borderLeft: active === n.id ? "3px solid #60A5FA" : "3px solid transparent", color: active === n.id ? "#93C5FD" : "#64748B", fontSize: 13, cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                <span style={{ fontSize: 14 }}>{n.icon}</span>
                {n.label}
                {n.id === "notifications" && unread > 0 && <span style={{ marginLeft: "auto", background: "#EF4444", color: "#fff", fontSize: 10, fontWeight: 700, borderRadius: 99, padding: "1px 6px" }}>{unread}</span>}
              </button>
            ))}
          </div>
          <div style={{ padding: "12px 16px", borderTop: "1px solid #1E293B" }}>
            {[{ label: "Total", value: stats.total, color: "#93C5FD" }, { label: "Pending", value: stats.pending, color: "#FCD34D" }, { label: "Signed", value: stats.signed, color: "#6EE7B7" }].map(s => (
              <div key={s.label} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: "#64748B" }}>{s.label}</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Main content ── */}
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          {active === "dashboard" && <Dashboard docs={docs} setActive={setActive} setSelectedDoc={(d) => { setSelectedDoc(d); setActive("documents"); }} />}
          {active === "documents" && <Documents docs={docs} setDocs={setLocalDocs} setActive={setActive} extra={{ updateStatus }} />}
          {active === "sign" && (
            <div style={{ padding: "28px 36px", flex: 1, overflowY: "auto" }}>
              {signingStep === 1 && (
                <div style={{ maxWidth: 600 }}>
                  <button onClick={() => setActive("dashboard")} style={{ fontSize: 12, color: "#64748B", background: "none", border: "none", cursor: "pointer", marginBottom: 20, padding: 0 }}>← Back to Dashboard</button>
                  <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: "#1E293B" }}>Select Contract to Sign</h2>
                  <p style={{ margin: "0 0 20px", fontSize: 13, color: "#94A3B8" }}>Choose a pending contract from below</p>
                  {docs.filter(d => d.status === "pending" || d.status === "sent").length === 0 ? (
                    <div style={{ padding: 40, textAlign: "center", background: "#fff", borderRadius: 12, border: "1px solid #E2E8F0" }}>
                      <div style={{ fontSize: 32, marginBottom: 8 }}>✅</div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "#1E293B" }}>No pending contracts</div>
                    </div>
                  ) : docs.filter(d => d.status === "pending" || d.status === "sent").map(doc => (
                    <div key={doc.id} style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 12, padding: "16px 20px", marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}
                      onClick={() => startSigning(doc)}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: "#1E293B" }}>{doc.name}</div>
                        <div style={{ fontSize: 11, color: "#94A3B8", marginTop: 4 }}>{doc.id} · {doc.sent ? fmtDate(doc.sent) : "—"}</div>
                      </div>
                      <button style={{ padding: "7px 16px", background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
                        Sign Now ✍️
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {signingStep === 2 && selectedContract && (
                <div style={{ maxWidth: 600 }}>
                  <button onClick={() => setSigningStep(1)} style={{ fontSize: 12, color: "#64748B", background: "none", border: "none", cursor: "pointer", marginBottom: 20, padding: 0 }}>← Back</button>
                  <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: "#1E293B" }}>Sign Contract</h2>
                  <p style={{ margin: "0 0 20px", fontSize: 13, color: "#94A3B8" }}>{selectedContract.invoice_number} — {selectedContract.client_name}</p>
                  <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 14, padding: 24, marginBottom: 20 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#1E293B", marginBottom: 16 }}>Your Signature</div>
                    <SignatureCanvas onCapture={(sig) => { setSignature(sig); setShowOTP(true); }} />
                  </div>
                </div>
              )}
              {signingStep === 3 && (
                <div style={{ textAlign: "center", padding: "40px 20px" }}>
                  <div style={{ fontSize: 64, marginBottom: 16 }}>🎉</div>
                  <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: "#166534" }}>Contract Signed!</h2>
                  <p style={{ fontSize: 14, color: "#64748B", margin: "0 0 24px" }}>Audit trail recorded. All parties have been notified.</p>
                  <button onClick={() => { setSigningStep(1); setActive("dashboard"); }}
                    style={{ padding: "12px 28px", background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 10, fontSize: 14, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
                    Back to Dashboard
                  </button>
                </div>
              )}
            </div>
          )}
          {active === "upload"        && <Upload setDocs={(newDoc) => setLocalDocs(p => [newDoc, ...p])} setActive={setActive} />}
          {active === "workflow"      && <Workflow />}
          {active === "cosign"        && <CoSign docs={docs} />}
          {active === "audit"         && <AuditPage docs={docs} />}
          {active === "notifications" && <NotificationsPage notifs={notifs} setNotifs={setNotifs} />}
          {active === "settings"      && <Settings />}
        </div>
      </div>

      {showOTP && (
        <OTPModal
          signer={{ name: "Authorized Officer", phone: "+254 7XX XXX XXX" }}
          onVerified={handleOTPVerified}
          onClose={() => { setShowOTP(false); setSignature(null); }}
        />
      )}
    </MainLayout>
  );
}
