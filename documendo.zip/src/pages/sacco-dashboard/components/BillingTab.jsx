import React from 'react';
import Icon from '../../../components/AppIcon';
import { SACCO_TIERS, INSTALLATION_FEE } from '../../../config/saccoTiers';
import { Card, StatCard, Table, Badge, KES, fmtDate } from './_shared';

const BillingTab = ({ ctx }) => {
  const { stats, sacco, invoices } = ctx;
  const bill = stats.billing;
  const currentTierId = stats.tier?.id;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Current tier" value={stats.tier?.name} hint={stats.tier?.memberRange} icon="Layers" />
        <StatCard label="Active members" value={stats.activeMembers} hint="Billed members" icon="Users" />
        <StatCard label="Estimated monthly bill" value={KES(bill.total)} icon="Receipt" tone="success" />
      </div>

      {/* This month's breakdown */}
      <Card title="This month's estimate" subtitle="Base + per-member + storage (BRS §7.6)">
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Base fee · {stats.tier?.name}</span>
            <span className="font-semibold text-foreground">{KES(bill.baseFee)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Per-member · {stats.activeMembers} × {KES(stats.tier?.perMemberFee)}</span>
            <span className="font-semibold text-foreground">{KES(bill.perMemberFeeTotal)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Storage excess · {bill.excessGb} GB × {KES(10)}</span>
            <span className="font-semibold text-foreground">{KES(bill.storageFee)}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-border">
            <span className="font-bold text-foreground">Total due this month</span>
            <span className="text-xl font-bold text-foreground">{KES(bill.total)}</span>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-3">One-time installation fee of {KES(INSTALLATION_FEE)} applies on first onboarding only.</p>
      </Card>

      {/* Tier catalog */}
      <Card title="Tiers" subtitle="Your tier is chosen automatically by active member count">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {SACCO_TIERS.map((t) => {
            const active = t.id === currentTierId;
            return (
              <div key={t.id} className="p-4 rounded-xl border-2 transition-all"
                style={{ borderColor: active ? '#34c1dd' : 'var(--color-border)', background: active ? 'rgba(52,193,221,0.05)' : 'transparent' }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: t.color }}>{t.name[0]}</div>
                    <p className="font-bold text-foreground">{t.name}</p>
                  </div>
                  {active && <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: '#34c1dd' }}><Icon name="Check" size={11} color="#fff" /></div>}
                </div>
                <p className="text-xs text-muted-foreground mt-2">{t.memberRange}</p>
                <div className="mt-3 space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Base</span><span className="font-semibold text-foreground">{KES(t.baseFee)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Per member</span><span className="font-semibold text-foreground">{KES(t.perMemberFee)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Free storage</span><span className="font-semibold text-foreground">{t.storageGb} GB</span></div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Invoices */}
      <Card title="Invoices" subtitle={`${invoices.length} on record`}>
        {invoices.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">No invoices generated yet.</p>
            <p className="text-xs text-muted-foreground mt-1">Monthly invoices run on the 1st (automated billing is a Phase 2 enhancement).</p>
          </div>
        ) : (
          <Table columns={['Period', 'Tier', 'Members', 'Base', 'Per-member', 'Storage', 'Total', 'Status']}>
            {invoices.map((inv) => (
              <tr key={inv.id} className="border-b border-border/60">
                <td className="py-2.5 pr-4 text-foreground">{fmtDate(inv.period)}</td>
                <td className="py-2.5 pr-4 capitalize text-muted-foreground">{inv.tier}</td>
                <td className="py-2.5 pr-4 text-muted-foreground">{inv.active_members}</td>
                <td className="py-2.5 pr-4 text-muted-foreground">{KES(inv.base_fee)}</td>
                <td className="py-2.5 pr-4 text-muted-foreground">{KES(inv.per_member_fee_total)}</td>
                <td className="py-2.5 pr-4 text-muted-foreground">{KES(inv.storage_fee)}</td>
                <td className="py-2.5 pr-4 font-semibold text-foreground">{KES(inv.total)}</td>
                <td className="py-2.5 pr-4"><Badge status={inv.status} /></td>
              </tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
};

export default BillingTab;
