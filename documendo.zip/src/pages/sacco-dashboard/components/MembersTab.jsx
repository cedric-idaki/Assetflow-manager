import React, { useState } from 'react';
import { useToast } from '../../../components/Toast';
import { Card, Table, Badge, PrimaryButton, GhostButton, Modal, Field, TextInput, Select, EmptyState, fmtDate } from './_shared';

const MEMBER_ROLES = ['member', 'treasurer', 'chairman', 'secretary', 'auditor'];
const STATUSES = ['active', 'inactive', 'suspended'];

const emptyForm = {
  full_name: '', phone: '', email: '', national_id: '', gender: '',
  member_role: 'member', status: 'active', kyc_status: 'pending',
  next_of_kin_name: '', next_of_kin_relationship: '', next_of_kin_phone: '', next_of_kin_id: '',
};

const MembersTab = ({ ctx }) => {
  const { members, addMember, updateMember, exportCSV } = ctx;
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState('');

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const openNew = () => { setEditing(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (m) => { setEditing(m); setForm({ ...emptyForm, ...m }); setOpen(true); };

  const save = async () => {
    if (!form.full_name.trim()) { toast.error('Member name is required.'); return; }
    setSaving(true);
    try {
      if (editing) await updateMember(editing.id, form);
      else await addMember(form);
      toast.success(editing ? 'Member updated.' : 'Member added.');
      setOpen(false);
    } catch (e) {
      toast.error(e.message || 'Could not save member.');
    } finally {
      setSaving(false);
    }
  };

  const filtered = members.filter((m) =>
    !q || (m.full_name || '').toLowerCase().includes(q.toLowerCase()) || (m.member_no || '').toLowerCase().includes(q.toLowerCase()));

  return (
    <Card
      title="Members"
      subtitle={`${members.length} registered · ${members.filter((m) => m.status === 'active').length} active`}
      actions={
        <div className="flex items-center gap-2">
          <GhostButton icon="Download" onClick={() => exportCSV(members, 'sacco_members')}>Export</GhostButton>
          <PrimaryButton icon="UserPlus" onClick={openNew}>Add member</PrimaryButton>
        </div>
      }
    >
      <input
        value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or member no…"
        className="w-full sm:w-72 mb-4 px-3 py-2 text-sm rounded-lg border border-border bg-background text-foreground focus:outline-none focus:border-primary"
      />

      {filtered.length === 0 ? (
        <EmptyState icon="Users" title="No members yet" hint="Add your first member to start tracking contributions, loans and shares." />
      ) : (
        <Table columns={['Member', 'Role', 'Phone', 'Status', 'KYC', 'Joined', '']}>
          {filtered.map((m) => (
            <tr key={m.id} className="border-b border-border/60">
              <td className="py-2.5 pr-4">
                <p className="font-medium text-foreground">{m.full_name}</p>
                <p className="text-xs text-muted-foreground">{m.member_no}</p>
              </td>
              <td className="py-2.5 pr-4 capitalize text-foreground">{m.member_role}</td>
              <td className="py-2.5 pr-4 text-muted-foreground">{m.phone || '—'}</td>
              <td className="py-2.5 pr-4"><Badge status={m.status} /></td>
              <td className="py-2.5 pr-4"><Badge status={m.kyc_status} /></td>
              <td className="py-2.5 pr-4 text-muted-foreground">{fmtDate(m.joined_at)}</td>
              <td className="py-2.5 pr-0 text-right">
                <button onClick={() => openEdit(m)} className="text-xs text-primary font-semibold hover:underline">Edit</button>
              </td>
            </tr>
          ))}
        </Table>
      )}

      <Modal
        open={open} onClose={() => setOpen(false)} wide
        title={editing ? 'Edit member' : 'Add member'}
        footer={<>
          <GhostButton onClick={() => setOpen(false)}>Cancel</GhostButton>
          <PrimaryButton icon="Check" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save member'}</PrimaryButton>
        </>}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Full name *"><TextInput value={form.full_name} onChange={(e) => set('full_name', e.target.value)} placeholder="Jane Wanjiku" /></Field>
          <Field label="Phone"><TextInput value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="+254 7XX XXX XXX" /></Field>
          <Field label="Email"><TextInput value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="jane@example.com" /></Field>
          <Field label="National ID"><TextInput value={form.national_id} onChange={(e) => set('national_id', e.target.value)} /></Field>
          <Field label="Role"><Select value={form.member_role} onChange={(e) => set('member_role', e.target.value)}>{MEMBER_ROLES.map((r) => <option key={r} value={r} className="capitalize">{r}</option>)}</Select></Field>
          <Field label="Status"><Select value={form.status} onChange={(e) => set('status', e.target.value)}>{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</Select></Field>
        </div>
        <p className="text-xs font-semibold text-muted-foreground mt-5 mb-2 uppercase tracking-wide">Next of kin</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Name"><TextInput value={form.next_of_kin_name} onChange={(e) => set('next_of_kin_name', e.target.value)} /></Field>
          <Field label="Relationship"><TextInput value={form.next_of_kin_relationship} onChange={(e) => set('next_of_kin_relationship', e.target.value)} /></Field>
          <Field label="Phone"><TextInput value={form.next_of_kin_phone} onChange={(e) => set('next_of_kin_phone', e.target.value)} /></Field>
          <Field label="ID number"><TextInput value={form.next_of_kin_id} onChange={(e) => set('next_of_kin_id', e.target.value)} /></Field>
        </div>
      </Modal>
    </Card>
  );
};

export default MembersTab;
