import{bj as l,q as b,aE as p,b3 as v,aU as x,af as P,aV as w,bn as $}from"./index-BhSeiNpe.js";const i=a=>`KES ${parseFloat(a||0).toLocaleString("en-KE",{minimumFractionDigits:0,maximumFractionDigits:0})}`,A=a=>a?new Date(a).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}):"—",h=a=>a?new Date(a+"-01").toLocaleDateString("en-GB",{month:"long",year:"numeric"}):"—",T=`
  /* A payslip is a document, not a themed page. It declares its own light
     ground: the text colours below are near-black, and a viewer in dark mode
     otherwise paints them onto a dark background — the pop-up sitting behind
     the print dialog comes out unreadable even though the printed sheet is
     fine. color-scheme keeps the browser from inverting scrollbars with it. */
  :root { color-scheme: light; }
  html, body { background: #fff; }
  body { font-family: Arial, sans-serif; max-width: 640px; margin: 32px auto; color: #111; }
  .head { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #1A56DB; padding-bottom: 16px; margin-bottom: 20px; }
  .co { font-size: 18px; font-weight: 700; }
  .muted { color: #666; font-size: 12px; margin-top: 2px; }
  .title { font-size: 22px; font-weight: 800; color: #1A56DB; text-align: right; }
  .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; font-size: 13px; }
  .lbl { font-size: 11px; text-transform: uppercase; color: #888; letter-spacing: .05em; margin-bottom: 4px; }
  .sec { font-weight: 700; border-bottom: 1px solid #ddd; padding-bottom: 6px; margin: 16px 0 4px; }
  .row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #f0f0f0; font-size: 13px; }
  .row span:last-child { font-family: monospace; font-weight: 600; }
  .neg { color: #DC2626; }
  .gross { font-weight: 700; border-top: 2px solid #111; }
  .net { display: flex; justify-content: space-between; padding: 14px 0; border-top: 2px solid #111; margin-top: 8px; font-size: 18px; font-weight: 800; }
  .net span:last-child { color: #059669; font-family: monospace; }
  .foot { margin-top: 28px; font-size: 11px; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 12px; }
  /* Each payslip is its own sheet. Without this a batch runs slips together
     across page boundaries and nobody can hand one to one employee. */
  .payslip { page-break-after: always; }
  .payslip:last-child { page-break-after: auto; }
  @media print { body { margin: 0 auto; } }
`,D=({company:a,letterhead:n,employee:o={},month:t,data:e={}})=>{const d=v(n===void 0?P():n,x(a)),u=(d==null?void 0:d.name)||"Ararat Company",g=(r,c)=>l(p`<div class="row"><span>${r}</span><span>${i(c)}</span></div>`),m=(r,c)=>l(p`<div class="row"><span>${r}</span><span class="neg">(${i(c)})</span></div>`),y=(r,c)=>parseFloat(c)>0?g(r,c):"",f=(r,c)=>parseFloat(c)>0?m(r,c):"";return p`
    <div class="payslip">
      <div class="head">
        ${l(w(d,{fallbackName:u}))}
        <div>
          <div class="title">PAYSLIP</div>
          <div class="muted" style="text-align:right;">${h(t)}</div>
        </div>
      </div>
      <div class="meta">
        <div>
          <div class="lbl">Employee</div>
          <div style="font-weight:600;">${o.full_name||"—"}</div>
          ${o.department?l(p`<div class="muted">${o.department}</div>`):""}
          ${o.email?l(p`<div class="muted">${o.email}</div>`):""}
          ${o.kra_pin?l(p`<div class="muted">KRA PIN: ${o.kra_pin}</div>`):""}
        </div>
        <div>
          <div class="lbl">Employee ID</div>
          <div style="font-family:monospace;font-size:12px;word-break:break-all;">${o.id||"—"}</div>
          <div class="lbl" style="margin-top:8px;">Pay Period</div>
          <div>${h(t)}</div>
        </div>
      </div>
      <div class="sec">Earnings</div>
      ${g("Basic Salary",e.basic)}
      ${y("Housing Allowance",e.housingAllowance)}
      ${y("Transport Allowance",e.transportAllowance)}
      ${y("Meal Allowance",e.mealAllowance)}
      ${y("Bonus",e.bonus)}
      ${y("Gift",e.gift)}
      <div class="row gross"><span>Gross Pay</span><span>${i(e.grossCash)}</span></div>
      ${e.taxableNonCash>0?l(p`<div class="row"><span>Taxable non-cash benefits</span><span>${i(e.taxableNonCash)}</span></div>`):""}

      <div class="sec">Statutory Deductions</div>
      ${m("NSSF (Tier I & II)",e.nssf)}
      ${m("SHIF (2.75%)",e.shif)}
      ${m("Affordable Housing Levy (1.5%)",e.housingLevy)}
      ${m("PAYE (Income Tax)",e.paye)}

      ${e.voluntaryDeductions>0?l(p`<div class="sec">Other Deductions</div>`):""}
      ${f("Pension Contribution",e.pension)}
      ${f("Post-Retirement Medical",e.postRetirementMedical)}
      ${f("Loan Repayment",e.loanDeduction)}
      ${f("Salary Advance",e.advanceDeduction)}
      ${f("Other",e.otherDeductions)}

      ${m("Total Deductions",e.totalDeductions)}
      <div class="net"><span>NET PAY</span><span>${i(e.netPay)}</span></div>

      <!-- How the tax was arrived at. A payslip that shows only the tax gives
           an employee no way to check it, and gives the employer nothing to
           show a KRA query. -->
      <div class="sec">How PAYE Was Calculated</div>
      <div class="row"><span>Gross pay</span><span>${i(e.grossPay)}</span></div>
      <div class="row"><span>Less allowable deductions (NSSF, SHIF, AHL${e.mortgageDeduction>0?", mortgage interest":""}${e.medicalFundDeduction>0?", medical fund":""})</span><span class="neg">(${i(e.allowableDeductions)})</span></div>
      ${e.disabilityRelief>0?l(p`<div class="row"><span>Less disability exemption</span><span class="neg">(${i(e.disabilityRelief)})</span></div>`):""}
      <div class="row gross"><span>Taxable pay</span><span>${i(e.taxablePay)}</span></div>
      ${l((e.payeBands||[]).map(r=>p`
        <div class="row"><span style="padding-left:12px;">${(r.rate*100).toFixed(r.rate===.325?1:0)}% on ${i(r.amount)}</span><span>${i(r.tax)}</span></div>
      `).join(""))}
      <div class="row"><span>Tax on taxable pay</span><span>${i(e.grossTax)}</span></div>
      <div class="row"><span>Less personal relief</span><span class="neg">(${i(e.personalRelief)})</span></div>
      ${e.insuranceRelief>0?l(p`<div class="row"><span>Less insurance relief</span><span class="neg">(${i(e.insuranceRelief)})</span></div>`):""}
      <div class="row gross"><span>PAYE payable</span><span>${i(e.paye)}</span></div>

      <div class="foot">
        Generated by ${u} on ${A(new Date)} · Computer-generated payslip, no signature required.<br/>
        ${e.rateLabel?`Statutory rates: ${e.rateLabel}`:"Statutory basis not recorded for this period"}
      </div>
    </div>
  `},S=(a=[])=>{var t,e,d,u;const n=Array.isArray(a)?a:[a],o=n.length===1?`Payslip — ${((e=(t=n[0])==null?void 0:t.employee)==null?void 0:e.full_name)||"Employee"} — ${h((d=n[0])==null?void 0:d.month)}`:`Payslips — ${h((u=n[0])==null?void 0:u.month)} — ${n.length} employees`;return p`
    <html><head><title>${o}</title>
    <style>${l(T+b)}</style></head><body>
    ${l(n.map(g=>D(g)).join(""))}
    </body></html>
  `},E=["PIN of Employee","Name of Employee","Residential Status","Type of Employee","Basic Salary","Housing Allowance","Transport Allowance","Leave Pay","Overtime Allowance","Directors Fee","Lump Sum Payment","Other Allowances","Total Cash Pay","Value of Car Benefit","Other Non-Cash Benefits","Total Non-Cash Pay","Total Gross Pay","Pension: Actual Contribution","Pension: 30% of Cash Pay","Pension: Permissible Limit","Pension: Amount Deductible","Owner Occupier Interest Deductible","Post Retirement Medical Fund","Affordable Housing Levy","Social Health Insurance Fund","Taxable Pay","Tax Payable on Taxable Pay","Monthly Personal Relief","Amount of Insurance Relief","PAYE Tax","Basis"],s=a=>Math.round(((parseFloat(a)||0)+Number.EPSILON)*100)/100,R=({records:a=[],employeesById:n={}})=>a.map(o=>{const t=n[o.employee_id]||{},e=$(o);return{"PIN of Employee":t.kra_pin||"","Name of Employee":t.full_name||"","Residential Status":"Resident","Type of Employee":"Primary Employee","Basic Salary":s(e.basic),"Housing Allowance":s(e.housingAllowance),"Transport Allowance":s(e.transportAllowance),"Leave Pay":0,"Overtime Allowance":0,"Directors Fee":0,"Lump Sum Payment":0,"Other Allowances":s(e.mealAllowance+e.bonus+e.gift+e.otherAllowances),"Total Cash Pay":s(e.grossCash),"Value of Car Benefit":0,"Other Non-Cash Benefits":s(e.nonCashBenefits),"Total Non-Cash Pay":s(e.taxableNonCash),"Total Gross Pay":s(e.grossPay),"Pension: Actual Contribution":s(e.pensionActual),"Pension: 30% of Cash Pay":s(e.pensionRateLimit),"Pension: Permissible Limit":s(e.pensionCap),"Pension: Amount Deductible":s(e.pensionDeduction),"Owner Occupier Interest Deductible":s(e.mortgageDeduction),"Post Retirement Medical Fund":s(e.medicalFundDeduction),"Affordable Housing Levy":s(e.housingLevy),"Social Health Insurance Fund":s(e.shif),"Taxable Pay":s(e.taxablePay),"Tax Payable on Taxable Pay":s(e.grossTax),"Monthly Personal Relief":s(e.personalRelief),"Amount of Insurance Relief":s(e.insuranceRelief),"PAYE Tax":s(e.paye),Basis:e.rebuilt?`${e.rateVersion||"unknown"} (reconstructed)`:e.rateVersion||""}}),C=(a=[])=>{const n=o=>s(a.reduce((t,e)=>t+(parseFloat(e[o])||0),0));return{employees:a.length,grossPay:n("Total Gross Pay"),taxablePay:n("Taxable Pay"),paye:n("PAYE Tax"),shif:n("Social Health Insurance Fund"),housingLevy:n("Affordable Housing Levy"),personalRelief:n("Monthly Personal Relief")}},F=(a=[])=>{const n=a.filter(t=>!t["PIN of Employee"]).map(t=>t["Name of Employee"]||"Unnamed employee"),o=a.filter(t=>String(t.Basis).includes("reconstructed")).length;return{missingPin:n,reconstructed:o}};export{E as P,C as a,R as b,S as c,F as p};
