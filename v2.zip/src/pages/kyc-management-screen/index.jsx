import React, { useState, useMemo, useEffect, useCallback } from 'react';
import MainLayout from '../../layouts/MainLayout';
import Icon from '../../components/AppIcon';
import KYCStatusBadge from './components/KYCStatusBadge';
import DocumentUploadZone from './components/DocumentUploadZone';
import PhotoCapturePanel from './components/PhotoCapturePanel';
import KRAPINPanel from './components/KRAPINPanel';
import ComplianceDashboard from './components/ComplianceDashboard';
import VerificationWorkflow from './components/VerificationWorkflow';
import ClientKYCCard from './components/ClientKYCCard';
import { supabase } from '../../lib/supabase';
import { auditLogsService } from '../../services/supabaseService';
import { useAuth } from '../../contexts/AuthContext';

const mapClient = (row, docMap) => {
  const d = docMap[row.id] || {};
  return {
    id: row.id,
    name: row.full_name,
    email: row.email,
    phone: row.phone,
    accountNumber: row.account_number,
    kycStatus: row.kyc_status || 'incomplete',
    kraPin: row.kra_pin || null,
    kraPinVerified: !!row.kra_pin_verified,
    documentExpiry: row.document_expiry || null,
    idDocument: !!(d.national_id || d.national_id_front),
    photo: !!(d.passport_photo || d.photo),
  };
};

const KYCManagementScreen = () => {
  const { user, userProfile } = useAuth();
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('documents');
  const [idDocument, setIdDocument] = useState(null);
  const [passportDocument, setPassportDocument] = useState(null);
  const [capturedPhoto, setCapturedPhoto] = useState(null);
  const [kraPin, setKraPin] = useState('');
  const [kraPinVerified, setKraPinVerified] = useState(false);
  const [isVerifyingPin, setIsVerifyingPin] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const currentUser = useMemo(() => ({
    id: user?.id || '',
    name: userProfile?.full_name || user?.email?.split('@')[0] || 'Staff',
    role: userProfile?.role || 'kyc_officer',
    email: user?.email || '',
  }), [user, userProfile]);

  const fetchClients = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: err } = await supabase
        .from('clients')
        .select('id, full_name, email, phone, account_number, kyc_status, kra_pin, kra_pin_verified, document_expiry, created_at, admin_id')
        .order('created_at', { ascending: false });
      if (err) throw err;

      const { data: docs } = await supabase
        .from('kyc_documents')
        .select('client_id, document_type')
        .in('document_type', ['national_id', 'national_id_front', 'passport_photo', 'photo']);

      const docMap = {};
      (docs || []).forEach(d => {
        if (!docMap[d.client_id]) docMap[d.client_id] = {};
        docMap[d.client_id][d.document_type] = true;
      });

      const mapped = (data || []).map(row => mapClient(row, docMap));
      setClients(mapped);
      if (mapped.length > 0 && !selectedClientId) {
        setSelectedClientId(mapped[0].id);
        setKraPin(mapped[0].kraPin || '');
        setKraPinVerified(mapped[0].kraPinVerified || false);
      }
    } catch (err) {
      setError('Failed to load clients. Please refresh.');
    } finally {
      setLoading(false);
    }
  }, [selectedClientId]);

  useEffect(() => { fetchClients(); }, []);

  useEffect(() => {
    const ch = supabase.channel('kyc_mgmt_rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'clients' }, fetchClients)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'kyc_documents' }, fetchClients)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [fetchClients]);

  const selectedClient = useMemo(() => clients.find(c => c.id === selectedClientId) || null, [clients, selectedClientId]);

  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !searchQuery ||
        c.name?.toLowerCase().includes(q) ||
        c.email?.toLowerCase().includes(q) ||
        c.accountNumber?.toLowerCase().includes(q);
      const matchStatus = statusFilter === 'all' || c.kycStatus === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [clients, searchQuery, statusFilter]);

  const handleClientSelect = (clientId) => {
    setSelectedClientId(clientId);
    const c = clients.find(x => x.id === clientId);
    setKraPin(c?.kraPin || '');
    setKraPinVerified(c?.kraPinVerified || false);
    setIdDocument(null); setPassportDocument(null); setCapturedPhoto(null); setSaveSuccess(false);
  };

  const handleVerifyKRAPin = async (pin) => {
    setIsVerifyingPin(true);
    await new Promise(r => setTimeout(r, 1500));
    setKraPinVerified(true);
    setIsVerifyingPin(false);
    if (selectedClient) {
      await supabase.from('clients').update({ kra_pin: pin, kra_pin_verified: true, updated_at: new Date().toISOString() }).eq('id', selectedClient.id);
      await auditLogsService?.logKYCAction('kyc_document_upload', selectedClient.id, selectedClient.name, `KRA PIN verified for ${selectedClient.name}`, { document_type: 'KRA PIN', verification_status: 'verified' }, 'info');
    }
  };

  const handleSaveDocuments = async () => {
    if (!selectedClient) return;
    setIsSaving(true);
    try {
      const uploads = [];
      if (idDocument) {
        uploads.push(supabase.from('kyc_documents').upsert({ client_id: selectedClient.id, document_type: 'national_id', file_name: idDocument.name, file_size: idDocument.size, status: 'active', uploaded_by: user?.id, created_at: new Date().toISOString() }, { onConflict: 'client_id,document_type' }));
        await auditLogsService?.logKYCAction('kyc_document_upload', selectedClient.id, selectedClient.name, `National ID uploaded for ${selectedClient.name}`, { document_type: 'National ID', file_name: idDocument.name }, 'info');
      }
      if (passportDocument) {
        uploads.push(supabase.from('kyc_documents').upsert({ client_id: selectedClient.id, document_type: 'passport', file_name: passportDocument.name, file_size: passportDocument.size, status: 'active', uploaded_by: user?.id, created_at: new Date().toISOString() }, { onConflict: 'client_id,document_type' }));
        await auditLogsService?.logKYCAction('kyc_document_upload', selectedClient.id, selectedClient.name, `Passport uploaded for ${selectedClient.name}`, { document_type: 'Passport', file_name: passportDocument.name }, 'info');
      }
      if (capturedPhoto) {
        uploads.push(supabase.from('kyc_documents').upsert({ client_id: selectedClient.id, document_type: 'passport_photo', file_name: 'photo_capture.jpg', status: 'active', uploaded_by: user?.id, created_at: new Date().toISOString() }, { onConflict: 'client_id,document_type' }));
        await auditLogsService?.logKYCAction('kyc_document_upload', selectedClient.id, selectedClient.name, `Photo captured for ${selectedClient.name}`, { document_type: 'Passport Photo' }, 'info');
      }
      if (kraPin) {
        await supabase.from('clients').update({ kra_pin: kraPin, kra_pin_verified: kraPinVerified, updated_at: new Date().toISOString() }).eq('id', selectedClient.id);
      }
      await Promise.all(uploads);

      const willHaveId = idDocument || selectedClient.idDocument;
      const willHavePhoto = capturedPhoto || selectedClient.photo;
      const willHavePin = kraPin || selectedClient.kraPin;
      if (willHaveId && willHavePhoto && willHavePin && selectedClient.kycStatus === 'incomplete') {
        await supabase.from('clients').update({ kyc_status: 'pending', updated_at: new Date().toISOString() }).eq('id', selectedClient.id);
        await auditLogsService?.logKYCAction('kyc_status_change', selectedClient.id, selectedClient.name, `KYC status changed to pending for ${selectedClient.name}`, { previous_status: 'incomplete', new_status: 'pending' }, 'info');
      }
      await fetchClients();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const handleApprove = async (clientId, comment) => {
    const c = clients.find(x => x.id === clientId);
    await supabase.from('clients').update({ kyc_status: 'verified', kyc_verified_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', clientId);
    await auditLogsService?.logKYCAction('kyc_verification', clientId, c?.name, `KYC approved for ${c?.name}`, { previous_status: c?.kycStatus, new_status: 'verified', approver_notes: comment || 'Approved' }, 'info');
    setClients(prev => prev.map(x => x.id === clientId ? { ...x, kycStatus: 'verified' } : x));
  };

  const handleReject = async (clientId, comment) => {
    const c = clients.find(x => x.id === clientId);
    await supabase.from('clients').update({ kyc_status: 'rejected', kyc_rejection_reason: comment, updated_at: new Date().toISOString() }).eq('id', clientId);
    await auditLogsService?.logKYCAction('kyc_verification', clientId, c?.name, `KYC rejected for ${c?.name}`, { previous_status: c?.kycStatus, new_status: 'rejected', approver_notes: comment }, 'warning');
    setClients(prev => prev.map(x => x.id === clientId ? { ...x, kycStatus: 'rejected' } : x));
  };

  const handleRequestInfo = async (clientId, comment) => {
    const c = clients.find(x => x.id === clientId);
    await supabase.from('clients').update({ kyc_status: 'incomplete', updated_at: new Date().toISOString() }).eq('id', clientId);
    await auditLogsService?.logKYCAction('kyc_status_change', clientId, c?.name, `Additional information requested for ${c?.name}`, { previous_status: c?.kycStatus, new_status: 'incomplete', reason: comment }, 'info');
    setClients(prev => prev.map(x => x.id === clientId ? { ...x, kycStatus: 'incomplete' } : x));
  };

  const statusOptions = [
    { value: 'all', label: 'All Statuses' }, { value: 'verified', label: 'Verified' },
    { value: 'pending', label: 'Pending' }, { value: 'under_review', label: 'Under Review' },
    { value: 'rejected', label: 'Rejected' }, { value: 'incomplete', label: 'Incomplete' },
  ];

  const tabs = [
    { id: 'documents', label: 'Documents', icon: 'FileText' },
    { id: 'verification', label: 'Verification', icon: 'ShieldCheck' },
    { id: 'compliance', label: 'Compliance', icon: 'BarChart3' },
  ];

  return (
    <MainLayout>
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">KYC Management</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Know Your Customer compliance, document verification &amp; tracking</p>
          </div>
          <button onClick={fetchClients} className="flex items-center gap-2 px-3 py-2 text-xs font-medium border border-border text-muted-foreground rounded-lg hover:bg-muted transition-colors">
            <Icon name="RefreshCw" size={13} color="currentColor" /> Refresh
          </button>
        </div>

        <div className="flex items-center gap-1 p-1 bg-muted rounded-xl w-fit">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
              <Icon name={tab.icon} size={14} color="currentColor" />{tab.label}
            </button>
          ))}
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm text-red-600">
            <Icon name="AlertCircle" size={14} color="currentColor" />{error}
          </div>
        )}

        {activeTab === 'compliance' && <ComplianceDashboard clients={clients} />}

        {(activeTab === 'documents' || activeTab === 'verification') && (
          <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-5">
            <div className="space-y-3">
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2"><Icon name="Search" size={14} color="var(--color-muted-foreground)" /></div>
                <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search clients..."
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 text-foreground placeholder:text-muted-foreground" />
              </div>
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/30 text-foreground">
                {statusOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              {!loading && clients.length > 0 && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground px-1">
                  <span>{filteredClients.length} of {clients.length}</span>
                  <span>·</span><span className="text-emerald-600">{clients.filter(c => c.kycStatus === 'verified').length} verified</span>
                  <span>·</span><span className="text-amber-600">{clients.filter(c => c.kycStatus === 'pending').length} pending</span>
                </div>
              )}
              <div className="space-y-2 max-h-[calc(100vh-340px)] overflow-y-auto pr-1">
                {loading ? (
                  <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                    <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg>
                    <p className="text-sm">Loading clients...</p>
                  </div>
                ) : filteredClients.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                    <Icon name="Users" size={28} color="currentColor" />
                    <p className="text-sm mt-2">{clients.length === 0 ? 'No clients yet' : 'No clients match filters'}</p>
                  </div>
                ) : (
                  filteredClients.map(client => (
                    <ClientKYCCard key={client.id} client={client} isSelected={selectedClientId === client.id} onClick={() => handleClientSelect(client.id)} />
                  ))
                )}
              </div>
            </div>

            <div className="space-y-4">
              {selectedClient ? (
                <>
                  <div className="bg-card border border-border rounded-xl px-5 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                        <Icon name="User" size={18} color="white" />
                      </div>
                      <div>
                        <p className="text-base font-bold text-foreground">{selectedClient.name}</p>
                        <p className="text-xs text-muted-foreground">{selectedClient.email}{selectedClient.accountNumber ? ` · ${selectedClient.accountNumber}` : ''}</p>
                      </div>
                    </div>
                    <KYCStatusBadge status={selectedClient.kycStatus || 'incomplete'} size="lg" />
                  </div>

                  {activeTab === 'documents' && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-card border border-border rounded-xl p-5">
                          <div className="flex items-center gap-2 mb-4"><div className="w-7 h-7 rounded-lg bg-blue-500/10 flex items-center justify-center"><Icon name="CreditCard" size={14} color="#3b82f6" /></div><h3 className="text-sm font-semibold text-foreground">Identity Document</h3></div>
                          <DocumentUploadZone label="National ID or Passport" docType="id" onUpload={setIdDocument} uploadedFile={idDocument} onRemove={() => setIdDocument(null)} />
                          {selectedClient.idDocument && !idDocument && <div className="mt-3 flex items-center gap-1.5 text-xs text-emerald-500"><Icon name="CheckCircle" size={12} color="currentColor" />Document already on file</div>}
                        </div>
                        <div className="bg-card border border-border rounded-xl p-5">
                          <div className="flex items-center gap-2 mb-4"><div className="w-7 h-7 rounded-lg bg-violet-500/10 flex items-center justify-center"><Icon name="BookOpen" size={14} color="#8b5cf6" /></div><h3 className="text-sm font-semibold text-foreground">Passport (Optional)</h3></div>
                          <DocumentUploadZone label="Passport Document" docType="passport" onUpload={setPassportDocument} uploadedFile={passportDocument} onRemove={() => setPassportDocument(null)} />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-card border border-border rounded-xl p-5">
                          <div className="flex items-center gap-2 mb-4"><div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center"><Icon name="Camera" size={14} color="#f59e0b" /></div><h3 className="text-sm font-semibold text-foreground">Photo Capture</h3></div>
                          <PhotoCapturePanel onPhotoCapture={setCapturedPhoto} capturedPhoto={capturedPhoto} onRemove={() => setCapturedPhoto(null)} />
                          {selectedClient.photo && !capturedPhoto && <div className="mt-3 flex items-center gap-1.5 text-xs text-emerald-500"><Icon name="CheckCircle" size={12} color="currentColor" />Photo already on file</div>}
                        </div>
                        <div className="bg-card border border-border rounded-xl p-5">
                          <div className="flex items-center gap-2 mb-4"><div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center"><Icon name="Shield" size={14} color="#10b981" /></div><h3 className="text-sm font-semibold text-foreground">KRA PIN</h3></div>
                          <KRAPINPanel value={kraPin} onChange={setKraPin} isVerified={kraPinVerified} onVerify={handleVerifyKRAPin} isVerifying={isVerifyingPin} />
                        </div>
                      </div>
                      <div className="bg-card border border-border rounded-xl p-5">
                        <div className="flex items-center gap-2 mb-4"><div className="w-7 h-7 rounded-lg bg-red-500/10 flex items-center justify-center"><Icon name="Calendar" size={14} color="#ef4444" /></div><h3 className="text-sm font-semibold text-foreground">Document Expiry Tracking</h3></div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-1.5"><label className="text-xs font-medium text-muted-foreground">ID / Passport Expiry Date</label><input type="date" defaultValue={selectedClient.documentExpiry || ''} className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 text-foreground" /></div>
                          <div className="space-y-1.5"><label className="text-xs font-medium text-muted-foreground">Reminder (days before)</label><select className="w-full px-3 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 text-foreground"><option value="30">30 days</option><option value="60">60 days</option><option value="90">90 days</option></select></div>
                        </div>
                        {selectedClient.documentExpiry && (() => {
                          const days = Math.ceil((new Date(selectedClient.documentExpiry) - new Date()) / 86400000);
                          if (days <= 30 && days > 0) return <div className="mt-3 flex items-center gap-2 p-3 bg-red-500/5 border border-red-500/20 rounded-lg"><Icon name="AlertTriangle" size={14} color="#ef4444" /><p className="text-xs text-red-500 font-medium">Document expires in {days} days</p></div>;
                          if (days <= 0) return <div className="mt-3 flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg"><Icon name="XCircle" size={14} color="#ef4444" /><p className="text-xs text-red-500 font-semibold">Document has expired</p></div>;
                          return null;
                        })()}
                      </div>
                      <div className="flex items-center justify-end gap-3">
                        {saveSuccess && <div className="flex items-center gap-1.5 text-emerald-500 text-sm font-medium"><Icon name="CheckCircle" size={14} color="currentColor" />Saved successfully</div>}
                        <button onClick={handleSaveDocuments} disabled={isSaving} className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50">
                          {isSaving ? <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"/></svg> : <Icon name="Save" size={14} color="white" />}
                          {isSaving ? 'Saving...' : 'Save Documents'}
                        </button>
                      </div>
                    </div>
                  )}
                  {activeTab === 'verification' && (
                    <VerificationWorkflow client={selectedClient} currentUser={currentUser} onApprove={handleApprove} onReject={handleReject} onRequestInfo={handleRequestInfo} />
                  )}
                </>
              ) : !loading ? (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground bg-card border border-border rounded-xl">
                  <Icon name="UserSearch" size={32} color="currentColor" />
                  <p className="text-sm mt-3">Select a client to view KYC details</p>
                </div>
              ) : null}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default KYCManagementScreen;
