import React, { useState } from 'react';
import MainLayout from '../../layouts/MainLayout';
import { useAuth } from '../../contexts/AuthContext';
import useClientPortal from '../../hooks/useClientPortal';
import Icon from '../../components/AppIcon';

import AccountSummary from './components/AccountSummary';
import MyAssetsTab from './components/MyAssetsTab';
import BrowseAssetsTab from './components/BrowseAssetsTab';
import PaymentsTab from './components/PaymentsTab';
import KYCTab from './components/KYCTab';

const Sk = ({ className }) => (
  <div className={'animate-pulse bg-muted rounded-lg ' + (className || '')} />
);

const Tab = ({ active, label, icon, badge, onClick }) => (
  <button
    onClick={onClick}
    className={'flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border ' + (
      active
        ? 'border-primary/40 text-primary'
        : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted'
    )}
    style={active ? { background: 'rgba(26,86,219,0.08)' } : {}}
  >
    <Icon name={icon} size={15} color="currentColor" />
    {label}
    {badge > 0 && (
      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold">
        {badge}
      </span>
    )}
  </button>
);

const ConnDot = ({ status }) => (
  <div className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border bg-card text-xs">
    <span className="relative flex h-2 w-2">
      {status === 'connected' && (
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
      )}
      <span className={'relative inline-flex rounded-full h-2 w-2 ' + (
        status === 'connected' ? 'bg-emerald-500' :
        status === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
      )} />
    </span>
    <span className={
      status === 'connected' ? 'text-emerald-600 font-semibold' :
      status === 'connecting' ? 'text-yellow-600 font-semibold' :
      'text-red-600 font-semibold'
    }>
      {status === 'connected' ? 'Live' :
       status === 'connecting' ? 'Connecting' : 'Offline'}
    </span>
  </div>
);

const ClientPortal = () => {
  const { userProfile } = useAuth();
  const {
    clientProfile,
    myAssets,
    browseAssets,
    payments,
    installmentPlans,
    enquiries,
    loading,
    connectionStatus,
    refetch,
    sendEnquiry,
    initiateMpesaPayment,
    exportPayments,
  } = useClientPortal();

  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview',  label: 'Overview',      icon: 'LayoutDashboard' },
    { id: 'myassets',  label: 'My Assets',      icon: 'Package',     badge: myAssets.length },
    { id: 'browse',    label: 'Browse Assets',  icon: 'ShoppingBag', badge: browseAssets.length },
    { id: 'payments',  label: 'Payments',       icon: 'CreditCard' },
    { id: 'kyc',       label: 'KYC Documents',  icon: 'Shield' },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #1A56DB, #1E429F)' }}
            >
              <Icon name="UserCircle" size={20} color="#fff" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">My Portal</h1>
              <p className="text-sm text-muted-foreground">
                Welcome, {(clientProfile && clientProfile.full_name) ? clientProfile.full_name : (userProfile && userProfile.full_name) ? userProfile.full_name : 'Client'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ConnDot status={connectionStatus} />
            <button
              onClick={refetch}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-border text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-all"
            >
              <Icon name="RefreshCw" size={12} color="currentColor" />
              Refresh
            </button>
          </div>
        </div>

        {!loading && clientProfile && clientProfile.kyc_status !== 'verified' && (
          <div className="flex items-center justify-between p-4 rounded-xl bg-yellow-50 border border-yellow-200">
            <div className="flex items-center gap-3">
              <Icon name="AlertTriangle" size={20} color="#ca8a04" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  KYC verification required
                </p>
                <p className="text-xs text-muted-foreground">
                  Upload your documents in the KYC tab to complete verification
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('kyc')}
              className="px-3 py-1.5 rounded-lg bg-yellow-500 text-white text-xs font-semibold hover:bg-yellow-600 transition-all"
            >
              Upload Now
            </button>
          </div>
        )}

        <div className="flex gap-1 flex-wrap">
          {tabs.map(function(t) {
            return (
              <Tab
                key={t.id}
                active={activeTab === t.id}
                label={t.label}
                icon={t.icon}
                badge={t.badge}
                onClick={() => setActiveTab(t.id)}
              />
            );
          })}
        </div>

        {loading ? (
          <div className="space-y-4">
            <Sk className="h-48" />
            <div className="grid grid-cols-2 gap-4">
              <Sk className="h-24" />
              <Sk className="h-24" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <Sk className="h-20" />
              <Sk className="h-20" />
              <Sk className="h-20" />
            </div>
          </div>
        ) : (
          <div>
            {activeTab === 'overview' && (
              <AccountSummary
                clientProfile={clientProfile}
                payments={payments}
                installmentPlans={installmentPlans}
              />
            )}
            {activeTab === 'myassets' && (
              <MyAssetsTab assets={myAssets} />
            )}
            {activeTab === 'browse' && (
              <BrowseAssetsTab
                assets={browseAssets}
                enquiries={enquiries}
                onEnquire={sendEnquiry}
              />
            )}
            {activeTab === 'payments' && (
              <PaymentsTab
                payments={payments}
                installmentPlans={installmentPlans}
                clientProfile={clientProfile}
                onPay={initiateMpesaPayment}
                onExport={exportPayments}
              />
            )}
            {activeTab === 'kyc' && (
              <KYCTab clientProfile={clientProfile} />
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default ClientPortal;