import React, { useState } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import ReportCard from './components/ReportCard';
import MetricCard from './components/MetricCard';
import ChartContainer from './components/ChartContainer';
import FilterPanel from './components/FilterPanel';
import ExportModal from './components/ExportModal';
import ScheduleReportModal from './components/ScheduleReportModal';
import CollectionPerformanceChart from './components/CollectionPerformanceChart';
import AgingAnalysisChart from './components/AgingAnalysisChart';
import SalesConversionChart from './components/SalesConversionChart';
import KYCMetricsDashboard from './components/KYCMetricsDashboard';
import MainLayout from '../../layouts/MainLayout';

const ReportsAnalyticsCenter = () => {
  const [userRole, setUserRole] = useState('director');
  const [activeTab, setActiveTab] = useState('overview');
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [exportToast, setExportToast] = useState(null);
  const [chartKey, setChartKey] = useState(0);
  const [filters, setFilters] = useState({
    dateRange: 'month',
    startDate: '',
    endDate: '',
    assetType: 'all',
    paymentMethod: 'all',
    region: 'all'
  });

  const roleOptions = [
    { value: 'director', label: 'Director' },
    { value: 'accountant', label: 'Accountant' },
    { value: 'admin', label: 'Administrator' }
  ];

  const executiveReports = [
    {
      id: 1,
      title: "Executive Dashboard",
      description: "High-level KPIs, collection efficiency trends, and strategic metrics for C-level decision making",
      icon: "LayoutDashboard",
      category: "Executive",
      lastGenerated: "02/25/2026 09:30 AM"
    },
    {
      id: 2,
      title: "Portfolio Performance",
      description: "Comprehensive asset portfolio analysis with performance indicators and growth trends",
      icon: "TrendingUp",
      category: "Executive",
      lastGenerated: "02/24/2026 02:15 PM"
    },
    {
      id: 3,
      title: "Strategic Insights",
      description: "Predictive analytics and strategic recommendations based on historical data patterns",
      icon: "Target",
      category: "Executive",
      lastGenerated: "02/23/2026 11:45 AM"
    }
  ];

  const financialReports = [
    {
      id: 4,
      title: "Fund Allocation Report",
      description: "Detailed breakdown of payment distribution across assets with percentage-based allocation analysis",
      icon: "DollarSign",
      category: "Financial",
      lastGenerated: "02/26/2026 08:00 AM"
    },
    {
      id: 5,
      title: "Aging Analysis",
      description: "Comprehensive aging breakdown showing 30/60/90+ days overdue accounts with collection priorities",
      icon: "Clock",
      category: "Financial",
      lastGenerated: "02/26/2026 07:30 AM"
    },
    {
      id: 6,
      title: "Payment Distribution",
      description: "Analysis of payment methods, transaction volumes, and processing efficiency by channel",
      icon: "CreditCard",
      category: "Financial",
      lastGenerated: "02/25/2026 04:20 PM"
    },
    {
      id: 7,
      title: "Revenue Recognition",
      description: "Accrual-based revenue tracking with installment recognition and deferred revenue analysis",
      icon: "Receipt",
      category: "Financial",
      lastGenerated: "02/24/2026 10:00 AM"
    }
  ];

  const operationalReports = [
    {
      id: 8,
      title: "Collection Performance",
      description: "Officer-wise collection tracking, efficiency metrics, and target achievement analysis",
      icon: "Users",
      category: "Operations",
      lastGenerated: "02/26/2026 09:15 AM"
    },
    {
      id: 9,
      title: "Sales Conversion Analysis",
      description: "Lead-to-closure conversion rates, sales cycle duration, and agent performance metrics",
      icon: "BarChart3",
      category: "Operations",
      lastGenerated: "02/25/2026 03:45 PM"
    },
    {
      id: 10,
      title: "Agent Performance",
      description: "Individual agent metrics including sales volume, commission earned, and ROI analysis",
      icon: "Award",
      category: "Operations",
      lastGenerated: "02/25/2026 01:30 PM"
    }
  ];

  const handleBulkExport = () => {
    const reports = getReportsForRole();
    const rows = [['Report Title', 'Category', 'Description', 'Last Generated']];
    reports.forEach(r => rows.push([r.title, r.category, r.description, r.lastGenerated]));
    const csv = rows.map(r => r.map(v => `"${(v || '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `all_reports_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApplyFilters = () => {
    // filters are already in state — charts read them via `filters` prop when implemented
    // trigger a visual refresh by forcing re-render
    setFilters(prev => ({ ...prev }));
  };

  const handleResetFilters = () => {
    setFilters({
      dateRange: 'month',
      startDate: '',
      endDate: '',
      assetType: 'all',
      paymentMethod: 'all',
      region: 'all'
    });
  };

  const handleGenerateReport = (report) => {
    setSelectedReport(report);
    setExportModalOpen(true);
  };

  const handleScheduleReport = (report) => {
    setSelectedReport(report);
    setScheduleModalOpen(true);
  };

  const handleExport = (exportConfig) => {
    const title = selectedReport?.title || 'Report';
    const date = new Date().toISOString().split('T')[0];
    if (exportConfig?.format === 'csv') {
      // Build a minimal CSV from the report metadata
      const rows = [
        ['Report', 'Generated', 'Format', 'Period'],
        [title, date, 'CSV', filters?.dateRange || 'month'],
      ];
      const csv = rows.map(r => r.map(v => `"${v}"`).join(',')).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${title.replace(/\s+/g, '_')}_${date}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      // PDF / Excel — show a toast that the report is being prepared
      setExportToast(`${title} export (${(exportConfig?.format || 'pdf').toUpperCase()}) is being prepared — check your downloads shortly.`);
      setTimeout(() => setExportToast(null), 5000);
    }
  };

  const handleSchedule = (scheduleConfig) => {
    const title = selectedReport?.title || 'Report';
    const recipients = (scheduleConfig?.recipients || []).filter(Boolean);
    if (recipients.length > 0) {
      setExportToast(`"${title}" scheduled ${scheduleConfig?.frequency || 'weekly'} — will be sent to ${recipients.length} recipient(s).`);
    } else {
      setExportToast(`"${title}" scheduled ${scheduleConfig?.frequency || 'weekly'}.`);
    }
    setTimeout(() => setExportToast(null), 5000);
  };

  const handleRefreshChart = () => {
    setChartKey(prev => prev + 1);
  };

  const handleExportChart = () => {
    setExportToast('Chart image download is not supported in this browser. Use the report Export button to download data.');
    setTimeout(() => setExportToast(null), 4000);
  };

  const getReportsForRole = () => {
    if (userRole === 'director') {
      return [...executiveReports, ...operationalReports];
    } else if (userRole === 'accountant') {
      return [...financialReports, ...operationalReports];
    }
    return [...executiveReports, ...financialReports, ...operationalReports];
  };

  return (
    <MainLayout>
      <div className="min-h-screen bg-background">
        <div className="max-w-[1600px] mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6 gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-heading font-semibold text-foreground mb-2">
                Reports & Analytics Center
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Comprehensive business intelligence and executive reporting
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <Select
                options={roleOptions}
                value={userRole}
                onChange={setUserRole}
                className="w-full sm:w-48"
              />
              <Button 
                variant="default" 
                iconName="Download" 
                iconPosition="left"
                onClick={handleBulkExport}
              >
                Bulk Export
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <MetricCard
              title="Total Revenue"
              value="$1,245,680"
              change="+12.5% vs last month"
              changeType="positive"
              icon="DollarSign"
              iconColor="bg-success bg-opacity-10 text-success"
            />
            <MetricCard
              title="Collection Rate"
              value="94.3%"
              change="+2.1% vs last month"
              changeType="positive"
              icon="TrendingUp"
              iconColor="bg-primary bg-opacity-10 text-primary"
            />
            <MetricCard
              title="Outstanding Balance"
              value="$325,000"
              change="-8.4% vs last month"
              changeType="positive"
              icon="AlertCircle"
              iconColor="bg-warning bg-opacity-10 text-warning"
            />
            <MetricCard
              title="Active Clients"
              value="1,847"
              change="+156 this month"
              changeType="positive"
              icon="Users"
              iconColor="bg-accent bg-opacity-10 text-accent"
            />
          </div>

          <FilterPanel
            filters={filters}
            onFilterChange={handleFilterChange}
            onApply={handleApplyFilters}
            onReset={handleResetFilters}
          />

          <div className="mt-6 mb-6">
            <div className="flex items-center space-x-2 overflow-x-auto scrollbar-custom pb-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-shrink-0 px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                  activeTab === 'overview' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:bg-muted-foreground hover:text-muted'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('reports')}
                className={`flex-shrink-0 px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                  activeTab === 'reports' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:bg-muted-foreground hover:text-muted'
                }`}
              >
                Available Reports
              </button>
              <button
                onClick={() => setActiveTab('scheduled')}
                className={`flex-shrink-0 px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                  activeTab === 'scheduled' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:bg-muted-foreground hover:text-muted'
                }`}
              >
                Scheduled Reports
              </button>
              <button
                onClick={() => setActiveTab('kyc')}
                className={`flex-shrink-0 px-4 py-2 rounded-md text-sm font-medium transition-smooth ${
                  activeTab === 'kyc' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground hover:bg-muted-foreground hover:text-muted'
                }`}
              >
                KYC Metrics
              </button>
            </div>
          </div>

          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ChartContainer
                  title="Collection Performance Trend"
                  onExport={handleExportChart}
                  onRefresh={handleRefreshChart}
                >
                  <CollectionPerformanceChart />
                </ChartContainer>

                <ChartContainer
                  title="Aging Analysis Distribution"
                  onExport={handleExportChart}
                  onRefresh={handleRefreshChart}
                >
                  <AgingAnalysisChart />
                </ChartContainer>
              </div>

              <ChartContainer
                title="Sales Conversion Analysis"
                onExport={handleExportChart}
                onRefresh={handleRefreshChart}
              >
                <SalesConversionChart />
              </ChartContainer>

              <div className="bg-card border border-border rounded-lg p-4 md:p-6">
                <h3 className="text-lg md:text-xl font-semibold text-foreground mb-4">
                  Key Insights
                </h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3 p-3 rounded-md bg-success bg-opacity-10">
                    <Icon name="TrendingUp" size={20} color="var(--color-success)" />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        Collection efficiency improved by 12.5% this quarter
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Driven by enhanced follow-up processes and automated reminders
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-3 rounded-md bg-warning bg-opacity-10">
                    <Icon name="AlertTriangle" size={20} color="var(--color-warning)" />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        18 accounts moved to 90+ days overdue category
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Immediate collection action required for $18,000 in outstanding balance
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-3 rounded-md bg-primary bg-opacity-10">
                    <Icon name="Target" size={20} color="var(--color-primary)" />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        Sales conversion rate reached 35.6% in May
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Highest conversion rate in the past 12 months, exceeding target by 8.6%
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'reports' && (
            <div className="space-y-6">
              {userRole === 'director' && (
                <div>
                  <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-4">
                    Executive Reports
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {executiveReports?.map(report => (
                      <ReportCard
                        key={report?.id}
                        {...report}
                        onGenerate={() => handleGenerateReport(report)}
                        onSchedule={() => handleScheduleReport(report)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {(userRole === 'accountant' || userRole === 'admin') && (
                <div>
                  <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-4">
                    Financial Reports
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {financialReports?.map(report => (
                      <ReportCard
                        key={report?.id}
                        {...report}
                        onGenerate={() => handleGenerateReport(report)}
                        onSchedule={() => handleScheduleReport(report)}
                      />
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-4">
                  Operational Reports
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {operationalReports?.map(report => (
                    <ReportCard
                      key={report?.id}
                      {...report}
                      onGenerate={() => handleGenerateReport(report)}
                      onSchedule={() => handleScheduleReport(report)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'kyc' && (
            <KYCMetricsDashboard />
          )}

          {activeTab === 'scheduled' && (
            <div className="bg-card border border-border rounded-lg p-4 md:p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl md:text-2xl font-semibold text-foreground">
                  Scheduled Reports
                </h2>
                <Button 
                  variant="default" 
                  iconName="Plus" 
                  iconPosition="left"
                  onClick={() => { setSelectedReport({ title: 'Custom Schedule' }); setScheduleModalOpen(true); }}
                >
                  New Schedule
                </Button>
              </div>

              <div className="space-y-3">
                {[
                  {
                    name: "Executive Dashboard",
                    frequency: "Weekly",
                    nextRun: "03/03/2026 09:00 AM",
                    recipients: 3
                  },
                  {
                    name: "Aging Analysis",
                    frequency: "Daily",
                    nextRun: "02/27/2026 08:00 AM",
                    recipients: 5
                  },
                  {
                    name: "Collection Performance",
                    frequency: "Monthly",
                    nextRun: "03/01/2026 10:00 AM",
                    recipients: 2
                  }
                ]?.map((schedule, index) => (
                  <div
                    key={index}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 rounded-md border border-border hover:bg-muted transition-smooth"
                  >
                    <div className="mb-3 sm:mb-0">
                      <p className="text-sm font-medium text-foreground">{schedule?.name}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-xs text-muted-foreground">
                          <Icon name="Clock" size={12} color="currentColor" className="inline mr-1" />
                          {schedule?.frequency}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          <Icon name="Users" size={12} color="currentColor" className="inline mr-1" />
                          {schedule?.recipients} recipients
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Next run: {schedule?.nextRun}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        iconName="Edit"
                        iconPosition="left"
                        onClick={() => setExportToast('Schedule editing coming soon — contact your super admin to modify schedules.')}
                      />
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        iconName="Trash2"
                        iconPosition="left"
                        onClick={() => setExportToast('Schedule deletion coming soon — contact your super admin to remove schedules.')}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <ExportModal
          isOpen={exportModalOpen}
          onClose={() => setExportModalOpen(false)}
          reportTitle={selectedReport?.title || ''}
          onExport={handleExport}
        />
        <ScheduleReportModal
          isOpen={scheduleModalOpen}
          onClose={() => setScheduleModalOpen(false)}
          reportTitle={selectedReport?.title || ''}
          onSchedule={handleSchedule}
        />
      </div>
    {exportToast && (
        <div className="fixed bottom-6 right-6 z-[300] flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg bg-blue-600 text-white text-sm font-medium max-w-sm">
          <Icon name="Info" size={16} color="white" />
          <span>{exportToast}</span>
          <button onClick={() => setExportToast(null)} className="ml-2 opacity-70 hover:opacity-100">
            <Icon name="X" size={14} color="white" />
          </button>
        </div>
      )}
    </MainLayout>
  );
};

export default ReportsAnalyticsCenter;