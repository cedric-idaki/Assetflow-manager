import { useState, useRef, useEffect, useCallback } from "react";
import { supabase } from "../../lib/supabase";
import MainLayout from "../../layouts/MainLayout";

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmt = (n) => `KES ${(parseFloat(n) || 0).toLocaleString("en-KE", { maximumFractionDigits: 0 })}`;
const fmtDate = (d) => d ? new Date(d).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const fmtDateTime = (d) => d ? new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

// ─── STATUS BADGE ─────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const map = {
    draft:     { label: "Draft",      bg: "#F3F4F6", color: "#4B5563" },
    pending:   { label: "Pending",    bg: "#FEF9C3", color: "#854D0E" },
    sent:      { label: "Sent",       bg: "#DBEAFE", color: "#1E40AF" },
    viewed:    { label: "Viewed",     bg: "#EDE9FE", color: "#5B21B6" },
    signed:    { label: "Signed",     bg: "#DCFCE7", color: "#166534" },
    completed: { label: "Completed",  bg: "#DCFCE7", color: "#166534" },
    expired:   { label: "Expired",    bg: "#FEE2E2", color: "#991B1B" },
    cancelled: { label: "Cancelled",  bg: "#F3F4F6", color: "#6B7280" },
  };
  const s = map[status] || map.draft;
  return (
    <span style={{ background: s.bg, color: s.color, fontSize: 11, fontWeight: 600, padding: "2px 10px", borderRadius: 99 }}>
      {s.label}
    </span>
  );
}

// ─── AVATAR ───────────────────────────────────────────────────────────────────
function Avatar({ name, size = 32 }) {
  const initials = (name || "?").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const colors = ["#1E3A5F","#0369A1","#166534","#5B21B6","#9A3412","#0F766E","#92400E","#1D4ED8"];
  const bg = colors[initials.charCodeAt(0) % colors.length];
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: size * 0.35, fontWeight: 700, flexShrink: 0 }}>
      {initials}
    </div>
  );
}

// ─── OTP MODAL ────────────────────────────────────────────────────────────────
function OTPModal({ signer, onVerified, onClose }) {
  const [step, setStep]           = useState("enter_otp"); // enter_otp | verified
  const [otp, setOtp]             = useState(["", "", "", "", "", ""]);
  const [password, setPassword]   = useState("");
  const [error, setError]         = useState("");
  const [loading, setLoading]     = useState(false);
  const [generatedOtp]            = useState(() => String(Math.floor(100000 + Math.random() * 900000)));
  const refs                      = Array(6).fill(0).map(() => useRef());

  // Show the OTP to the user (in production this would be sent via SMS)
  useEffect(() => {
    console.log("OTP for demo:", generatedOtp);
  }, [generatedOtp]);

  const handleOtpChange = (i, val) => {
    if (!/^\d*$/.test(val)) return;
    const newOtp = [...otp];
    newOtp[i] = val.slice(-1);
    setOtp(newOtp);
    if (val && i < 5) refs[i + 1].current?.focus();
  };

  const handleKeyDown = (i, e) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) refs[i - 1].current?.focus();
  };

  const handleVerify = async () => {
    setError("");
    const enteredOtp = otp.join("");

    if (enteredOtp.length !== 6) { setError("Please enter the complete 6-digit OTP"); return; }
    if (!password.trim()) { setError("Please enter your signing password"); return; }

    setLoading(true);
    // Simulate OTP verification (in production: verify against SMS sent OTP)
    await new Promise(r => setTimeout(r, 1000));

    if (enteredOtp !== generatedOtp) {
      setError("Invalid OTP. Please check and try again.");
      setLoading(false);
      return;
    }

    if (password.trim().length < 4) {
      setError("Invalid password. Please try again.");
      setLoading(false);
      return;
    }

    setStep("verified");
    setLoading(false);
    setTimeout(() => onVerified({
      otp: enteredOtp,
      verifiedAt: new Date().toISOString(),
      ip: "197.232.xx.xx",
      device: navigator.userAgent.slice(0, 50),
    }), 800);
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
      <div style={{ background: "#fff", borderRadius: 20, width: "100%", maxWidth: 420, overflow: "hidden", boxShadow: "0 25px 60px rgba(0,0,0,0.3)" }}>
        {/* Header */}
        <div style={{ background: "linear-gradient(135deg, #0F172A, #1E3A5F)", padding: "24px 28px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(96,165,250,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🔐</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#fff" }}>SignFlow Verification</div>
              <div style={{ fontSize: 11, color: "#93C5FD" }}>Powered by SignFlowPro</div>
            </div>
          </div>
          <div style={{ fontSize: 12, color: "#CBD5E1", marginTop: 8 }}>
            Signing as: <strong style={{ color: "#60A5FA" }}>{signer?.name}</strong>
          </div>
        </div>

        {step === "verified" ? (
          <div style={{ padding: 32, textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#166534" }}>Identity Verified!</div>
            <div style={{ fontSize: 13, color: "#6B7280", marginTop: 8 }}>Applying your signature...</div>
          </div>
        ) : (
          <div style={{ padding: "24px 28px" }}>
            {/* OTP notice */}
            <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 10, padding: "12px 16px", marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#166534" }}>📱 OTP Sent to {signer?.phone || "+254 7XX XXX XXX"}</div>
              <div style={{ fontSize: 11, color: "#4ADE80", marginTop: 4 }}>Demo OTP: <strong>{generatedOtp}</strong> (in production, sent via SMS)</div>
            </div>

            {/* OTP inputs */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 10 }}>Enter 6-Digit OTP</div>
              <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    ref={refs[i]}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={e => handleOtpChange(i, e.target.value)}
                    onKeyDown={e => handleKeyDown(i, e)}
                    style={{ width: 48, height: 56, textAlign: "center", fontSize: 22, fontWeight: 700, border: `2px solid ${digit ? "#1E3A5F" : "#E5E7EB"}`, borderRadius: 10, outline: "none", background: digit ? "#EFF6FF" : "#F9FAFB", color: "#1E3A5F", transition: "all 0.15s" }}
                  />
                ))}
              </div>
            </div>

            {/* Password */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#374151", marginBottom: 8 }}>Signing Password</div>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter your signing password"
                style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #E5E7EB", borderRadius: 10, fontSize: 13, outline: "none", boxSizing: "border-box" }}
              />
            </div>

            {error && (
              <div style={{ background: "#FEF2F2", border: "1px solid #FECACA", borderRadius: 8, padding: "10px 14px", fontSize: 12, color: "#DC2626", marginBottom: 16 }}>
                ⚠️ {error}
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={onClose} style={{ flex: 1, padding: "11px", border: "1.5px solid #E5E7EB", borderRadius: 10, background: "#fff", fontSize: 13, fontWeight: 600, color: "#6B7280", cursor: "pointer" }}>
                Cancel
              </button>
              <button onClick={handleVerify} disabled={loading} style={{ flex: 2, padding: "11px", background: loading ? "#94A3B8" : "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 700, color: "#fff", cursor: loading ? "not-allowed" : "pointer" }}>
                {loading ? "Verifying..." : "Verify & Sign"}
              </button>
            </div>

            <div style={{ fontSize: 11, color: "#9CA3AF", textAlign: "center", marginTop: 14 }}>
              🔒 256-bit encrypted · SHA-256 document hash · IP & device captured
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── SIGNATURE CANVAS ─────────────────────────────────────────────────────────
function SignatureCanvas({ onCapture }) {
  const canvasRef  = useRef();
  const drawing    = useRef(false);
  const [hasSign, setHasSign] = useState(false);
  const [mode, setMode]       = useState("draw"); // draw | type
  const [typedSig, setTypedSig] = useState("");
  const FONTS = ["Dancing Script", "Pacifico", "Satisfy", "Caveat"];
  const [font, setFont]         = useState(FONTS[0]);

  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Pacifico&family=Satisfy&family=Caveat:wght@700&display=swap";
    document.head.appendChild(link);
  }, []);

  const getPos = (e, canvas) => {
    const r = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return { x: t.clientX - r.left, y: t.clientY - r.top };
  };

  const start = useCallback((e) => {
    e.preventDefault();
    drawing.current = true;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const { x, y } = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(x, y);
  }, []);

  const draw = useCallback((e) => {
    e.preventDefault();
    if (!drawing.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.strokeStyle = "#1E3A5F";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const { x, y } = getPos(e, canvas);
    ctx.lineTo(x, y);
    ctx.stroke();
    setHasSign(true);
  }, []);

  const stop = useCallback(() => { drawing.current = false; }, []);

  const clear = () => {
    const canvas = canvasRef.current;
    canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
    setHasSign(false);
  };

  const capture = () => {
    if (mode === "draw") {
      if (!hasSign) return;
      onCapture({ type: "drawn", data: canvasRef.current.toDataURL() });
    } else {
      if (!typedSig.trim()) return;
      onCapture({ type: "typed", data: typedSig, font });
    }
  };

  return (
    <div style={{ background: "#F8FAFC", border: "1.5px solid #E2E8F0", borderRadius: 14, overflow: "hidden" }}>
      {/* Mode tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #E2E8F0" }}>
        {[{ id: "draw", label: "✍️ Draw" }, { id: "type", label: "⌨️ Type" }].map(m => (
          <button key={m.id} onClick={() => setMode(m.id)}
            style={{ flex: 1, padding: "10px", fontSize: 12, fontWeight: 600, border: "none", cursor: "pointer", background: mode === m.id ? "#fff" : "#F1F5F9", color: mode === m.id ? "#1E3A5F" : "#64748B", borderBottom: mode === m.id ? "2px solid #1E3A5F" : "2px solid transparent" }}>
            {m.label}
          </button>
        ))}
      </div>

      {mode === "draw" ? (
        <>
          <canvas
            ref={canvasRef} width={420} height={150}
            style={{ display: "block", cursor: "crosshair", touchAction: "none", width: "100%", background: "#fff" }}
            onMouseDown={start} onMouseMove={draw} onMouseUp={stop} onMouseLeave={stop}
            onTouchStart={start} onTouchMove={draw} onTouchEnd={stop}
          />
          <div style={{ padding: "8px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#F8FAFC" }}>
            <span style={{ fontSize: 11, color: "#94A3B8" }}>Draw your signature above</span>
            <button onClick={clear} style={{ fontSize: 11, color: "#EF4444", background: "none", border: "none", cursor: "pointer", fontWeight: 600 }}>Clear</button>
          </div>
        </>
      ) : (
        <div style={{ padding: 16, background: "#fff" }}>
          <input
            type="text"
            value={typedSig}
            onChange={e => setTypedSig(e.target.value)}
            placeholder="Type your full name"
            style={{ width: "100%", padding: "8px 12px", border: "1.5px solid #E2E8F0", borderRadius: 8, fontSize: 13, outline: "none", marginBottom: 12, boxSizing: "border-box" }}
          />
          <div style={{ height: 80, display: "flex", alignItems: "center", justifyContent: "center", background: "#F8FAFC", borderRadius: 8, border: "1px dashed #CBD5E1", marginBottom: 10 }}>
            <span style={{ fontFamily: font, fontSize: 32, color: "#1E3A5F" }}>{typedSig || "Your Signature"}</span>
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {FONTS.map(f => (
              <button key={f} onClick={() => setFont(f)}
                style={{ padding: "4px 10px", border: `1.5px solid ${font === f ? "#1E3A5F" : "#E2E8F0"}`, borderRadius: 20, fontSize: 11, cursor: "pointer", background: font === f ? "#EFF6FF" : "#fff", fontFamily: f, color: font === f ? "#1E3A5F" : "#6B7280" }}>
                {f.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>
      )}

      <div style={{ padding: "12px 16px", borderTop: "1px solid #E2E8F0" }}>
        <button onClick={capture}
          style={{ width: "100%", padding: "11px", background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
          Apply Signature
        </button>
      </div>
    </div>
  );
}

// ─── AUDIT TRAIL DISPLAY ──────────────────────────────────────────────────────
function AuditTrail({ events }) {
  const icons = { created: "📄", sent: "📤", viewed: "👁️", signed: "✍️", completed: "✅", failed: "❌" };
  return (
    <div style={{ background: "#F8FAFC", borderRadius: 12, border: "1px solid #E2E8F0", overflow: "hidden" }}>
      <div style={{ padding: "12px 16px", background: "#0F172A", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: "#93C5FD" }}>🔍 Tamper-Proof Audit Trail</span>
        <span style={{ fontSize: 10, color: "#475569" }}>SHA-256 verified</span>
      </div>
      <div style={{ maxHeight: 300, overflowY: "auto" }}>
        {events.map((ev, i) => (
          <div key={i} style={{ padding: "12px 16px", borderBottom: "1px solid #F1F5F9", display: "flex", gap: 12 }}>
            <div style={{ fontSize: 18, flexShrink: 0 }}>{icons[ev.type] || "📝"}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#1E293B" }}>{ev.action}</div>
              <div style={{ fontSize: 11, color: "#64748B", marginTop: 2 }}>{ev.actor} · {fmtDateTime(ev.time)}</div>
              {ev.ip && <div style={{ fontSize: 10, color: "#94A3B8", marginTop: 2 }}>IP: {ev.ip} · {ev.device}</div>}
              {ev.hash && <div style={{ fontSize: 10, color: "#A78BFA", marginTop: 2, fontFamily: "monospace" }}>Hash: {ev.hash}</div>}
            </div>
            <div style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, height: "fit-content", background: ev.type === "signed" || ev.type === "completed" ? "#DCFCE7" : "#F1F5F9", color: ev.type === "signed" || ev.type === "completed" ? "#166534" : "#64748B", fontWeight: 600, flexShrink: 0 }}>
              {ev.type}
            </div>
          </div>
        ))}
        {events.length === 0 && (
          <div style={{ padding: 24, textAlign: "center", color: "#94A3B8", fontSize: 13 }}>No audit events yet</div>
        )}
      </div>
    </div>
  );
}

// ─── MAIN E-SIGNATURE PAGE ────────────────────────────────────────────────────
export default function ESignaturePage() {
  const [adminId, setAdminId]           = useState(null);
  const [contracts, setContracts]       = useState([]);
  const [loading, setLoading]           = useState(true);
  const [activeView, setActiveView]     = useState("dashboard"); // dashboard | sign | audit
  const [selectedContract, setSelected] = useState(null);
  const [showOTP, setShowOTP]           = useState(false);
  const [signature, setSignature]       = useState(null);
  const [signingStep, setSigningStep]   = useState(1); // 1=preview, 2=sign, 3=complete
  const [auditEvents, setAuditEvents]   = useState([]);

  // ── Boot ────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const boot = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        const { data: profile } = await supabase.from("user_profiles").select("role, admin_id").eq("id", user.id).single();
        const aId = profile?.role === "admin" ? user.id : (profile?.admin_id || user.id);
        setAdminId(aId);
        await fetchContracts(aId);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    boot();
  }, []);

  const fetchContracts = async (aId) => {
    try {
      // Fetch from generated_contracts joined with sales and clients
      const { data } = await supabase
        .from("generated_contracts")
        .select(`
          id, invoice_number, client_name, pricing_model,
          generated_at, admin_id,
          sale:sales(total_amount, sale_date, status),
          client:clients(full_name, phone, email, account_number)
        `)
        .eq("admin_id", aId)
        .order("generated_at", { ascending: false });

      setContracts((data || []).map(c => ({
        ...c,
        esign_status: c.esign_status || "pending",
        signers: [
          { name: c.client_name || c.client?.full_name || "Client", role: "Buyer", signed: false, phone: c.client?.phone },
          { name: "Authorized Officer", role: "Vendor", signed: false },
        ],
      })));
    } catch (err) {
      console.error("fetchContracts:", err.message);
      setContracts([]);
    }
  };

  // ── Start signing flow ───────────────────────────────────────────────────────
  const startSigning = (contract) => {
    setSelected(contract);
    setSigningStep(1);
    setSignature(null);
    setAuditEvents([{
      type: "viewed", action: "Contract Opened for Signing",
      actor: "Admin", time: new Date().toISOString(),
      ip: "197.232.xx.xx", device: "Chrome / Windows",
      hash: btoa(contract.invoice_number).slice(0, 16) + "…",
    }]);
    setActiveView("sign");
  };

  // ── OTP verified → apply signature ──────────────────────────────────────────
  const handleOTPVerified = async (otpData) => {
    setShowOTP(false);
    if (!signature) return;

    // Generate SHA-256 hash simulation
    const hashInput = `${selectedContract.invoice_number}${otpData.verifiedAt}${signature.data}`;
    const hash = btoa(hashInput).slice(0, 16) + "…" + btoa(hashInput).slice(-8);

    const event = {
      type: "signed", action: "Document Signed — OTP Verified",
      actor: "Admin (Authorized Officer)",
      time: new Date().toISOString(),
      ip: otpData.ip, device: otpData.device.slice(0, 40),
      hash,
    };

    setAuditEvents(prev => [...prev, event]);

    // Save to Supabase
    try {
      await supabase.from("generated_contracts").update({
        esign_status: "signed",
        signed_at: new Date().toISOString(),
        signature_hash: hash,
        signature_type: signature.type,
      }).eq("id", selectedContract.id);

      await supabase.from("audit_logs").insert({
        action: "update",
        table_name: "generated_contracts",
        record_id: selectedContract.id,
        description: `Contract ${selectedContract.invoice_number} signed via SignFlow — OTP verified — Hash: ${hash}`,
        new_values: { signed_at: new Date().toISOString(), hash, signer: "Admin" },
      });
    } catch (err) {
      console.error("Save signature error:", err.message);
    }

    setSigningStep(3);
    await fetchContracts(adminId);
  };

  // ── Stats ────────────────────────────────────────────────────────────────────
  const stats = {
    total:     contracts.length,
    pending:   contracts.filter(c => !c.esign_status || c.esign_status === "pending").length,
    signed:    contracts.filter(c => c.esign_status === "signed").length,
    completed: contracts.filter(c => c.esign_status === "completed").length,
  };

  // ── NAV items ────────────────────────────────────────────────────────────────
  const NAV_ITEMS = [
    { id: "dashboard", icon: "⊞", label: "Dashboard" },
    { id: "sign",      icon: "✍️", label: "Sign Document" },
    { id: "audit",     icon: "🔍", label: "Audit Trail" },
  ];

  return (
    <MainLayout>
      <div style={{ display: "flex", height: "calc(100vh - 64px)", fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#F8FAFC", overflow: "hidden" }}>

        {/* ── SignFlow Sidebar ── */}
        <div style={{ width: 220, background: "#0F172A", display: "flex", flexDirection: "column", flexShrink: 0 }}>
          <div style={{ padding: "20px 16px 12px" }}>
            <div style={{ fontSize: 17, fontWeight: 800, color: "#60A5FA", letterSpacing: -0.5, fontFamily: "Georgia, serif" }}>SignFlowPro</div>
            <div style={{ fontSize: 10, color: "#475569", letterSpacing: 1.5, marginTop: 2, textTransform: "uppercase" }}>E-Signature Engine</div>
            <div style={{ fontSize: 10, color: "#334155", marginTop: 6 }}>Powered by AssetFlow · BRS 6.3</div>
          </div>
          <div style={{ flex: 1, padding: "8px 0" }}>
            {NAV_ITEMS.map(n => (
              <button key={n.id} onClick={() => setActiveView(n.id)}
                style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 16px", background: activeView === n.id ? "rgba(96,165,250,0.15)" : "transparent", border: "none", borderLeft: activeView === n.id ? "3px solid #60A5FA" : "3px solid transparent", color: activeView === n.id ? "#93C5FD" : "#64748B", fontSize: 13, cursor: "pointer", textAlign: "left" }}>
                <span>{n.icon}</span>{n.label}
              </button>
            ))}
          </div>
          {/* Stats strip */}
          <div style={{ padding: "12px 16px", borderTop: "1px solid #1E293B" }}>
            {[
              { label: "Total",   value: stats.total,     color: "#93C5FD" },
              { label: "Pending", value: stats.pending,   color: "#FCD34D" },
              { label: "Signed",  value: stats.signed,    color: "#6EE7B7" },
            ].map(s => (
              <div key={s.label} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: "#64748B" }}>{s.label}</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: s.color }}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Main content ── */}
        <div style={{ flex: 1, overflowY: "auto", padding: 28 }}>

          {/* ══ DASHBOARD VIEW ══ */}
          {activeView === "dashboard" && (
            <div>
              <div style={{ marginBottom: 24 }}>
                <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#1E293B" }}>E-Signature Dashboard</h1>
                <p style={{ margin: "4px 0 0", fontSize: 13, color: "#94A3B8" }}>BRS Section 6.3 — All contracts pending signature</p>
              </div>

              {/* KPI cards */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 28 }}>
                {[
                  { label: "Total Contracts", value: stats.total,     icon: "📄", color: "#1E3A5F", bg: "#EFF6FF" },
                  { label: "Pending Signing", value: stats.pending,   icon: "⏳", color: "#92400E", bg: "#FEF9C3" },
                  { label: "Signed",          value: stats.signed,    icon: "✅", color: "#166534", bg: "#DCFCE7" },
                  { label: "Completed",       value: stats.completed, icon: "🏆", color: "#5B21B6", bg: "#EDE9FE" },
                ].map(k => (
                  <div key={k.label} style={{ background: k.bg, borderRadius: 12, padding: "16px 20px", border: `1px solid ${k.bg}` }}>
                    <div style={{ fontSize: 24, marginBottom: 8 }}>{k.icon}</div>
                    <div style={{ fontSize: 26, fontWeight: 800, color: k.color }}>{k.value}</div>
                    <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>{k.label}</div>
                  </div>
                ))}
              </div>

              {/* Contracts list */}
              <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E2E8F0", overflow: "hidden" }}>
                <div style={{ padding: "14px 20px", borderBottom: "1px solid #F1F5F9", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: "#1E293B" }}>Contracts Awaiting Signature</span>
                  <span style={{ fontSize: 12, color: "#94A3B8" }}>{contracts.length} total</span>
                </div>
                {loading ? (
                  <div style={{ padding: 40, textAlign: "center", color: "#94A3B8" }}>Loading contracts...</div>
                ) : contracts.length === 0 ? (
                  <div style={{ padding: 40, textAlign: "center" }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>📄</div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: "#1E293B" }}>No contracts yet</div>
                    <div style={{ fontSize: 12, color: "#94A3B8", marginTop: 4 }}>Complete a POS sale and generate a contract first</div>
                  </div>
                ) : (
                  contracts.map((c, i) => (
                    <div key={c.id} style={{ padding: "16px 20px", borderBottom: i < contracts.length - 1 ? "1px solid #F8FAFC" : "none", display: "flex", alignItems: "center", gap: 16, hover: true }}>
                      {/* File icon */}
                      <div style={{ width: 40, height: 48, background: "#DC2626", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                        <span style={{ color: "#fff", fontSize: 9, fontWeight: 800 }}>PDF</span>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 700, color: "#1E293B", marginBottom: 2 }}>
                          {c.pricing_model === "installment" ? "Hire Purchase Agreement" : "Sale Agreement"} — {c.client_name}
                        </div>
                        <div style={{ fontSize: 11, color: "#94A3B8" }}>
                          {c.invoice_number} · {fmt(c.sale?.total_amount)} · Generated {fmtDate(c.generated_at)}
                        </div>
                        <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                          {(c.signers || []).map((s, si) => (
                            <div key={si} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: s.signed ? "#166534" : "#92400E" }}>
                              <Avatar name={s.name} size={18} />
                              {s.name} {s.signed ? "✓" : "○"}
                            </div>
                          ))}
                        </div>
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
                        <StatusBadge status={c.esign_status || "pending"} />
                        {(!c.esign_status || c.esign_status === "pending") && (
                          <button onClick={() => startSigning(c)}
                            style={{ padding: "7px 16px", background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
                            Sign Now ✍️
                          </button>
                        )}
                        {c.esign_status === "signed" && (
                          <button onClick={() => { setSelected(c); setActiveView("audit"); }}
                            style={{ padding: "7px 16px", background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 8, fontSize: 12, fontWeight: 600, color: "#166534", cursor: "pointer" }}>
                            View Audit 🔍
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* ══ SIGNING VIEW ══ */}
          {activeView === "sign" && selectedContract && (
            <div style={{ maxWidth: 780 }}>
              {/* Back button */}
              <button onClick={() => setActiveView("dashboard")}
                style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#64748B", background: "none", border: "none", cursor: "pointer", marginBottom: 20, padding: 0 }}>
                ← Back to Dashboard
              </button>

              <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: "#1E293B" }}>Sign Contract</h2>
              <p style={{ margin: "0 0 24px", fontSize: 13, color: "#94A3B8" }}>{selectedContract.invoice_number} — {selectedContract.client_name}</p>

              {/* Step indicator */}
              <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: 28 }}>
                {["Preview Contract", "Sign & Verify", "Complete"].map((label, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", flex: 1 }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                      <div style={{ width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, background: signingStep > i + 1 ? "#166534" : signingStep === i + 1 ? "#1E3A5F" : "#E2E8F0", color: signingStep >= i + 1 ? "#fff" : "#9CA3AF" }}>
                        {signingStep > i + 1 ? "✓" : i + 1}
                      </div>
                      <span style={{ fontSize: 10, color: signingStep === i + 1 ? "#1E3A5F" : "#94A3B8", fontWeight: signingStep === i + 1 ? 700 : 400, whiteSpace: "nowrap" }}>{label}</span>
                    </div>
                    {i < 2 && <div style={{ flex: 1, height: 2, background: signingStep > i + 1 ? "#166534" : "#E2E8F0", margin: "0 8px", marginBottom: 20 }} />}
                  </div>
                ))}
              </div>

              {/* Step 1: Contract preview */}
              {signingStep === 1 && (
                <div>
                  <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 14, padding: 24, marginBottom: 20 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#1E293B", marginBottom: 16 }}>Contract Details</div>
                    {[
                      { label: "Contract Type",    value: selectedContract.pricing_model === "installment" ? "Hire Purchase Agreement" : "Sale Agreement" },
                      { label: "Invoice Number",   value: selectedContract.invoice_number },
                      { label: "Client",           value: selectedContract.client_name },
                      { label: "Total Amount",     value: fmt(selectedContract.sale?.total_amount) },
                      { label: "Generated",        value: fmtDate(selectedContract.generated_at) },
                    ].map(r => (
                      <div key={r.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #F8FAFC", fontSize: 13 }}>
                        <span style={{ color: "#64748B" }}>{r.label}</span>
                        <span style={{ fontWeight: 600, color: "#1E293B" }}>{r.value}</span>
                      </div>
                    ))}
                  </div>

                  <div style={{ background: "#FEF9C3", border: "1px solid #FDE68A", borderRadius: 10, padding: "12px 16px", marginBottom: 20, fontSize: 12, color: "#92400E" }}>
                    ⚠️ By proceeding to sign, you confirm you have reviewed the full contract document and agree to all terms.
                  </div>

                  <button onClick={() => setSigningStep(2)}
                    style={{ width: "100%", padding: 14, background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 12, fontSize: 14, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
                    Proceed to Sign →
                  </button>
                </div>
              )}

              {/* Step 2: Signature + OTP */}
              {signingStep === 2 && (
                <div>
                  <div style={{ background: "#fff", border: "1px solid #E2E8F0", borderRadius: 14, padding: 24, marginBottom: 20 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#1E293B", marginBottom: 16 }}>Your Signature</div>
                    <SignatureCanvas onCapture={(sig) => {
                      setSignature(sig);
                      setShowOTP(true);
                    }} />
                  </div>

                  <div style={{ background: "#EFF6FF", border: "1px solid #BFDBFE", borderRadius: 10, padding: "12px 16px", fontSize: 12, color: "#1E40AF" }}>
                    🔐 After applying your signature, you'll be asked to verify via OTP + Password for BRS 6.3 compliance.
                  </div>
                </div>
              )}

              {/* Step 3: Complete */}
              {signingStep === 3 && (
                <div style={{ textAlign: "center", padding: "40px 20px" }}>
                  <div style={{ fontSize: 64, marginBottom: 16 }}>🎉</div>
                  <h2 style={{ margin: "0 0 8px", fontSize: 24, fontWeight: 800, color: "#166534" }}>Contract Signed!</h2>
                  <p style={{ fontSize: 14, color: "#64748B", margin: "0 0 24px" }}>
                    {selectedContract.invoice_number} has been signed and sealed. The audit trail has been recorded.
                  </p>
                  <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: 12, padding: 20, marginBottom: 24, textAlign: "left" }}>
                    {auditEvents.map((ev, i) => (
                      <div key={i} style={{ display: "flex", gap: 10, padding: "6px 0", fontSize: 12, borderBottom: i < auditEvents.length - 1 ? "1px solid #D1FAE5" : "none" }}>
                        <span>{ev.type === "signed" ? "✅" : "👁️"}</span>
                        <div>
                          <div style={{ fontWeight: 600, color: "#166534" }}>{ev.action}</div>
                          <div style={{ color: "#6B7280", fontSize: 11 }}>{fmtDateTime(ev.time)} · {ev.ip}</div>
                          {ev.hash && <div style={{ color: "#A78BFA", fontSize: 10, fontFamily: "monospace" }}>Hash: {ev.hash}</div>}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "flex", gap: 12 }}>
                    <button onClick={() => setActiveView("dashboard")}
                      style={{ flex: 1, padding: 12, background: "#fff", border: "1.5px solid #E2E8F0", borderRadius: 10, fontSize: 13, fontWeight: 600, color: "#64748B", cursor: "pointer" }}>
                      Back to Dashboard
                    </button>
                    <button onClick={() => setActiveView("audit")}
                      style={{ flex: 1, padding: 12, background: "linear-gradient(135deg, #1E3A5F, #0369A1)", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 700, color: "#fff", cursor: "pointer" }}>
                      View Full Audit Trail
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ══ AUDIT TRAIL VIEW ══ */}
          {activeView === "audit" && (
            <div>
              <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: "#1E293B" }}>Audit Trail</h2>
              <p style={{ margin: "0 0 24px", fontSize: 13, color: "#94A3B8" }}>Tamper-proof, immutable record of all signing activity</p>
              <AuditTrail events={auditEvents} />
            </div>
          )}
        </div>
      </div>

      {/* ── OTP Modal ── */}
      {showOTP && (
        <OTPModal
          signer={{ name: "Authorized Officer", phone: "+254 7XX XXX XXX" }}
          onVerified={handleOTPVerified}
          onClose={() => { setShowOTP(false); setSignature(null); }}
        />
      )}
    </MainLayout>
  );
}
