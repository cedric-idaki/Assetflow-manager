import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';

export const calcKenyaTax = (gross) => {
  const bands = [
    { limit: 24000,    rate: 0.10 },
    { limit: 8333,     rate: 0.25 },
    { limit: 467667,   rate: 0.30 },
    { limit: 300000,   rate: 0.325 },
    { limit: Infinity, rate: 0.35 },
  ];
  let paye = 0, remaining = gross;
  for (const band of bands) {
    if (remaining <= 0) break;
    const taxable = Math.min(remaining, band.limit);
    paye += taxable * band.rate;
    remaining -= taxable;
  }
  paye = Math.max(0, paye - 2400);
  const nssfTierI  = Math.min(gross, 7000) * 0.06;
  const nssfTierII = Math.min(Math.max(gross - 7000, 0), 11000) * 0.06;
  const nssf = nssfTierI + nssfTierII;
  const shif = Math.max(gross * 0.0275, 300);
  const totalDeductions = paye + nssf + shif;
  return {
    gross, paye: Math.round(paye), nssf: Math.round(nssf),
    shif: Math.round(shif), totalDeductions: Math.round(totalDeductions),
    net: Math.round(gross - totalDeductions),
  };
};

export const TRIGGER_LABELS = {
  cash_sale_completed:           { label: 'Cash Sale',           icon: '💵', color: 'emerald' },
  vat_on_cash_sale:              { label: 'VAT on Sale',         icon: '🏛️', color: 'blue'    },
  cogs_on_sale:                  { label: 'COGS',                icon: '📦', color: 'orange'  },
  installment_deposit_received:  { label: 'HP Deposit',          icon: '🏦', color: 'blue'    },
  installment_receivable_created:{ label: 'HP Receivable',       icon: '📋', color: 'violet'  },
  installment_payment_received:  { label: 'Installment Payment', icon: '💳', color: 'emerald' },
  interest_income_recognised:    { label: 'Interest Income',     icon: '📈', color: 'green'   },
  late_payment_penalty:          { label: 'Penalty',             icon: '⚠️', color: 'red'     },
  payroll_processed:             { label: 'Payroll',             icon: '👥', color: 'blue'    },
  paye_payable:                  { label: 'PAYE',                icon: '🏛️', color: 'red'     },
  nssf_payable:                  { label: 'NSSF',                icon: '🏛️', color: 'orange'  },
  shif_payable:                  { label: 'SHIF',                icon: '🏛️', color: 'orange'  },
  overpayment_wallet_credit:     { label: 'Overpayment Credit',  icon: '💰', color: 'blue'    },
  refund_issued:                 { label: 'Refund',              icon: '↩️', color: 'amber'   },
  payment_received:              { label: 'Payment',             icon: '💳', color: 'emerald' },
};

export const useFinanceHub = () => {
  const [adminId, setAdminId]                   = useState(null);
  const [companyProfile, setCompanyProfile]     = useState(null);
  const [invoices, setInvoices]                 = useState([]);
  const [journalEntries, setJournalEntries]     = useState([]);
  const [automatedEntries, setAutomatedEntries] = useState([]);
  const [payrollRecords, setPayrollRecords]     = useState([]);
  const [employees, setEmployees]               = useState([]);
  const [chartOfAccounts, setChartOfAccounts]   = useState([]);
  const [financialSummary, setFinancialSummary] = useState({
    totalRevenue: 0, totalExpenses: 0, netProfit: 0,
    totalAssets: 0, totalLiabilities: 0, equity: 0,
    pendingInvoices: 0, overdueInvoices: 0,
    totalInterestIncome: 0, totalPenaltyIncome: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const getAdminId = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');
    const { data: profile } = await supabase
      .from('user_profiles').select('id, role, admin_id').eq('id', user.id).single();
    return profile?.role === 'admin' ? user.id : (profile?.admin_id || user.id);
  }, []);

  const seedCOA = useCallback(async (aId) => {
    try {
      const { count } = await supabase
        .from('chart_of_accounts')
        .select('id', { count: 'exact', head: true })
        .eq('admin_id', aId);
      if (count === 0) {
        await supabase.rpc('seed_default_coa', { p_admin_id: aId });
      }
      const { data } = await supabase
        .from('chart_of_accounts').select('*').eq('admin_id', aId).order('account_code');
      setChartOfAccounts(data || []);
    } catch (err) { console.warn('COA seed skipped:', err.message); }
  }, []);

  const fetchCompanyProfile = useCallback(async (aId) => {
    try {
      const { data } = await supabase.from('company_profiles').select('*').eq('admin_id', aId).single();
      setCompanyProfile(data);
    } catch { setCompanyProfile(null); }
  }, []);

  const fetchInvoices = useCallback(async (aId) => {
    try {
      const { data } = await supabase
        .from('payments')
        .select(`id, amount, payment_date, payment_status, transaction_id,
          reference_number, payment_method, notes,
          client:clients(full_name, email, account_number),
          asset:assets(description, asset_code)`)
        .eq('processed_by', aId)
        .order('payment_date', { ascending: false });
      const mapped = (data || []).map((p, i) => ({
        id: p.id,
        invoice_no:   `INV-${String(p.transaction_id || i + 1000).slice(-4)}`,
        date:         p.payment_date,
        client_name:  p.client?.full_name || 'Unknown',
        client_email: p.client?.email || '',
        account_no:   p.client?.account_number || '',
        asset:        p.asset?.description || '—',
        amount:       parseFloat(p.amount || 0),
        status:       p.payment_status === 'completed' ? 'paid' : p.payment_status === 'pending' ? 'pending' : 'overdue',
        method:       p.payment_method || '—',
        reference:    p.reference_number || '—',
      }));
      setInvoices(mapped);
      return mapped;
    } catch { setInvoices([]); return []; }
  }, []);

  const fetchJournalEntries = useCallback(async (aId) => {
    try {
      const { data } = await supabase
        .from('journal_entries').select('*').eq('admin_id', aId)
        .order('entry_date', { ascending: false })
        .order('created_at', { ascending: false });
      const all       = data || [];
      const manual    = all.filter(j => !j.is_automated);
      const automated = all.filter(j =>  j.is_automated);
      setJournalEntries(manual);
      setAutomatedEntries(automated);
      return all;
    } catch { setJournalEntries([]); setAutomatedEntries([]); return []; }
  }, []);

  const fetchPayrollRecords = useCallback(async (aId) => {
    try {
      const { data } = await supabase
        .from('payroll_records')
        .select('*, employee:user_profiles(full_name, email, department)')
        .eq('admin_id', aId).order('pay_month', { ascending: false });
      setPayrollRecords(data || []);
    } catch { setPayrollRecords([]); }
  }, []);

  const fetchEmployees = useCallback(async (aId) => {
    try {
      const { data } = await supabase
        .from('user_profiles')
        .select('id, full_name, email, role, department, is_active')
        .eq('admin_id', aId).eq('is_active', true);
      setEmployees((data || []).filter(e => !['client','admin'].includes(e.role)));
    } catch { setEmployees([]); }
  }, []);

  const computeSummary = useCallback((journals) => {
    const posted = journals.filter(j => j.status === 'posted');
    const totalRevenue = posted
      .filter(j => ['Asset Sales Revenue (6100)','Interest Income (6200)'].includes(j.credit_account))
      .reduce((s, j) => s + parseFloat(j.amount || 0), 0);
    const totalInterestIncome = posted
      .filter(j => j.credit_account === 'Interest Income (6200)')
      .reduce((s, j) => s + parseFloat(j.amount || 0), 0);
    const totalPenaltyIncome = posted
      .filter(j => j.credit_account === 'Penalty Income (6300)')
      .reduce((s, j) => s + parseFloat(j.amount || 0), 0);
    const totalExpenses = posted
      .filter(j => (j.debit_account || '').startsWith('Salaries') || (j.debit_account || '').startsWith('Cost'))
      .reduce((s, j) => s + parseFloat(j.amount || 0), 0);
    const netProfit        = totalRevenue - totalExpenses;
    const totalAssets      = totalRevenue * 0.8;
    const totalLiabilities = totalExpenses * 0.3;
    const equity           = totalAssets - totalLiabilities;
    setFinancialSummary({
      totalRevenue, totalExpenses, netProfit,
      totalAssets, totalLiabilities, equity,
      totalInterestIncome, totalPenaltyIncome,
      pendingInvoices: 0, overdueInvoices: 0,
    });
  }, []);

  const loadAll = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const aId = await getAdminId();
      setAdminId(aId);
      const [invList, journals] = await Promise.all([
        fetchInvoices(aId),
        fetchJournalEntries(aId),
        fetchPayrollRecords(aId),
        fetchEmployees(aId),
        fetchCompanyProfile(aId),
        seedCOA(aId),
      ]);
      computeSummary(journals);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [getAdminId, fetchInvoices, fetchJournalEntries, fetchPayrollRecords,
      fetchEmployees, fetchCompanyProfile, seedCOA, computeSummary]);

  useEffect(() => { loadAll(); }, []);

  // Real-time: refresh journal when new entries auto-post
  useEffect(() => {
    if (!adminId) return;
    const channel = supabase
      .channel(`journal_${adminId}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'journal_entries',
        filter: `admin_id=eq.${adminId}`,
      }, () => fetchJournalEntries(adminId))
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [adminId, fetchJournalEntries]);

  const createJournalEntry = useCallback(async (entryData) => {
    if (!adminId) throw new Error('Not ready');
    const { data, error: err } = await supabase
      .from('journal_entries')
      .insert({
        admin_id: adminId,
        entry_date: entryData.date || new Date().toISOString().split('T')[0],
        description: entryData.description,
        debit_account: entryData.debitAccount,
        credit_account: entryData.creditAccount,
        amount: parseFloat(entryData.amount),
        entry_type: entryData.entryType || 'general',
        reference: entryData.reference || null,
        status: 'posted',
        is_automated: false,
      })
      .select().single();
    if (err) throw err;
    await fetchJournalEntries(adminId);
    return data;
  }, [adminId, fetchJournalEntries]);

  const runPayroll = useCallback(async (employeeId, grossSalary, payMonth) => {
    if (!adminId) throw new Error('Not ready');
    const tax = calcKenyaTax(parseFloat(grossSalary));
    const { data, error: err } = await supabase
      .from('payroll_records')
      .insert({
        admin_id: adminId, employee_id: employeeId, pay_month: payMonth,
        gross_salary: tax.gross, paye: tax.paye, nssf: tax.nssf, shif: tax.shif,
        total_deductions: tax.totalDeductions, net_salary: tax.net, status: 'pending',
      })
      .select().single();
    if (err) throw err;
    await fetchPayrollRecords(adminId);
    return { ...data, ...tax };
  }, [adminId, fetchPayrollRecords]);

  const approvePayroll = useCallback(async (payrollId) => {
    const { error: err } = await supabase
      .from('payroll_records')
      .update({ status: 'approved', approved_at: new Date().toISOString() })
      .eq('id', payrollId);
    if (err) throw err;
    // DB trigger auto-posts journal entries for salary, PAYE, NSSF, SHIF
    await Promise.all([fetchPayrollRecords(adminId), fetchJournalEntries(adminId)]);
  }, [adminId, fetchPayrollRecords, fetchJournalEntries]);

  return {
    adminId, companyProfile,
    invoices, journalEntries, automatedEntries, chartOfAccounts,
    payrollRecords, employees, financialSummary,
    loading, error,
    createJournalEntry, runPayroll, approvePayroll,
    refetch: loadAll,
    TRIGGER_LABELS,
  };
};

export default useFinanceHub;
